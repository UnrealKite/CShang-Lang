﻿// CShang.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.hpp"

#include "../Module/TokenParser.hpp"
#include "../Module/SyntaxPaser.hpp"
#include "../Module/SemanticAnalyzer.hpp"
#include "../Module/CodeGenerator.hpp"
#include "../Module/Linker.hpp"

#include "../Module/Helper.hpp"
#include "../Module/ObjectFile.hpp"
// 重要时间点记录：
// 工程创建日期：2025/6/30 14:42
// 组装出一个可以正常工作的空白EXE文件：
// 按代码逻辑真正成功编译出一个真正能运行的EXE文件：2025/9/7 10:15（只能函数调用，已正确处理外部函数导入）
// 正常处理字符串资源：学校四楼机房：2025/9/16 16:29

// 注意：自2025/9/22 13:07起，将“属性”更改为“选项”
// 2025/10/12下午开始重构屎山

namespace CShang
{
	static String ReadFileToString(const String& Path)
	{
		InFile File(Utf8ToUtf16(Path));
		StrStream SS;
		SS << File.rdbuf();
		return SS.str();
	}

	static void SetConsoleFont(int Size)
	{
		CONSOLE_FONT_INFOEX cfi{};
		cfi.cbSize = sizeof(cfi);
		cfi.nFont = 0;
		cfi.dwFontSize.X = 0;    // 字体宽度
		cfi.dwFontSize.Y = Size; // 字体高度
		cfi.FontFamily = FF_DONTCARE;
		cfi.FontWeight = FW_NORMAL;
		wcscpy_s(cfi.FaceName, LF_FACESIZE, L"霞鹜文楷等宽"); // 字体名称

		SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);
	}    

#define TEST_DEBUGPRINT

	static int OnMain()
	{
		/*ObjectFile_T ObjFile;

		ObjFuncRelocates_T* Relocates = new ObjFuncRelocates_T;
		Relocates->AddBinaryRes(0, u8"Hello, World!");
		Relocates->AddExternal(10, u8"kernel32.dll", u8"ExitProcess");
		ObjFile.AddFunction(u8"TestFunc", { 0x90, 0x90, 0x90 }, Relocates);
		ObjFile.SaveToFile("test.o");
		ObjFile.LoadFromFile("test.o");
		return 0;*/
		printf(u8"====================词法分析====================\n");
		// 读取代码文件
		const String Code = ReadFileToString(u8"TEST/TEST.Shang"/*u8"C:/Users/Admini/Desktop/测试.shang"*/);

		// 词法分析
		TokenParser_T TokenParser;
		TokenParser.SetCode(Code);

		if (!TokenParser.Parse())
		{
			const auto& Position = TokenParser.GetErrorPos();
			printf(u8"\033[38;2;255;0;0m词法分析错误： [行：%d, 列：%d] 错误：%s\033[0m\n", Position.Line, Position.Column, TokenParser.GetErrorMsg().c_str());
			return -1;
		}

#ifdef TEST_DEBUGPRINT
		TokenParser.DebugPrint();
#endif
		const auto& Tokens = TokenParser.GetResult();
		printf(u8"\033[38;2;0;255;0m词法分析成功！共计%llu个Token。\033[0m\n", Tokens.size());

		printf(u8"====================分析上色====================\n");

		// 打印分析后的Tokens（染色）
#ifdef TEST_DEBUGPRINT
		const auto& IntactTokens = TokenParser.GetIntactResult();
		for (const auto& Token : IntactTokens)
		{
			const uint32_t Color = GetTokenColor(Token);
			const BYTE R = *((BYTE*)(&Color));
			const BYTE G = *((BYTE*)&Color + 1);
			const BYTE B = *((BYTE*)&Color + 2);
			String Prefix, Suffix;
			switch (Token.Type)
			{
			//case TokenType::Empty:
			//    if (Token.Value != "\n") {
			//        printf(u8"empty: '%s'", Token.Value.c_str());
			//    }
			//	break;
			case TokenType::COM_String:
				Prefix = "\"";
				Suffix = "\"";
				break;
			case TokenType::COM_SComment:
				Prefix = "//";
				break;
			case TokenType::COM_MComment:
				Prefix = "/*";
				Suffix = "*/";
				break;
			}
			printf("\033[38;2;%d;%d;%dm%s%s%s\033[0m", R, G, B, Prefix.c_str(), Token.Value.c_str(), Suffix.c_str());
		}
		printf("\n");
#endif

		printf(u8"====================语法分析====================\n");
		// 语法分析
		SyntaxParser_T SyntaxParser;
		SyntaxParser.SetTokens(Tokens);

		if (!SyntaxParser.Parse())
		{
			const auto& Position = SyntaxParser.GetErrorPos();
			const auto& Message = SyntaxParser.GetErrorMsg();
			printf(u8"\033[38;2;255;0;0m语法分析错误： [行：%d, 列：%d] 错误：%s\033[0m\n", Position.Line, Position.Column, Message.c_str());
			return -2;
		}

		Space_T* Space = SyntaxParser.GetSpace();
		CodeBlock_T* InitCode = SyntaxParser.GetUnitInitCode();

		printf(u8"\033[38;2;0;255;0m词法分析成功！共计%llu个变量，共计%llu个函数，共计%llu个类。\033[0m\n",
			Space->GetVariables().size(),
			Space->Functions.size(),
			Space->Classes.size()
		);

		//printf(u8"====================语义分析====================\n");
		//// 语义分析
		//SemanticAnalyzer_T SemanticAnalyzer;
		//
		//SemanticAnalyzer.SetSpace(Space);
		//const bool Status = SemanticAnalyzer.Analyzer();

		//const auto& Errors = SemanticAnalyzer.GetErrors();
		//const auto& Warnings = SemanticAnalyzer.GetWarnings();
		//const auto& Infos = SemanticAnalyzer.GetInfos();

		//for (const auto& Error : Errors) {
		//	printf(u8"\033[38;2;255;0;0m语义分析错误： [行：%d, 列：%d] 错误：%s\033[0m\n", Error.Position.Line, Error.Position.Column, Error.Message.c_str());
		//}

		//for (const auto& Warning : Warnings) {
		//	printf(u8"\033[38;2;255;128;0m语义分析警告： [行：%d, 列：%d] 警告：%s\033[0m\n", Warning.Position.Line, Warning.Position.Column, Warning.Message.c_str());
		//}

		//for (const auto& Info : Infos) {
		//	printf(u8"\033[38;2;0;128;255m语义分析信息： [行：%d, 列：%d] 信息：%s\033[0m\n", Info.Position.Line, Info.Position.Column, Info.Message.c_str());
		//}

		//if (!Status) { return -3; }

		//printf(u8"====================代码生成====================\n");

		//CodeGenerator_T CodeGenerator;
		//CodeGenerator.SetSpace(Space);
		//CodeGenerator.SetUnitInitCode(InitCode);
		//CodeGenerator.SetOutputFile(u8"TEST/TEST.o");
		//if (!CodeGenerator.Generate())
		//{
		//	const String& ErrorMsg = CodeGenerator.GetErrorMsg();
		//	printf(u8"\033[38;2;255;0;0m代码生成失败：%s\033[0m\n", ErrorMsg.c_str());
		//	return -4;
		//}

		//printf(u8"====================链接====================\n");

		//Linker_T Linker;
		//Linker.AddInputFile(u8"TEST/TEST.o");
		//Linker.SetOutputFile(u8"C:/Users/Admini/Desktop/TEST.EXE");
		//if (!Linker.Build())
		//{
		//	const String& ErrorMsg = Linker.GetErrorMsg();
		//	printf(u8"\033[38;2;255;0;0m链接失败：%s\033[0m\n", ErrorMsg.c_str());
		//	return -5;
		//}

		return 0;
	}
}

int main()
{
	SetConsoleTitleW(L"CShang");
	SetConsoleOutputCP(CP_UTF8);
	CShang::SetConsoleFont(36);

	// 格式：\033[属性;前景色;背景色m
	//printf(u8"\033[31m这是红色文本\033[0m\n");  // 红色文本
	//printf(u8"\033[32m这是绿色文本\033[0m\n");  // 绿色文本
	//printf(u8"\033[33m这是黄色文本\033[0m\n");  // 黄色文本
	//printf(u8"\033[34m这是蓝色文本\033[0m\n");  // 蓝色文本

	// 重置颜色为默认
	//printf(u8"\033[0m");

	std::cout << "Hello World!\n";
	return CShang::OnMain();
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件