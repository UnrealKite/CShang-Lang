#ifndef PCH_HPP
#define PCH_HPP


#include <Windows.h>

#include <iostream>
#include <string>
using String = std::string;
using WString = std::wstring;

#include <set>

template<typename T>
using Set = std::set<T>;

#include <iomanip> // std::setw

#include <fstream>
#include <sstream>

#include <functional>

using InFile = std::ifstream;
using OutFile = std::ofstream;
using StrStream = std::stringstream;

#include <vector>
template<typename T>
using Array = std::vector<T>;

#include <stack>
template<typename T>
using Stack = std::stack<T>;

#include <map>
template<typename Key, typename Value>
using Map = std::map<Key, Value>;

template<typename Key, typename Value>
using Pair = std::pair<Key, Value>;

template<typename... Types>
using Tuple = std::tuple<Types...>;

using Exception = std::runtime_error;

struct Position_T
{
	int Line = 0, Column = 0;
};

// Externals
#include <JsonCpp/json.h>

#endif // !PCH_HPP