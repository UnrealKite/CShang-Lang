// by: shangyuan
#ifndef CODE_GENERATOR_HPP
#define CODE_GENERATOR_HPP
#include "../Program/pch.hpp"
#include "Assembler.hpp"
#include "ClassDefine.hpp"
#include "StackResAllocator.hpp"
namespace CShang
{
	class CodeGenerator_T
	{
	public:
		CodeGenerator_T() = default;
		~CodeGenerator_T() = default;

		void SetSpace(const Space_T* Space);
		void SetUnitInitCode(const CodeBlock_T* Block);
		void SetOutputFile(const String& Path);
		bool Generate();
		const String& GetErrorMsg() const;

		void GenerateUnit(class ObjectFile_T* ObjFile, const Space_T* Space);

		struct GeneratorParam_T
		{
			x86::Assembler_T* Assembler = nullptr;
			StackResAllocator_T* Allocator = nullptr;
			const Function_T* Function = nullptr;
			class ObjFuncRelocates_T* Relocates = nullptr;
		};
		// Pair<����, �����ռ�, �������ڴ�ƫ��>
		// �����ռ䣺 0 = δ�ҵ� 1 = �ֲ����� 2 = ����
		Tuple<Variable_T*, int, int> FindVariable(GeneratorParam_T* Param, const String& VarName);
		void GenerateRealFuncBody(GeneratorParam_T* Param);
		void GenerateRealFuncParam(GeneratorParam_T* Param, const ASTNode_T* AParam);
		void GenerateStatement_Calling(GeneratorParam_T* Param, const CallingStatement_T* Calling);
		void GenerateStatement_Assign(GeneratorParam_T* Param, const AssignStatement_T* Assign);
		// ���ɱ�����ַ����ʽ
		//x86::Register GenerateVariableAddress(GeneratorParam_T* Param, const MemberAccess_T* MemberAcc);
		// Pair<�Ĵ���, ƫ��>
		Pair<x86::Register, int> GenerateNode_MemberAccPtr(GeneratorParam_T* Param, const MemberAccess_T* MemberAcc);
		x86::Register GenerateExpression_Binary(GeneratorParam_T* Param, const BinaryExpression_T* Binary);
		x86::Register GenerateBinaryRight(GeneratorParam_T* Param, const BinOp_E Op, const ASTNode_T* Right);
		x86::Register GenerateValueExpression(GeneratorParam_T* Param, const ASTNode_T* Node);

	private:
		thread_local static String m_ErrorMsg;
		const Space_T* m_Space = nullptr;
		const CodeBlock_T* m_UnitInitCode = nullptr;
		String m_OutputFile;
		bool FindFunction(const Function_T** Result, const String& Name);
	};
}
#endif // !CODE_GENERATOR_HPP