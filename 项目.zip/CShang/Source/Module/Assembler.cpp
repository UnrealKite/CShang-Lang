#include "Assembler.hpp"
namespace CShang
{
	namespace x86
	{
		static Map<Register, Map<Register, BYTE>> RegisterMap
		{
			{
				Register::Eax,
				{
					{ Register::Eax, 0xC0 }, { Register::Ebx, 0xC3 },
					{ Register::Ecx, 0xC1 }, { Register::Edx, 0xC2 },
					{ Register::Edi, 0xC7 }, { Register::Esi, 0xC6 },
					{ Register::Esp, 0xC4 }, { Register::Ebp, 0xC5 }
				},
			},
			{
				Register::Ebx,
				{
					{ Register::Eax, 0xD8 }, { Register::Ebx, 0xDB },
					{ Register::Ecx, 0xD9 }, { Register::Edx, 0xDA },
					{ Register::Edi, 0xDF }, { Register::Esi, 0xDE },
					{ Register::Esp, 0xDC }, { Register::Ebp, 0xDD }
				},
			},
			{
				Register::Ecx,
				{
					{ Register::Eax, 0xC8 }, { Register::Ebx, 0xCB },
					{ Register::Ecx, 0xC9 }, { Register::Edx, 0xCA },
					{ Register::Edi, 0xCF }, { Register::Esi, 0xCE },
					{ Register::Esp, 0xCC }, { Register::Ebp, 0xCD }
				},
			},
			{
				Register::Edx,
				{
					{ Register::Eax, 0xD0 }, { Register::Ebx, 0xD3 },
					{ Register::Ecx, 0xD1 }, { Register::Edx, 0xD2 },
					{ Register::Edi, 0xD7 }, { Register::Esi, 0xD6 },
					{ Register::Esp, 0xD4 }, { Register::Ebp, 0xD5 }
				},
			},
			{
				Register::Esi,
				{
					{ Register::Eax, 0xF0 }, { Register::Ebx, 0xF3 },
					{ Register::Ecx, 0xF1 }, { Register::Edx, 0xF2 },
					{ Register::Edi, 0xF7 }, { Register::Esi, 0xF6 },
					{ Register::Esp, 0xF4 }, { Register::Ebp, 0xF5 }
				},
			},
			{
				Register::Edi,
				{
					{ Register::Eax, 0xF8 }, { Register::Ebx, 0xFB },
					{ Register::Ecx, 0xF9 }, { Register::Edx, 0xFA },
					{ Register::Edi, 0xFF }, { Register::Esi, 0xFE },
					{ Register::Esp, 0xFC }, { Register::Ebp, 0xFD }
				},
			},
			{
				Register::Esp,
				{
					{ Register::Eax, 0xE0 }, { Register::Ebx, 0xE3 },
					{ Register::Ecx, 0xE1 }, { Register::Edx, 0xE2 },
					{ Register::Edi, 0xE7 }, { Register::Esi, 0xE6 },
					{ Register::Esp, 0xE4 }, { Register::Ebp, 0xE5 }
				},
			},
			{
				Register::Ebp,
				{
					{ Register::Eax, 0xE8 }, { Register::Ebx, 0xEB },
					{ Register::Ecx, 0xE9 }, { Register::Edx, 0xEA },
					{ Register::Edi, 0xEF }, { Register::Esi, 0xEE },
					{ Register::Esp, 0xEC }, { Register::Ebp, 0xED }
				},
			}
		};

		static Map<Register, BYTE> SRMap
		{
			{ Register::Eax, 0x0 },
			{ Register::Ebx, 0x3 },
			{ Register::Ecx, 0x1 },
			{ Register::Edx, 0x2 },
			{ Register::Edi, 0x7 },
			{ Register::Esi, 0x6 },
			{ Register::Esp, 0x4 },
			{ Register::Ebp, 0x5 }
		};

		Assembler_T::Assembler_T()
		{
		}

		Assembler_T::~Assembler_T()
		{
		}

		void Assembler_T::ResetPointer()
		{
			m_Position = SIZE_MAX;
		}

		void Assembler_T::SetPointer(size_t Pos)
		{
			m_Position = Pos;
		}

		size_t Assembler_T::GetPointer() const
		{
			return m_Position;
		}

		void Assembler_T::DB(BYTE Byte)
		{
			if (m_Position == SIZE_MAX) {
				m_Code.push_back(Byte);
				return;
			}
			m_Code.insert(m_Code.begin() + m_Position, Byte);
			++m_Position;
		}

		void Assembler_T::DW(WORD Word)
		{
			DB(Word & 0xFF);
			DB((Word >> 8) & 0xFF);
		}

		void Assembler_T::DD(DWORD DWord)
		{
			DB(DWord & 0xFF);
			DB((DWord >> 8) & 0xFF);
			DB((DWord >> 16) & 0xFF);
			DB((DWord >> 24) & 0xFF);
		}

		size_t Assembler_T::GetSize() const
		{
			return m_Code.size();
		}

		const Array<BYTE>& Assembler_T::_GetBytes() const
		{
			return m_Code;
		}

		void Assembler_T::Nop()
		{
			DB(0x90);
		}

		void Assembler_T::Retn()
		{
			DB(0xC3);
		}

		void Assembler_T::Ret_Imm16(uint16_t Value)
		{
			DB(0xC2);
			DW(Value);
		}


		void Assembler_T::Push(Register R, int Offset)
		{
			DB(0xFF);

			// ���λ���Ƿ��ʺ�8λ�з�������
			bool use_8bit_offset = (Offset >= -128 && Offset <= 127);

			if (use_8bit_offset) {
				DB(SRMap[R] + 0x70);
				// ����8λλ��
				DB(Offset & 0xFF);
			}
			else {
				DB(SRMap[R] + 0xB0);
				// ����32λλ��
				DD((DWORD)Offset);
			}
		}

		void Assembler_T::Push_Imm8(uint8_t Value)
		{
			// 8λ��������������չ��
			DB(0x6A);
			DB(Value);
		}

		void Assembler_T::Push_Imm32(uint32_t Value)
		{
			// 32λ������
			DB(0x68); // push imm32
			DD(Value);
		}

		void Assembler_T::Push(int32_t Value)
		{
			if (Value >= -128 && Value <= 127) {
				Push_Imm8((uint8_t)Value);
			}
			else {
				Push_Imm32((uint32_t)Value);
			}
		}

		void Assembler_T::Push_U(uint32_t Value)
		{
			if (Value <= 0xFF) {
				Push_Imm8((uint8_t)Value);
			}
			else {
				Push_Imm32(Value);
			}
		}

		void Assembler_T::Push(Register R)
		{
			DB(0x50 + SRMap[R]);
		}

		void Assembler_T::Pop(Register R)
		{
			DB(0x58 + SRMap[R]);
		}

		void Assembler_T::Mov(Register R, uint32_t Value)
		{
			DB(0xB8 + SRMap[R]);
			// ����32λλ��
			DD(Value);
		}

		void Assembler_T::Mov(Register A, Register B)
		{
			DB(0x8B);
			DB(RegisterMap[A][B]);
		}

		void Assembler_T::Mov(Register A, Register B, int Offset)
		{
			Register Temp = A;
			A = B;
			B = Temp;
			// mov A, [B + Offset]
			DB(0x8B);
			// ����Ƿ���Ҫ SIB �ֽڣ�esp �� ebp ��Ϊ��ַ�Ĵ���ʱ��Ҫ��
			bool needs_sib = (B == Register::Esp);

			// ���λ���Ƿ��ʺ�8λ�з�������
			bool use_8bit_offset = (Offset >= -128 && Offset <= 127);

			// ֱ�Ӵ�ӳ����л�ȡ�����ֽ�
			BYTE base_byte = RegisterMap[B][A];

			// �޸�mod�ֶ�
			if (use_8bit_offset) {
				// mod=01 (8λλ��)
				BYTE modrm = (base_byte & 0x3F) | 0x40;
				DB(modrm);

				// ����8λλ��
				DB(Offset & 0xFF);
			}
			else {
				// mod=10 (32λλ��)
				BYTE modrm = (base_byte & 0x3F) | 0x80;
				DB(modrm);

				// ����32λλ��
				DD((DWORD)Offset);
			}
		}

		void Assembler_T::Mov(void* Addr, Register V)
		{

		}

		void Assembler_T::Mov(Register A, int Offset, Register B)
		{

			// mov [A + Offset], B
			DB(0x89);

			// ���λ���Ƿ��ʺ�8λ�з�������
			bool use_8bit_offset = (Offset >= -128 && Offset <= 127);

			// ֱ�Ӵ�ӳ����л�ȡ�����ֽ�
			BYTE base_byte = RegisterMap[B][A];

			// �޸�mod�ֶ�
			if (use_8bit_offset) {
				// mod=01 (8λλ��)
				BYTE modrm = (base_byte & 0x3F) | 0x40;
				DB(modrm);

				// ����8λλ��
				DB(Offset & 0xFF);
			}
			else {
				// mod=10 (32λλ��)
				BYTE modrm = (base_byte & 0x3F) | 0x80;
				DB(modrm);

				// ����32λλ��
				DD((DWORD)Offset);
			}

		}

		void Assembler_T::Mov(Register R, int Offset, uint32_t Value)
		{
			// mov [A + Offset], Value
			DB(0xC7);
			if (Offset == 0 && R != Register::Ebp) {
				DB(SRMap[R]);
				if (R == Register::Esp) {
					DB(0x24);
				}
			}
			else if (Offset >= -128 && Offset <= 127) {
				// 8λλ��
				DB(SRMap[R] + 0x40);
				DB((BYTE)Offset);
			}
			else {
				// 32λλ��
				DB(SRMap[R] + 0x80);
				DD((DWORD)Offset);
			}
			DD(Value);
		}


		/*void Assembler_T::Sub(Register A, uint32_t Value)
		{
			if (Value <= 0xFF) {
				DB(0x83);
				DB(0xE8 + SRegisterMap[A]);
				DB(Value & 0xFF);
			}
			else if (Value <= 0xFFFF) {
				DB(0x81);
				DB(0xE8 + SRegisterMap[A]);
				DB(Value & 0xFF);
				DB((Value >> 8) & 0xFF);
			}
			else {
				DB(0x81);
				DB(0xE8 + SRegisterMap[A]);
				DB(Value & 0xFF);
				DB((Value >> 8) & 0xFF);
				DB((Value >> 16) & 0xFF);
				DB((Value >> 24) & 0xFF);
			}
		}*/

		void Assembler_T::Lea(Register A, Register B, int Offset)
		{
			// lea A, [B + Offset]
			DB(0x8D); // LEA ������

			// ����Ƿ���Ҫ SIB �ֽڣ�esp �� ebp ��Ϊ��ַ�Ĵ���ʱ��Ҫ��
			bool needs_sib = (B == Register::Esp);

			// ���λ���Ƿ��ʺ�8λ�з�������
			bool use_8bit_offset = (Offset >= -128 && Offset <= 127);

			if (needs_sib) {
				// ��Ҫ SIB �ֽڵ������esp ��Ϊ��ַ�Ĵ�����
				if (use_8bit_offset && Offset != 0) {
					// mod=01 (8λλ��), reg=A, r/m=100 (��ʾSIB)
					BYTE modrm = 0x40 | ((RegisterMap[A][A] & 0x38)) | 0x04;
					DB(modrm);

					// SIB �ֽ�: scale=00, index=100(��index), base=esp(100)
					DB(0x24);

					// ����8λλ��
					DB(Offset & 0xFF);
				}
				else if (Offset == 0) {
					// mod=00, reg=A, r/m=100 (��ʾSIB)
					BYTE modrm = ((RegisterMap[A][A] & 0x38)) | 0x04;
					DB(modrm);

					// SIB �ֽ�: scale=00, index=100(��index), base=esp(100)
					DB(0x24);
				}
				else {
					// mod=10 (32λλ��), reg=A, r/m=100 (��ʾSIB)
					BYTE modrm = 0x80 | ((RegisterMap[A][A] & 0x38)) | 0x04;
					DB(modrm);

					// SIB �ֽ�: scale=00, index=100(��index), base=esp(100)
					DB(0x24);

					// ����32λλ��
					DD((DWORD)Offset);
				}
			}
			else {
				// ��ͨ���������Ҫ SIB �ֽ�
				BYTE base_byte = RegisterMap[A][B];

				if (use_8bit_offset && Offset != 0) {
					// mod=01 (8λλ��)
					BYTE modrm = (base_byte & 0x3F) | 0x40;
					DB(modrm);

					// ����8λλ��
					DB(Offset & 0xFF);
				}
				else if (Offset == 0 && B != Register::Ebp) {
					// mod=00 (��λ��)���� ebp ��Ҫ���⴦��
					BYTE modrm = base_byte & 0x3F;
					DB(modrm);
				}
				else if (Offset == 0 && B == Register::Ebp) {
					// Ebp ��Ϊ��ַ�Ĵ�����û��λ��ʱ����Ҫ mod=01 �� 8λ0λ��
					BYTE modrm = (base_byte & 0x3F) | 0x40;
					DB(modrm);
					DB(0x00);
				}
				else {
					// mod=10 (32λλ��)
					BYTE modrm = (base_byte & 0x3F) | 0x80;
					DB(modrm);

					// ����32λλ��
					DD((DWORD)Offset);
				}
			}
		}

		void Assembler_T::Add(Register R, int32_t Value)
		{
			if (Value <= 0x7F && Value >= -0x80) {
				DB(0x83);
				DB(0xC0 + SRMap[R]);
				DB(Value & 0xFF);
			}
			else {
				DB(0x05 + SRMap[R]);
				DD(Value);
			}
		}

		void Assembler_T::Sub(Register R, int32_t Value)
		{
			if (Value <= 0x7F && Value >= -0x80) {
				DB(0x83);
				DB(0xE8 + SRMap[R]);
				DB(Value & 0xFF);
			}
			else {
				DB(0x2D + SRMap[R]);
				DD(Value);
			}
		}

		void Assembler_T::Add(Register A, Register B)
		{
			DB(0x01);
			DB(0xC0 + SRMap[A] + SRMap[B] * 8);
		}

		void Assembler_T::Sub(Register A, Register B)
		{
			DB(0x29);
			DB(0xC0 + SRMap[A] + SRMap[B] * 8);
		}

		void Assembler_T::Add(Register A, Register B, int Offset)
		{
			DB(0x03);
			if (Offset <= 0x7F && Offset >= -0x80) {
				DB(0x40 + SRMap[A] * 8 + SRMap[B]);
				DB((BYTE)Offset);
			}
			else {
				DB(0x80 + SRMap[A] * 8 + SRMap[B]);
				DD((DWORD)Offset);
			}
		}

		void Assembler_T::Sub(Register A, Register B, int Offset)
		{
			DB(0x2B);
			if (Offset <= 0x7F && Offset >= -0x80) {
				DB(0x40 + SRMap[A] * 8 + SRMap[B]);
				DB((BYTE)Offset);
			}
			else {
				DB(0x80 + SRMap[A] * 8 + SRMap[B]);
				DD((DWORD)Offset);
			}
		}

		void Assembler_T::Imul2(Register A, Register B)
		{
			DB(0x0F);
			DB(0xAF);
			DB(0xC0 + SRMap[A] + SRMap[B] * 8);
		}

		void Assembler_T::Imul2(Register A, Register B, int Offset)
		{
			DB(0x0F);
			DB(0xAF);
			if (Offset <= 0x7F && Offset >= -0x80) {
				DB(0x40 + SRMap[A] * 8 + SRMap[B]);
				DB((BYTE)Offset);
			}
			else {
				DB(0x80 + SRMap[A] * 8 + SRMap[B]);
				DD((DWORD)Offset);
			}
		}

		void Assembler_T::Imul3(Register A, Register B, int32_t Value)
		{
			if (Value <= 0x7F && Value >= -0x80) {
				DB(0x6B);
				DB(0xC0 + SRMap[A] + SRMap[B] * 8);
				DB((BYTE)Value);
			}
			else {
				DB(0x69);
				DB(0xC0 + SRMap[A] + SRMap[B] * 8);
				DD((DWORD)Value);
			}
		}

		void Assembler_T::Call(void* Addr)
		{
			// call Addr
			DB(0xE8);

			// (Ԥ��4�ֽ�)
			DD(0);
		}

		void Assembler_T::Call_Dword_Ptr(void* Addr)
		{
			// call dword ptr [Addr]
			DB(0xFF);
			DB(0x15);

			// ����32λ��ַ
			const DWORD Addr32 = (DWORD)Addr;
			DD(Addr32);
		}
	}
}