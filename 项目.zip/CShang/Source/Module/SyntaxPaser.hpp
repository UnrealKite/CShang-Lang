﻿#ifndef SYNTAX_PARSER_HPP
#define SYNTAX_PARSER_HPP
#include "../Program/pch.hpp"
#include "Token.hpp"
#include "ClassDefine.hpp"

#define SIZE_T_MAX ~static_cast<size_t>(0)
#define ERROR_MSG_BUTGOT(Token) (String)(Token.Value.empty() ? u8"但意外结尾。" : u8"但得到\"" + Token.Value + "\"。")

namespace CShang
{
	class SyntaxParser_T
	{
	public:
		SyntaxParser_T() = default;
		~SyntaxParser_T() = default;
		void SetTokens(const Array<Token_T>& Tokens);
		Space_T* GetSpace();
		const Space_T* GetSpace() const;
		CodeBlock_T* GetUnitInitCode();
		const CodeBlock_T* GetUnitInitCode() const;
		const Array<String>& GetNeededUnits() const;
		bool Parse();
		const Position_T& GetErrorPos() const;
		const String& GetErrorMsg() const;

	private:
		Array<Token_T> m_Tokens;
		String m_ParsingError;

		size_t m_CurTokenIndex = -1;
		//// 类、结构体
		//const SpaceMember_T* m_LastContainerObj = nullptr;

		Space_T m_Space;
		CodeBlock_T m_UnitInitCode;
		Array<String> m_NeededUnits;

		const Token_T& _PeekToken(intptr_t Pos = 1) const;
		const Token_T& _CurToken() const;
		const Token_T& _NextToken();
		const Token_T& _LastToken();
		
		Array<const Token_T*> ParseBracketKeys();

		bool ParseSpaceMember(Space_T* Space);
		// 类型
		PTypeDesc _ParseType();
		// 解析标识符和属性
		String _ParseNameAndOptions(SpaceMember_T* Member);

		// 解析变量
		String _ParseVariable(Space_T* Space, CodeBlock_T* Block, LONG_PTR Tag = 0);
	    // 解析函数
		void _ParseFunction(Space_T* Space, LONG_PTR Tag = 0);

		// 解析函数参数
		using Parameter = std::pair<std::string, PTypeDesc>;
		using ParameterList = std::vector<Parameter>;
		ParameterList _ParseParametersOrResults();

		// 解析函数的单个参数
		void _ParseFunctionParam(Function_T* Function);

		// 解析结构体
		void _ParseStructure(Space_T* Space);
		// 解析类
		void _ParseClass(Space_T* Space);

		// 解析一个代码块
        void ParseCode(Space_T* Space, CodeBlock_T* Block, bool IsTopSpace = false);
        ASTNode_T* ParseExpression(Space_T* Space, CodeBlock_T* Block, bool IsAtomicity = false);
		void HandleBrackets();
		void HandleToken(CodeBlock_T* Block, const Token_T& Tk, bool IsAtomicity);

		void HandleAtomicToken(CodeBlock_T* Block, ASTNode_T* Node);
		void HandleBinaryOperator(CodeBlock_T* Block, BinaryExpression_T* Binary);
	};
}
#endif // !SYNTAX_PARSER_HPP