﻿#include "ClassDefine.hpp"
namespace CShang
{
	/*============TypeDesc_T============*/
	
	PTypeDesc TypeDesc_T::Create(const String& Name)
	{
		PTypeDesc Ptr = std::make_shared<TypeDesc_T>();
		Ptr->Name = Name;
		return Ptr;
	}

	size_t TypeDesc_T::GetSize() const
	{
		if (Name == u8"整数型" || Name == u8"单浮点") { return 4; }
		if (Name == u8"长数型" || Name == u8"双浮点") { return 8; }
		// 默认4字节
		if (DefinitionPtr == nullptr) { return 4; }
		size_t Size = 0;
		const SpaceMemberType Type = DefinitionPtr->GetMemberType();
		if (Type == SpaceMemberType::Structure) {
			const Structure_T* Structure = (const Structure_T*)DefinitionPtr;
			const auto& Members = Structure->Space.GetVariables();
			for (const auto& Member : Members) {
				Size += Member.second->TypeDesc->GetSize();
			}
			return Size;
		}
	}

	/*============Space_T============*/

	Space_T::~Space_T()
	{
		/*for (auto& Variable : Variables) {
			delete Variable.second;
			Variable.second = nullptr;
		}
		for (auto& Function : Functions) {
			delete Function.second;
			Function.second = nullptr;
		}
		for (auto& Class : Classes) {
			delete Class.second;
			Class.second = nullptr;
		}*/
	}

	String Space_T::GetAccessName() const
	{
		if (Parent == nullptr) { return ""; }
		// 判断当前空间对象是否属于某个类
		const SpaceMemberType T = Parent->GetMemberType();
		if (T == SpaceMemberType::Class) {
			// 获取当前空间对象所属的类
			const Class_T* Class = (const Class_T*)Parent;
			for (const auto& it : Class->Parent->Classes) {
				if (it.second == Class) {
					if (Class->Parent == nullptr) {
						return it.first;
					}
					String AccSymbol = Class->Parent->GetAccessName();
					if (!AccSymbol.empty()) {
						AccSymbol += ".";
					}
					return AccSymbol + it.first;
				}
			}
		}
		return "";
	}

	void Space_T::AddVariable(const String& VarName, Variable_T* VarObj)
	{
		m_Variables.push_back(std::make_pair(VarName, VarObj));
	}

	Variable_T* Space_T::FindVariable(const String& VarName) const
	{
		for (const auto& Variable : m_Variables) {
			if (Variable.first == VarName) {
				return Variable.second;
			}
		}
		return nullptr;
	}

	const Array<Pair<String, Variable_T*>>& Space_T::GetVariables() const
	{
		return m_Variables;
	}

	/*============SpaceMember_T============*/

	SpaceMember_T::SpaceMember_T(Space_T* Parent)
	{
		m_MemberType = SpaceMemberType::Unknown;
	}

	SpaceMemberType SpaceMember_T::GetMemberType() const
	{
		return m_MemberType;
	}

	/*void SpaceMember_T::SetName(const String& Name)
	{
		m_Name = Name;
	}

	const String& SpaceMember_T::GetName() const
	{
		return m_Name;
	}*/

	void SpaceMember_T::AddOption(const String& Option, const Array<String>& Params)
	{
		m_Options[Option] = Params;
	}

	const Array<String>* SpaceMember_T::GetOption(const String& Option) const
	{
		auto It = m_Options.find(Option);
		if (It != m_Options.end()) {
			return &It->second;
		}
		return nullptr;
	}

	const Map<String, Array<String>>& SpaceMember_T::GetOptions() const
	{
		return m_Options;
	}

	/*============Function_T============*/

	Function_T::Function_T(Space_T* Owner)
	{
		m_MemberType = SpaceMemberType::Function;
		Space.Parent = this;
		Parent = Owner;
	}

	void Function_T::AddParam(PTypeDesc Type, const String& Name)
	{
		Variable_T* Param = new Variable_T;
		Param->TypeDesc = Type;
		m_Params.push_back(std::make_pair(Name, Param));
	}

	const Array<Pair<String, Variable_T*>>& Function_T::GetParams() const
	{
		return m_Params;
	}

	void Function_T::AddResult(PTypeDesc Type, const String& Name)
	{
		Variable_T* Result = new Variable_T;
		Result->TypeDesc = Type;
		m_Results.push_back(std::make_pair(Name, Result));
	}

	const Array<Pair<String, Variable_T*>>& Function_T::GetResults() const
	{
		return m_Results;
	}

	Pair<Variable_T*, size_t> Function_T::GetParamObjAndOffset(const String& Name) const
	{
		size_t Offset = 0x4;
		for (const auto Param : m_Params) {
			if (!Param.first.empty() && Param.first == Name) {
				return std::make_pair(Param.second, Offset);
			}
			Offset += Param.second->TypeDesc->GetSize();
		}
		return std::make_pair(nullptr, SIZE_MAX);
	}

	size_t Function_T::GetParamOffset(const String& Name) const
	{
		return GetParamObjAndOffset(Name).second;
	}

	Variable_T* Function_T::FindParam(const String& Name) const
	{
		return GetParamObjAndOffset(Name).first;
	}

	String Function_T::GetFeatureDesc() const
	{
		String DefDesc = u8"函数";
		// 参数
		DefDesc += "(";
		size_t i = 0;
		for (const auto& Param : m_Params) {
			if (i != 0) {
				DefDesc += ",";
			}
			Param.second->TypeDesc->Name;
			++i;
		}
		DefDesc += ")";
		// 类型
		/*if (ResultType != nullptr) {
			DefDesc += ":" + ResultType->Name;
		}*/
		return DefDesc;
	}

	/*============Variable_T============*/

	Variable_T::Variable_T()
	{
		m_MemberType = SpaceMemberType::Variable;
	}

	/*============Structure_T============*/

	Structure_T::Structure_T(Space_T* Owner)
	{
		m_MemberType = SpaceMemberType::Structure;
	}

	size_t Structure_T::GetMemberVarOffset(const String& Name) const
	{
		size_t Offset = 0;
		for (const auto& MemberVar : Space.GetVariables()) {
			if (MemberVar.first == Name) {
				return Offset;
			}
			else {
				Offset += MemberVar.second->TypeDesc->GetSize();
			}
		}
		return SIZE_MAX;
	}

	/*============Class_T============*/

	Class_T::Class_T(Space_T* Owner)
	{
		m_MemberType = SpaceMemberType::Class;
		Space.Parent = this;
		Parent = Owner;
	}

	Array<Function_T*> Class_T::GetConstructors() const
	{
		Array<Function_T*> Result;
		for (const auto& ReloadFuncs : Space.Functions) {
			for (const auto& Func : ReloadFuncs.second) {
				if (Func->Tag == TAG_FUNCTION_CONSTRUCTOR) {
					Result.push_back(Func);
				}
			}
		}
		return Result;
	}

	Array<Function_T*> Class_T::GetDestructors() const
	{
		Array<Function_T*> Result;
		for (const auto& ReloadFuncs : Space.Functions) {
			for (const auto& Func : ReloadFuncs.second) {
				if (Func->Tag == TAG_FUNCTION_DESTRUCTOR) {
					Result.push_back(Func);
				}
			}
		}
		return Result;
	}
	
	

}