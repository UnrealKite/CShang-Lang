﻿#ifndef SEMANTIC_ANALYZER_HPP
#define SEMANTIC_ANALYZER_HPP
#include "../Program/pch.hpp"
#include "../Module/ClassDefine.hpp"
namespace CShang
{
	class Space_T;

	struct PositionEx_T : public Position_T
	{
		size_t CharNum = 0;
	};

	struct SAException_T
	{
		enum class EType
		{
			None,
			Error,
			Warning,
			Info,
		};
		EType Type = EType::None;
		PositionEx_T Position;
		String Message;
	};

	/**
	* @class SemanticAnalyzer_T
	* @brief 语法分析类
	* 
	* 此类负责语义检查
	* 将所有字面量的二元运算结果直接计算出来
	* 将所有二元表达式的字面量移动到右边
	* 选项展开
	* 未使用的函数局部变量去除
	* 查找TypeDesc对应的类型并添加定义的指针指向
	* 查找被赋值目标的指针并设置为Hint
	*/
	class SemanticAnalyzer_T
	{
	public:
		SemanticAnalyzer_T() = default;
		~SemanticAnalyzer_T() = default;
		
		void SetSpace(Space_T* Space);
		bool Analyzer();
		

		const Array<SAException_T>& GetErrors() const;
		const Array<SAException_T>& GetWarnings() const;
		const Array<SAException_T>& GetInfos() const;

	private:
		Space_T* m_Space = nullptr;
		Array<SAException_T> m_Errors;
		Array<SAException_T> m_Warnings;
		Array<SAException_T> m_Infos;

		void PushException(const String& Message, SAException_T::EType Type = SAException_T::EType::Error);
		void ExceptionTest();

		void AnalyzerSpace(Space_T* Space);

		const Variable_T* FindVariable(const Function_T* Func, const String& Name);
		const Variable_T* FindVariableFromParent(const Space_T* Space, const String& Name);

		
		SpaceMember_T* FindTypeFromSpace(const Space_T* Space, const String& Name);
		void AnalyzerTypeDesc(PTypeDesc* pResult, const Space_T* Space);

		void AnalyzeStatement_Calling(Function_T* Func, const CallingStatement_T* Calling);
		void AnalyzeStatement_Assign(Function_T* Func, AssignStatement_T* Assign);
		void AnalyzeExpression_MemberAccess(const Function_T* Func, const MemberAccess_T* MemberAcc);
		void AnalyzerNode_Right(ASTNode_T** Parent, ASTNode_T* Value);
		void AnalyzeExpression_Binary(ASTNode_T** Parent, BinaryExpression_T* Binary);
	};
}
#endif // !SEMANTIC_ANALYZER_HPP