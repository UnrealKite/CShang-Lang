﻿#include "TokenParser.hpp"
#include "Helper.hpp"
namespace CShang
{
	void TokenParser_T::SetCode(const String& Code)
	{
		m_Code = Code;
		m_Chars = SplitUTF8(m_Code);
	}

	bool TokenParser_T::Parse()
	{
		m_ParsingError.clear();
		m_Position.Line = 1;
		m_Position.Column = 1;

		for (const auto& Char : m_Chars)
		{
			Token_T CurToken = CharToBaseToken(Char);

			if (CurToken.Value == "\n") {
				++m_Position.Line;
				m_Position.Column = 1;
			}
			else {
				++m_Position.Column;
			}

			// 第一个Token
			if (m_Result.empty()) {
				_PushToken(CurToken);
				continue;
			}

			Token_T& Token = m_Result.back();

			// 注释开始
			if (Token.Value == "/")
			{
				// *变异：除号 --> 单行注释
				if (CurToken.Value == "/")
				{
					Token.Type = TokenType::COM_SComment;
					// 清除前面的"/"号
					Token.Value.clear();
					continue;
				}

				// *变异：除号 --> 多行注释
				else if (CurToken.Value == "*")
				{
					Token.Type = TokenType::COM_MComment;
					// 清除前面的"/"号
					Token.Value.clear();
					continue;
				}
			}

			// 单行注释内容
			else if (Token.Type == TokenType::COM_SComment)
			{
				if (CurToken.Value != "\n") {
					Token.Value += CurToken.Value;
					continue;
				}
			}

			// 多行注释内容
			else if (Token.Type == TokenType::COM_MComment)
			{
				if (Token.Value.size() >= 2 && Token.Value[Token.Value.size() - 2] == '*' && Token.Value.back() == '/') {
					// 已经结束
					// 清理"*/"
					Token.Value.pop_back();
					Token.Value.pop_back();
				}

				else {
					Token.Value += CurToken.Value;
					continue;
				}
			}

			// 整数
			else if (Token.Type == TokenType::Integer)
			{

				if (CurToken.Type == TokenType::Integer) {
					Token.Type = TokenType::Integer;
					Token.Value += CurToken.Value;
					continue;
				}

				// *变异：整数 --> 浮点数
				else if (CurToken.Type == TokenType::Dot)
				{
					Token.Type = TokenType::COM_Float;
					Token.Value += CurToken.Value;
					continue;
				}

				else if (CurToken.Type == TokenType::Word)
				{
					m_ParsingError = u8"意外得到\"" + CurToken.Value + "\"。";
					break;
				}
			}

			// 小数
			else if (Token.Type == TokenType::COM_Float)
			{
				if (CurToken.Type == TokenType::Integer) {
					Token.Value += CurToken.Value;
					continue;
				}

				else if (CurToken.Type == TokenType::Dot) {
					m_ParsingError = u8"意外得到\".\"。";
					break;
				}

				else if (CurToken.Type == TokenType::Word)
				{
					m_ParsingError = u8"意外得到\"" + CurToken.Value + "\"。";
					break;
				}
			}

			// 字符串
			else if (Token.Type == TokenType::COM_String || Token.Type == TokenType::SingleQuote || Token.Type == TokenType::DoubleQuote) {
				// 引号开始转变为字符串
				if (Token.Type != TokenType::COM_String) {
					Token.Value += CurToken.Value;
					Token.Type = TokenType::COM_String;
					continue;
				}

				const char Back = Token.Value.back();
				if (Back == '"' || Back == '\'')
				{
					Token.Value.pop_back();
				}
				else {
					if (CurToken.Type == TokenType::SingleQuote || CurToken.Type == TokenType::DoubleQuote)
					{
						if (Token.Value[0] != CurToken.Value[0]) {
							Token.Value += CurToken.Value;
							continue;
						}
						else {
							Token.Value += CurToken.Value;
							Token.Value.erase(0, 1);
							continue;
						}
					}
					// 字符串未结束，继续
					else {
						Token.Value += CurToken.Value;
						continue;
					}
				}
			}

			// 字符串拼接
			else if (Token.Type == TokenType::Dot) {
				if (CurToken.Type == TokenType::Dot) {
					Token.Type = TokenType::StrConcat;
					Token.Value += CurToken.Value;
					continue;
				}
			}

			// 字符串自拼接赋值
			else if (Token.Type == TokenType::StrConcat) {
				if (CurToken.Type == TokenType::Assign) {
					Token.Type = TokenType::StrConcatA;
					Token.Value += CurToken.Value;
					continue;
				}
			}

			// 标识符
			else if (Token.Type == TokenType::COM_Ident || Token.Type == TokenType::Word)
			{
				Token.Type = TokenType::COM_Ident;

				// 标识符后可接标识符或数字
				if (CurToken.Type == TokenType::Word || CurToken.Type == TokenType::Integer)
				{
					Token.Value += CurToken.Value;
					continue;
				}
			}
		
			// 返回值类型
			else if (Token.Type == TokenType::Assign)
			{
				if (CurToken.Type == TokenType::LTD)
				{
					Token.Type = TokenType::ResultType;
					Token.Value += CurToken.Value;
					continue;
				}
			}

			// 未处理，代表一个Token结束
			_PushToken(CurToken);
		}

		return m_ParsingError.empty();
	}

	const Array<Token_T> TokenParser_T::GetResult() const
	{
		if (!m_ParsingError.empty()) { return {}; }
		Array<Token_T> Result = m_Result;
		auto Func = [](const Token_T& Token) {
			return Token.Type == TokenType::Empty
				|| Token.Type == TokenType::Void
				|| Token.Type == TokenType::COM_SComment
				|| Token.Type == TokenType::COM_MComment;
			};
		Result.erase(std::remove_if(Result.begin(), Result.end(), Func), Result.end());
		return Result;
	}

	const Array<Token_T>& TokenParser_T::GetIntactResult() const
	{
		return m_Result;
	}

	void TokenParser_T::DebugPrint() const
	{
		auto ReplaceNewlines = [](String& Str) {
			size_t Pos = 0;
			while ((Pos = Str.find('\n', Pos)) != String::npos) {
				Str.replace(Pos, 1, "\\n");
				Pos += 2; // 跳过刚插入的'\\'和'n'
			}
			};

		for (auto& Token : m_Result) {
			String Value = Token.Value;
			ReplaceNewlines(Value);
			const Position_T& Position = Token.Position;
			const uint32_t Color = GetTokenColor(Token);
			const BYTE R = *((BYTE*)(&Color));
			const BYTE G = *((BYTE*)&Color + 1);
			const BYTE B = *((BYTE*)&Color + 2);
			printf("\033[38;2;%d;%d;%dm[%d, %d] %s \t\t %s\033[0m\n", R, G, B, Position.Line, Position.Column - 1, TokenName[Token.Type].c_str(), Value.c_str());
		}
	}

	const Position_T& TokenParser_T::GetErrorPos() const
	{
		return m_Position;
	}

	const String& TokenParser_T::GetErrorMsg() const
	{
		return m_ParsingError;
	}

	inline void TokenParser_T::_PushToken(Token_T& Token)
	{
		Token.Position = m_Position;
		m_Result.push_back(Token);
	}

	TokenType GetCharBaseTokenType(const String& Char)
	{
		const size_t CharLength = Char.size();
		if (CharLength == 0 || CharLength > 4) {
			return TokenType::Void;
		}
		if (CharLength == 1) {
			const char C = Char[0];
			if (C >= '0' && C <= '9') {
				return TokenType::Integer;
			}
			if ((C >= 'A' && C <= 'Z') || (C >= 'a' && C <= 'z')) {
				return TokenType::Word;
			}

			switch (C)
			{
			case ' ':
			case '\t':
			case '\n':
				return TokenType::Empty;
				//
			case ':':
				return TokenType::Colon;
			case ';':
				return TokenType::Semicolon;
			case '.':
				return TokenType::Dot;
			case ',':
				return TokenType::Comma;
				//
			case '\'':
				return TokenType::SingleQuote;
			case '\"':
				return TokenType::DoubleQuote;
			case '`':
				return TokenType::BackQuote;
				//
			case '=':
				return TokenType::Assign;
				//
			case '+':
				return TokenType::Add;
			case '-':
				return TokenType::Sub;
			case '*':
				return TokenType::Mul;
			case '/':
				return TokenType::Div;
			case '&':
				return TokenType::BitAnd;
			case '#':
				return TokenType::BitOr;
			case '~':
				return TokenType::BitNot;
				//
			case '(':
				return TokenType::LP;
			case ')':
				return TokenType::RP;
			case '[':
				return TokenType::LA;
			case ']':
				return TokenType::RA;
			case '{':
				return TokenType::LB;
			case '}':
				return TokenType::RB;
			case '>':
				return TokenType::LTD;
			case '<':
				return TokenType::RTD;
			}
		}
		return TokenType::Word;
	}

	Token_T CharToBaseToken(const String& Char)
	{
		Token_T Result;
		Result.Type = GetCharBaseTokenType(Char);
		Result.Value = Char;
		return Result;
	}
}