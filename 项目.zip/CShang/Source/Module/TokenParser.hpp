#ifndef TOKEN_PARSER_HPP
#define TOKEN_PARSER_HPP
#include "../Program/pch.hpp"
#include "Token.hpp"
namespace CShang
{
	class TokenParser_T
	{
	public:
		TokenParser_T() = default;
		~TokenParser_T() = default;
		// �ô���
		void SetCode(const String& Code);
		// ����
		bool Parse();
		// ȡ���
		const Array<Token_T> GetResult() const;
		// ȡ�������
		const Array<Token_T>& GetIntactResult() const;
		// �������
		void DebugPrint() const;
		// ȡ����λ��
		const Position_T& GetErrorPos() const;
		// ȡ������Ϣ
		const String& GetErrorMsg() const;

	private:
		String m_Code;
		Array<String> m_Chars; // UTF8

		Position_T m_Position;
		String m_ParsingError;

		Array<Token_T> m_Result;

		void _PushToken(Token_T& Token);
	};

	TokenType GetCharBaseTokenType(const String& Char);

	Token_T CharToBaseToken(const String& Char);
}
#endif // !TOKEN_PARSER_HPP