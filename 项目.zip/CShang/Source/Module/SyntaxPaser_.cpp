#include "SyntaxPaser.hpp"
namespace CShang
{
	void SyntaxParser_T::SetTokens(const Array<Token_T>& Tokens)
	{
		m_Tokens = Tokens;
	}

	Space_T* SyntaxParser_T::GetSpace()
	{
		return &m_Space;
	}

	const Space_T* SyntaxParser_T::GetSpace() const
	{
		return &m_Space;
	}

	bool SyntaxParser_T::Parse()
	{
		try {

			m_CurTokenIndex = SIZE_MAX;
			m_ParsingError.clear();

			if (m_Tokens.empty()) {
				throw Exception(u8"û���ṩ�κ�Token���н�����");
			}

			//while ((m_CurTokenIndex == SIZE_MAX && !m_Tokens.empty()) || m_CurTokenIndex < m_Tokens.size())
			//{
			//	/*if (!ParseCode(&m_Space)) {
			//		break;
			//	}*/
			//	
			//}
			Function_T MainFunc(&m_Space);
			ParseCode(&m_Space, &MainFunc.Body, true);

			PrintASTStructure(&MainFunc.Body);
			return true;
		}
		catch (const std::exception& e)
		{
			m_ParsingError = e.what();
			return false;
		}
	}

	const Position_T& SyntaxParser_T::GetErrorPos() const
	{
		if (m_CurTokenIndex < m_Tokens.size()) {
			return m_Tokens[m_CurTokenIndex].Position;
		}
		else {
			static const Position_T InvalidPosition{ 0, 0 };
			return InvalidPosition;
		}
	}

	const String& SyntaxParser_T::GetErrorMsg() const
	{
		return m_ParsingError;
	}

	const Token_T& SyntaxParser_T::CurToken() const
	{
		if (m_CurTokenIndex < m_Tokens.size()) {
			return m_Tokens[m_CurTokenIndex];
		}
		else {
			static const Token_T InvalidToken = { TokenType::Void, "", { 0, 0 } };
			return InvalidToken;
		}
	}

	const Token_T& SyntaxParser_T::_NextToken()
	{
		if ((m_CurTokenIndex == SIZE_MAX && !m_Tokens.empty()) || m_CurTokenIndex + 1 < m_Tokens.size()) {
			++m_CurTokenIndex;
			return m_Tokens[m_CurTokenIndex];
		}
		else {
			static const Token_T InvalidToken = { TokenType::Void, "", { 0, 0 } };
			return InvalidToken;
		}
	}

	const Token_T& SyntaxParser_T::_LastToken()
	{
		if (m_CurTokenIndex > 0 && m_CurTokenIndex <= m_Tokens.size()) {
			--m_CurTokenIndex;
			return m_Tokens[m_CurTokenIndex];
		}
		else if (m_CurTokenIndex == 0) {
			m_CurTokenIndex = SIZE_MAX;
		}
		static const Token_T InvalidToken = { TokenType::Void, "", { 0, 0 } };
		return InvalidToken;
	}

	Array<const Token_T*> SyntaxParser_T::ParseBracketKeys()
	{
		const Token_T& Begin = CurToken();
		if (Begin.Type != TokenType::LP) {
			throw Exception(u8"Ԥ��\"(\"\"��" + ERROR_MSG_BUTGOT(Begin));
		}
		Array<const Token_T*> Result;
		while (true)
		{
			const Token_T& NextToken = _NextToken();

			if (NextToken.Type != TokenType::COM_String) {
				throw Exception(u8"�����ڵļ��������ַ�����" + ERROR_MSG_BUTGOT(NextToken));
			}
			Result.push_back(&NextToken);
			const Token_T& Delimiter = _NextToken();
			if (Delimiter.Type == TokenType::Comma) {
				continue;
			}
			else if (Delimiter.Type == TokenType::RP) {
				break;
			}
		}
		return Result;
	}

	bool SyntaxParser_T::ParseCode(Space_T* Space, bool IsTopSpace)
	{
		return false;
	}

	bool SyntaxParser_T::ParseSpaceMember(Space_T* Space)
	{
		const Token_T& FirstToken = _NextToken();
		const Token_T& LastToken = _NextToken();

		_LastToken();

		if (LastToken.Type == TokenType::Colon) {
			_LastToken();
			_ParseVariable(Space);
			return true;
		}

		if (FirstToken.Type == TokenType::Void) {
			return false;
		}

		if (FirstToken.Value == u8"����") {
			_ParseFunction(Space);
		}
		else if (FirstToken.Value == u8"�ṹ") {
			_ParseStructure(Space);
		}
		else if (FirstToken.Value == u8"��") {
			_ParseClass(Space);
		}
		else if (FirstToken.Value == u8"����") {
			const SpaceMemberType T =
				Space->Parent == nullptr
				? SpaceMemberType::MainSpace
				: Space->Parent->GetMemberType();

			if (T != SpaceMemberType::Class) {
				throw Exception(u8"\"����\"ֻ��������ʹ�á�");
			}
			// �ͺ������ƣ��Ȱ���������
			_ParseFunction(Space, TAG_FUNCTION_CONSTRUCTOR);
		}
		else if (FirstToken.Value == u8"����") {
			const SpaceMemberType T =
				Space->Parent == nullptr
				? SpaceMemberType::MainSpace
				: Space->Parent->GetMemberType();

			if (T != SpaceMemberType::Class) {
				throw Exception(u8"\"����\"ֻ��������ʹ�á�");
			}
			// �ͺ������ƣ��Ȱ���������
			_ParseFunction(Space, TAG_FUNCTION_DESTRUCTOR);
		}
		else {
			throw Exception(u8"Ԥ�ڹؼ��֣�" + ERROR_MSG_BUTGOT(FirstToken));
		}
		return true;
	}

	TypeDesc_T* SyntaxParser_T::_ParseType()
	{
		const Token_T& TypeToken = _NextToken();
		if (TypeToken.Type == TokenType::COM_Ident) {
			TypeDesc_T* Type = new TypeDesc_T();
			Type->Name = TypeToken.Value;
			return Type;
		}
		throw Exception(u8"���ͱ����Ǳ�ʶ����" + ERROR_MSG_BUTGOT(TypeToken));
	}

	String SyntaxParser_T::_ParseNameAndOptions(SpaceMember_T* Member)
	{
		const Token_T& Name = _NextToken();
		if (Name.Type != TokenType::COM_Ident) {
			throw Exception(u8"Ӧ�����ʶ����" + ERROR_MSG_BUTGOT(Name));
		}
		// ��ѡ��ѡ��
		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type == TokenType::LA) {
			while (true) {
				const Token_T& NextToken = _NextToken();
				if (NextToken.Type == TokenType::RA) {
					break;
				}
				else if (NextToken.Type == TokenType::COM_Ident) {
					Array<String> Params;
					// �������Բ���
					const Token_T& AfterAttr = _NextToken();
					if (AfterAttr.Type == TokenType::LP) {
						const auto& _Params = ParseBracketKeys();
						for (const auto& Param : _Params) {
							Params.push_back(Param->Value);
						}
					}
					else if (AfterAttr.Type == TokenType::RA) {
						break;
					}
					Member->AddOption(NextToken.Value, Params);

					const Token_T& Delimiter = _NextToken();
					if (Delimiter.Type == TokenType::Comma) {
						continue;
					}
					else if (Delimiter.Type == TokenType::RA) {
						break;
					}
					else {
						throw Exception(u8"��������֮������ö��ŷָ���" + ERROR_MSG_BUTGOT(Delimiter));
					}
				}
				else {
					throw Exception(u8"�������Ա����Ǳ�ʶ����" + ERROR_MSG_BUTGOT(NextToken));
				}
			}
		}
		else {
			_LastToken();
		}

		return Name.Value;
	}

	String SyntaxParser_T::_ParseVariable(Space_T* Space, LONG_PTR Tag)
	{
		Variable_T* NewVar = new Variable_T();
		// ������
		const String Name = _ParseNameAndOptions(NewVar);

		// :
		const Token_T& Delimiter = _NextToken();
		if (Delimiter.Type != TokenType::Colon) {
			throw Exception(u8"���������������ð�ţ�" + ERROR_MSG_BUTGOT(Delimiter));
		}

		// ����
		NewVar->TypeDesc = _ParseType();

		// ������
		//// ��ѡ��������ʼֵ
		//const Token_T& Begin = _NextToken();
		//if (Begin.Type == TokenType::Assign) {
		//	const Token_T& Value = _NextToken();
		//}
		//else {
		//	_LastToken();
		//}

		Space->AddVariable(Name, NewVar);
		return Name;
	}

	void SyntaxParser_T::_ParseVariableAttributes(const String& VarName, Variable_T** pVariable)
	{
	}

	void SyntaxParser_T::_ParseFunction(Space_T* Space, LONG_PTR Tag)
	{
		Function_T* NewFunc = new Function_T(Space);
		NewFunc->Tag = Tag;
		// ������
		const String Name = _ParseNameAndOptions(NewFunc);

		// �����б�
		_ParseFunctionParams(NewFunc);

		// ���Դ�ӡ����
#ifdef TEST_DEBUGPRINT
		printf(u8"�����б���\n");
		for (const auto& Param : NewFunction->GetParams())
		{
			if (Param.second.empty()) {
				const TypeDescType TypeDesc = Param.first->GetType();
				switch (TypeDesc)
				{
				case TypeDescType::Named: {
					const TypeDescNamed_T* NamedType = dynamic_cast<const TypeDescNamed_T*>(Param.first);
					printf("Param: TypeDesc: %s, Name: <anonymous>\n", NamedType->GetTypeName().c_str());
					break;
				}
				default:
					printf("Param: TypeDesc: UnknownType, Name: <anonymous>\n");
					break;
				}
			}
			else {
				const TypeDescType TypeDesc = Param.first->GetType();
				switch (TypeDesc)
				{
				case TypeDescType::Named: {
					const TypeDescNamed_T* NamedType = dynamic_cast<const TypeDescNamed_T*>(Param.first);
					printf("Param: TypeDesc: %s, Name: %s\n", NamedType->GetTypeName().c_str(), Param.second.c_str());
					break;
				}
				default:
					printf("Param: TypeDesc: UnknownType, Name: %s\n", Param.second.c_str());
					break;
				}
			}
		}
#endif
		// �������
		const Token_T& Delimiter = _NextToken();
		if (Delimiter.Type == TokenType::Colon) {
			NewFunc->ResultType = _ParseType();
		}
		else {
			_LastToken();
		}

		const Token_T& NextToken = _NextToken();
		_LastToken();
		if (NextToken.Type == TokenType::LB) {
			_ParseFunctionBody(NewFunc);
		}

		// const String Symbol = Space->GetAccessName() +  + "@" +
		Space->Functions[Name].push_back(NewFunc);
	}

	void SyntaxParser_T::_ParseFunctionParams(Function_T* Function)
	{
		// (
		const Token_T& LeftBracket2 = _NextToken();
		if (LeftBracket2.Type != TokenType::LP) {
			throw Exception(u8"������������������ţ�" + ERROR_MSG_BUTGOT(LeftBracket2));
		}

		while (true)
		{
			if (_NextToken().Type == TokenType::RP) { break; }
			else { _LastToken(); }

			_ParseFunctionParam(Function);
			const Token_T& Token = _NextToken();
			if (Token.Type == TokenType::Comma) {
				continue;
			}
			else if (Token.Type == TokenType::RP) {
				break;
			}
			else {
				throw Exception(u8"��������֮������ö��ŷָ���" + ERROR_MSG_BUTGOT(Token));
			}
		}
	}

	void SyntaxParser_T::_ParseFunctionParam(Function_T* Function)
	{
		const Token_T& Begin = _NextToken();
		const Token_T& Next = _NextToken();
		// �����Ĳ���
		if (Next.Type == TokenType::Colon)
		{
			if (Begin.Type != TokenType::COM_Ident) {
				throw Exception(u8"���������������Ǳ�ʶ����" + ERROR_MSG_BUTGOT(Begin));
			}
			TypeDesc_T* Type = Type = _ParseType();
			Function->AddParam(Type, Begin.Value);
		}
		// ռλ��δ��������
		else {
			_LastToken();
			_LastToken();
			TypeDesc_T* Type = Type = _ParseType();
			Function->AddParam(Type);
		}
	}

	void SyntaxParser_T::_ParseFunctionBody(Function_T* Function)
	{
		const Token_T& Begin = _NextToken();
		if (Begin.Type != TokenType::LB) {
			throw Exception(u8"Ԥ�ڡ�{����" + ERROR_MSG_BUTGOT(Begin));
		}
		CodeBlock_T* Block = &Function->Body;
		ParseCode(&m_Space, Block);
		//ParseASTNodes(Body);
		for (const auto& Node : Block->GetSubNodes()) {
			if (Node->GetType() == ASTNodeType::LocalVariable) {
				LocalVariable_T* Variable = dynamic_cast<LocalVariable_T*>(Node);
				Variable_T* VarObj = new Variable_T();
				{
					TypeDesc_T* TD = new TypeDesc_T();
					{
						TD->Name = Variable->GetDefType();
					}
					VarObj->TypeDesc = TD;
				}
				const String Name = Variable->GetDefName();
				Function->Space.AddVariable(Name, VarObj);
			}
		}
		PrintASTStructure(Block);
	}

	void SyntaxParser_T::_ParseStructure(Space_T* Space)
	{
		Structure_T* NewStructure = new Structure_T(Space);
		// �ṹ��
		const String Name = _ParseNameAndOptions(NewStructure);
		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type != TokenType::LB) {
			throw Exception(u8"Ԥ�ڡ�{����" + ERROR_MSG_BUTGOT(LeftBracket));
		}
		while (true) {
			_ParseVariable(&NewStructure->Space);
			const Token_T& NextToken = _NextToken();
			if (NextToken.Type == TokenType::RB) {
				break;
			}
			else if (NextToken.Type != TokenType::Comma) {
				throw Exception(u8"Ԥ�ڡ�,����" + ERROR_MSG_BUTGOT(LeftBracket));
			}
		}
		Space->Structures[Name] = NewStructure;
	}

	void SyntaxParser_T::_ParseClass(Space_T* Space)
	{
		Class_T* NewClass = new Class_T(Space);
		// ����
		const String Name = _ParseNameAndOptions(NewClass);

		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type != TokenType::LB) {
			throw Exception(u8"Ԥ�ڡ�{����" + ERROR_MSG_BUTGOT(LeftBracket));
		}
		while (true) {
			const Token_T& NextToken = _NextToken();
			if (NextToken.Type == TokenType::RB) {
				break;
			}
			else {
				_LastToken();
			}
			if (!ParseSpaceMember(&NewClass->Space)) {
				throw Exception(u8"�����β��");
			}
		}
		Space->Classes[Name] = NewClass;
	}

	static bool IsAtomicToken(const Token_T& Tk)
	{
		static Set<TokenType> Atomics
		{
			TokenType::COM_Ident,
			TokenType::COM_Integer,
			TokenType::LP
		};
		return Atomics.find(Tk.Type) != Atomics.end();
	}

	static BinaryExpression_T* RecursiveBinaryGetRoot(BinaryExpression_T* Binary)
	{
		if (Binary->Right && Binary->Right->GetType() == ASTNodeType::BinaryExpression) {
			return RecursiveBinaryGetRoot((BinaryExpression_T*)Binary->Right);
		}
		return Binary;
	}

	static bool IsPriorityHigh(BinOp_E A, BinOp_E B)
	{
		static Map<BinOp_E, int> Prioritys
		{
			{ BinOp_E::Mul, 1 },
			{ BinOp_E::Div, 1 },

			{ BinOp_E::Add, 2 },
			{ BinOp_E::Sub, 2 },

			{ BinOp_E::And, 3 },
			{ BinOp_E::Or, 3 },
			{ BinOp_E::Xor, 3 },

			{ BinOp_E::Assign, 4 }
		};
		return Prioritys[A] < Prioritys[B];
	}

	// �������һ�����ȼ��͵Ľڵ㣨���Ҳ���У�
	static BinaryExpression_T* FindLastPriorityLowRootBinary(BinaryExpression_T* Binary, BinOp_E Op)
	{
		if (!IsPriorityHigh(Op, Binary->Operator)) {
			return nullptr;
		}
		if (Binary->Right && Binary->Right->GetType() == ASTNodeType::BinaryExpression) {
			BinaryExpression_T* Right = (BinaryExpression_T*)Binary->Right;
			BinaryExpression_T* Result = FindLastPriorityLowRootBinary(Right, Op);
			if (Result) {
				return Result;
			}
			if (IsPriorityHigh(Op, Right->Operator)) {
				return nullptr;
			}
		}
		return Binary;
	}

	static BinOp_E TokenTypeToBinOp(TokenType Type)
	{
		switch (Type) {
		case TokenType::Add: return BinOp_E::Add;
		case TokenType::Sub: return BinOp_E::Sub;
		case TokenType::Mul: return BinOp_E::Mul;
		case TokenType::Div: return BinOp_E::Div;

		case TokenType::BitAnd: return BinOp_E::And;
		case TokenType::BitOr:  return BinOp_E::Or;
		case TokenType::BitXor: return BinOp_E::Xor;

		case TokenType::Assign: return BinOp_E::Assign;
		}
		return BinOp_E::Unknown;
	}

	void SyntaxParser_T::ParseCode(Space_T* Space, CodeBlock_T* Block, bool IsTopSpace)
	{
		// ��һ��token�Ƿ�Ϊԭ��
		bool LastIsAtomic = false;
		
		while (true) {

			const Token_T& Token = _NextToken();
			if (Token.Type == TokenType::LB) {
				CodeBlock_T* Block = new CodeBlock_T();
				ParseCode(Space, Block);
				Block->AddSubNode(Block);
			}

			//if (Token.Type == TokenType::LP) {
			//	// ���������ڵı���ʽ
			//	ASTNode_T* parenExpr = ParseExpression(Space);

			//	// ������һ��token��������
			//	const Token_T& nextToken = _NextToken();
			//	if (nextToken.Type != TokenType::RP) {
			//		throw Exception(u8"����������");
			//	}

			//	OnAtomic(Block, parenExpr);
			//	LastIsAtomic = true;  // ���ű���ʽ������һ��ԭ��
			//	continue;
			//}

			if (Token.Type == TokenType::RB || IsTopSpace && Token.Type == TokenType::Void) {
				Block->ConverTempNodesToFormal();
				break;
			}

			// TODO: δ��������
			using Process = void(SyntaxParser_T::*)(Space_T* Space, LONG_PTR Tag);
			static Map<String, Process> KeywordProcess{
				//{ u8"����", &SyntaxParser_T::_ParseVariable },
				{ u8"����", &SyntaxParser_T::_ParseFunction },
				//{ u8"�ṹ", &SyntaxParser_T::_ParseFunction },
			};

			if (Token.Type == TokenType::COM_Ident) {
				Process Proc = KeywordProcess[Token.Value];
				if (Proc) {
					(this->*Proc)(Space, 0);
					return;
				}
			}

			bool CurIsAtomic = IsAtomicToken(Token);

			if (LastIsAtomic && CurIsAtomic ||
				LastIsAtomic && Token.Type == TokenType::LP) {
				// ����2��ԭ�ӣ��м��޷��ţ��޷����ӵ�һ��ת��������ʱ�ڵ�
				Block->ConverTempNodesToFormal();
			}
			LastIsAtomic = CurIsAtomic;

			switch (Token.Type)
			{
			case TokenType::COM_Ident: {
				Identifier_T* Ident = new Identifier_T();
				Ident->Name = Token.Value;
				OnAtomic(Block, Ident);
				break;
			}
			case TokenType::COM_Integer: {
				LiteralInteger_T* Int = new LiteralInteger_T();
				Int->Value = std::stoull(Token.Value);
				OnAtomic(Block, Int);
				break;
			}

			case TokenType::Add:
			case TokenType::Sub:
			case TokenType::Mul:
			case TokenType::Div:
			case TokenType::BitAnd:
			case TokenType::BitOr:
			case TokenType::BitXor:
			case TokenType::Assign:
			{
				BinaryExpression_T* Bin = new BinaryExpression_T();
				Bin->Operator = TokenTypeToBinOp(Token.Type);
				OnBinary(Block, Bin);
				break;
			}
			default:
				if (Token.Value.empty()) {
					throw Exception(u8"�����β��");
				}
				else {
					throw Exception(u8"����֧�ֵ�token����" + Token.Value + u8"��");
				}
			}
		}
	}

	void SyntaxParser_T::ParseExpression(CodeBlock_T* Block)
	{
	}

	void SyntaxParser_T::OnAtomic(CodeBlock_T* Block, ASTNode_T* Node)
	{
		ASTNode_T* Back = Block->GetBack();
		if (Back) {
			// ���β���нڵ㣬�����Ƕ�Ԫ����ʽ����ݹ��������ʽ���ڿ��е��Ҹ��ڵ����ԭ��
			if (Back->GetType() == ASTNodeType::BinaryExpression) {
				BinaryExpression_T* Root = RecursiveBinaryGetRoot((BinaryExpression_T*)Back);
				if (Root->Right) {
					throw Exception(u8"�ڲ�����");
				}
				Root->Right = Node;
			}
			else {
				throw Exception(u8"��δ֧��");
			}
			return;
		}
		Block->PushTempNode(Node);
	}

	void SyntaxParser_T::OnBinary(CodeBlock_T* Block, BinaryExpression_T* Binary)
	{
		ASTNode_T* Back = Block->GetBack();
		if (Back == nullptr) {
			throw Exception(u8"��߲���Ϊ�ա�");
		}
		// ���һ����ʱ�ڵ��Ƕ�Ԫ����ʽ
		if (Back->GetType() == ASTNodeType::BinaryExpression) {
			auto Root = FindLastPriorityLowRootBinary((BinaryExpression_T*)Back, Binary->Operator);
			if (Root) {
				Binary->Left = Root->Right;
				Root->Right = Binary;
				return;
			}
		}
		Binary->Left = Back;
		Block->PopBack();
		Block->PushTempNode(Binary);
	}
}