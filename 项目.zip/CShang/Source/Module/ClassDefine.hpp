﻿#ifndef CLASS_DEFINE_HPP
#define CLASS_DEFINE_HPP
#include "../Program/pch.hpp"
#include "AST.hpp"
namespace CShang
{
	/*
	* 将某个空间成员（变量，函数，类等）添加到总空间对象(Space_T*)中，
	* 空间对象在析构时会将它全部的成员都delete
	*/

	constexpr LONG_PTR TAG_FUNCTION_CONSTRUCTOR = 1;
	constexpr LONG_PTR TAG_FUNCTION_DESTRUCTOR = 2;

	class Entry_T
	{
	public:
		LONG_PTR Tag = 0;
		void* Hint = nullptr;
	};
	class SpaceMember_T;
	class Variable_T;
	class Function_T;
	class Structure_T;
	class Class_T;

	/*========================类型描述符========================*/

	enum class TypeDescType
	{
		Unknown,
		Base,
		Struct,
		Enum,
		Class
	};

	/*============TypeDesc_T============*/
	// 类型描述符
	class TypeDesc_T;
	using PTypeDesc = std::shared_ptr<TypeDesc_T>;

	class TypeDesc_T
	{
	public:
		static PTypeDesc Create(const String& Name);
		String Name;
		TypeDescType Type = TypeDescType::Unknown;
		SpaceMember_T* DefinitionPtr = nullptr;
		size_t GetSize() const;
	};
	
	

	/*============Space_T============*/
	// 空间
	class Space_T : public Entry_T
	{
	public:
		Space_T() = default;
		~Space_T();
		String Name;
		SpaceMember_T* Parent = nullptr;
		
		// 函数可能重载，存储做特殊处理
		Map<String, Array<Function_T*>> Functions;
		Map<String, Structure_T*> Structures;
		Map<String, Class_T*> Classes;

		String GetAccessName() const;

		void AddVariable(const String& VarName, Variable_T* VarObj);
		Variable_T* FindVariable(const String& VarName) const;
		const Array<Pair<String, Variable_T*>>& GetVariables() const;

	private:
		// 变量必须有顺序
		Array<Pair<String, Variable_T*>> m_Variables;
	};

	/*============SpaceMember_T============*/

	enum class SpaceMemberType
	{
		Unknown,
		MainSpace,
		Variable,
		Function,
		Class,
		Structure,
		Enum,
	};
	
	// 所有成员基类
	class SpaceMember_T : public Entry_T
	{
	public:
		SpaceMember_T(Space_T* ParentSpace = nullptr);
		virtual ~SpaceMember_T() = default;
		SpaceMemberType GetMemberType() const;

		/*void SetName(const String& Name);
		const String& GetName() const;*/

		void AddOption(const String& Option, const Array<String>& Params = {});
		const Array<String>* GetOption(const String& Option) const;
		const Map<String, Array<String>>& GetOptions() const;

		Space_T* Parent = nullptr;

	protected:
		//String m_Name;
		SpaceMemberType m_MemberType;
		// Map<选项名, Array<选项参数>>
		Map<String, Array<String>> m_Options; // 选项
	};

	/*============Function_T============*/
	// 函数基类
	class Function_T : public SpaceMember_T
	{
	public:
		Function_T(Space_T* Owner);
		virtual ~Function_T() = default;

		Space_T Space;
		CodeBlock_T Body;
		// 参数
		void AddParam(PTypeDesc Type, const String& Name = "");
		const Array<Pair<String, Variable_T*>>& GetParams() const;
		// 结果
		void AddResult(PTypeDesc Type, const String& Name = "");
		const Array<Pair<String, Variable_T*>>& GetResults() const;

		Pair<Variable_T*, size_t> GetParamObjAndOffset(const String& Name) const;
		size_t GetParamOffset(const String& Name) const;
		Variable_T* FindParam(const String& Name) const;

		String GetFeatureDesc() const;

	private:
		Array<Pair<String, Variable_T*>> m_Params;
		Array<Pair<String, Variable_T*>> m_Results;
	};

	/*============Function_T============*/
	// 变量
	class Variable_T : public SpaceMember_T
	{
	public:
		Variable_T();
		~Variable_T() = default;

		PTypeDesc TypeDesc;
	};

	/*============Structure_T============*/
	class Structure_T : public SpaceMember_T
	{
	public:
		Structure_T(Space_T* Owner);
		~Structure_T() = default;

		Space_T Space;
		size_t GetMemberVarOffset(const String& Name) const;
	};

	/*============Class_T============*/
	// 类
	class Class_T : public SpaceMember_T
	{
	public:
		Class_T(Space_T* Owner);
		~Class_T() = default;
		
		Space_T Space;
		Array<Function_T*> GetConstructors() const;
		Array<Function_T*> GetDestructors() const;
	};
}
#endif // !CLASS_DEFINE_HPP