﻿#include "AST.hpp"
#include "ClassDefine.hpp"
namespace CShang
{
	/*============ASTNode_T============*/

	ASTNodeType ASTNode_T::GetType() const
	{
		return m_Type;
	}

	void ASTNode_T::SetTag(LONG_PTR Tag)
	{
		m_Tag = Tag;
	}

	LONG_PTR ASTNode_T::GetTag() const
	{
		return m_Tag;
	}

	/*============CodeBlock_T============*/

	CodeBlock_T::CodeBlock_T()
	{

		m_Type = ASTNodeType::CodeBlock;
		Space = new Space_T();
	}

	CodeBlock_T::~CodeBlock_T()
	{
		delete Space;
	}

	void CodeBlock_T::AddTempNode(ASTNode_T* Node)
	{
		m_TempNodes.push_back(Node);
	}

	ASTNode_T* CodeBlock_T::GetTempBack() const
	{
		if (m_TempNodes.empty()) {
			return nullptr;
		}
		return m_TempNodes.back();
	}

	void CodeBlock_T::PopTempBack()
	{
		if (m_TempNodes.empty()) {
			return;
		}
		m_TempNodes.pop_back();
	}

	const Array<ASTNode_T*>& CodeBlock_T::GetSubNodes() const
	{
		return m_SubNodes;
	}

	ASTNode_T* CodeBlock_T::GetSubBack() const
	{
		if (m_SubNodes.empty()) {
			return nullptr;
		}
		return m_SubNodes.back();
	}

	void CodeBlock_T::FormatTempNodes()
	{
		for (auto* Temp : m_TempNodes) {
			m_SubNodes.push_back(Temp);
		}
		m_TempNodes.clear();
	}

	/*============Identifier_T============*/

	Identifier_T::Identifier_T()
	{
		m_Type = ASTNodeType::Identifier;
	}

	void Identifier_T::SetName(const String& _Name)
	{
		Name = _Name;
	}

	const String& Identifier_T::GetName() const
	{
		return Name;
	}

	/*============LiteralInteger_T============*/

	LiteralInteger_T::LiteralInteger_T()
	{
		m_Type = ASTNodeType::LiteralInteger;
	}

	void LiteralInteger_T::SetValue(int64_t Value)
	{
		Value = Value;
	}

	int64_t LiteralInteger_T::GetValue() const
	{
		return Value;
	}

	/*============LiteralString_T============*/

	LiteralString_T::LiteralString_T()
	{
		m_Type = ASTNodeType::LiteralString;
	}

	void LiteralString_T::SetValue(const String& _Value)
	{
		Value = _Value;
	}

	const String& LiteralString_T::GetValue() const
	{
		return Value;
	}

	/*============CallingStatement_T============*/

	CallingStatement_T::CallingStatement_T()
	{
		m_Type = ASTNodeType::CallingStatement;
	}

	void CallingStatement_T::SetSource(const ASTNode_T* Node)
	{
		Source = Node;
	}

	const ASTNode_T* CallingStatement_T::GetSource() const
	{
		return Source;
	}

	void CallingStatement_T::AddParam(const ASTNode_T* Node)
	{
		m_Params.push_back(Node);
	}

	const Array<const ASTNode_T*>& CallingStatement_T::GetParams() const
	{
		return m_Params;
	}

	/*============BinaryExpression_T============*/

	BinaryExpression_T::BinaryExpression_T()
	{
		m_Type = ASTNodeType::BinaryExpression;
	}

	/*============FourBinExpression_T============*/

	FourBinExpression_T::FourBinExpression_T()
	{

	}

	/*============BitBinExpression_T============*/

	BitBinExpression_T::BitBinExpression_T()
	{
	}

	/*============AssignStatement_T============*/

	AssignStatement_T::AssignStatement_T()
	{
		Operator = BinOp_E::Assign;
	}

	/*============MemberAccess_T============*/

	MemberAccess_T::MemberAccess_T()
	{
		Operator = BinOp_E::MAcc;
	}

	/*============StringConcat_T============*/

	StringConcat_T::StringConcat_T()
	{
		m_Type = ASTNodeType::StringConcat;
	}

	// 打印AST结构的辅助函数
	void PrintASTStructure(const ASTNode_T* Node, const std::string& prefix, bool isLast, bool isRoot)
	{
		if (!Node) { return; }

		// 当前节点的前缀和连接线
		if (!isRoot) {
			std::cout << prefix;
			std::cout << (isLast ? u8"\033[34m└── \033[0m" : u8"\033[34m├── \033[0m");
		}

		// 打印节点类型
		std::cout << "\033[32m"; // 设置节点类型的颜色为绿色
		switch (Node->GetType())
		{
		case ASTNodeType::CodeBlock:
			std::cout << "CodeBlock";
			break;
		case ASTNodeType::Identifier:
			std::cout << "Identifier";
			std::cout << "\033[0m"; // 重置颜色
			if (const Identifier_T* ident = dynamic_cast<const Identifier_T*>(Node)) {
				std::cout << " \033[33mName: \"" << ident->GetName() << "\"\033[0m"; // 设置标识符名称的颜色为黄色
			}
			break;
		case ASTNodeType::LiteralInteger:
			std::cout << "LiteralInteger";
			std::cout << "\033[0m"; // 重置颜色
			if (const LiteralInteger_T* integer = dynamic_cast<const LiteralInteger_T*>(Node)) {
				std::cout << " \033[31mValue: " << integer->GetValue() << "\033[0m"; // 设置整数值的颜色为红色
			}
			break;
		case ASTNodeType::LiteralString:
			std::cout << "LiteralString";
			std::cout << "\033[0m"; // 重置颜色
			if (const LiteralString_T* str = dynamic_cast<const LiteralString_T*>(Node)) {
				std::cout << " \033[33mValue: \"" << str->GetValue() << "\"\033[0m"; // 设置字符串值的颜色为黄色
			}
			break;
		case ASTNodeType::CallingStatement:
			std::cout << "CallingStatement";
			break;
		case ASTNodeType::BinaryExpression:
			switch (dynamic_cast<const BinaryExpression_T*>(Node)->Operator)
			{
			case BinOp_E::Unknown:	std::cout << "Unknown";	break;
			case BinOp_E::Add:		std::cout << "Add";		break;
			case BinOp_E::Sub:		std::cout << "Sub";		break;
			case BinOp_E::Mul:		std::cout << "Mul";		break;
			case BinOp_E::Div:		std::cout << "Div";		break;
			case BinOp_E::And:		std::cout << "And";		break;
			case BinOp_E::Or:		std::cout << "Or";		break;
			case BinOp_E::Xor:		std::cout << "Xor";		break;
			case BinOp_E::Assign:	std::cout << "Assign";	break;
			case BinOp_E::MAcc:	std::cout << "MemberAccess";	break;
			}
			break;
		case ASTNodeType::StringConcat:
			std::cout << "StringConcat";
			break;
		default:
			std::cout << "Unknown";
			break;
		}
		std::cout << std::endl;

		// 收集子节点
		Array<const ASTNode_T*> subNodes;

		// 特殊处理不同类型的节点
		switch (Node->GetType()) {
		case ASTNodeType::CodeBlock:
			if (const CodeBlock_T* block = dynamic_cast<const CodeBlock_T*>(Node)) {
				// 添加语句作为子节点
				for (const auto& statement : block->GetSubNodes()) {
					subNodes.push_back(statement);
				}
			}
			break;
		case ASTNodeType::CallingStatement:
			if (const CallingStatement_T* call = dynamic_cast<const CallingStatement_T*>(Node)) {
				if (call->GetSource()) {
					subNodes.push_back(call->GetSource());
				}
				// 添加参数作为子节点
				for (const auto& param : call->GetParams()) {
					subNodes.push_back(param);
				}
			}
			break;
		case ASTNodeType::BinaryExpression:
			if (const BinaryExpression_T* binary = dynamic_cast<const BinaryExpression_T*>(Node)) {
				if (binary->Left) {
					subNodes.push_back(binary->Left);
				}
				if (binary->Right) {
					subNodes.push_back(binary->Right);
				}
			}
			break;
		case ASTNodeType::StringConcat:
			if (const StringConcat_T* strconcat = dynamic_cast<const StringConcat_T*>(Node)) {
				if (strconcat->Left) {
					subNodes.push_back(strconcat->Left);
				}
				if (strconcat->Right) {
					subNodes.push_back(strconcat->Right);
				}
			}
			break;
		}
		// 递归打印子节点
		std::string newPrefix = prefix + (isLast ? u8"    " : u8"\033[34m│   \033[0m");

		for (size_t i = 0; i < subNodes.size(); ++i) {
			PrintASTStructure(subNodes[i], newPrefix, i == subNodes.size() - 1, false);
		}
	}
}