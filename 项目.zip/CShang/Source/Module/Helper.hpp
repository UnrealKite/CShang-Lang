﻿#ifndef HELPER_HPP
#define HELPER_HPP
#include "../Program/pch.hpp"
namespace CShang
{
    String Utf8ToAnsi(const String& UTF8);
    WString Utf8ToUtf16(const String& UTF8);
    WString Utf8ToWide(const String& UTF8);
    Array<String> SplitUTF8(const String& UTF8);

    Array<BYTE> HexToBin(const std::string& Hex);
    String BinToHex(const Array<BYTE>& Data);
    void InsertBin(Array<BYTE>& Data, const Array<BYTE>& Bin);
    void AppendBin(Array<BYTE>& Data, const Array<BYTE>& Bin);
    void InsertHex(Array<BYTE>& Data, const String& Hex);
    void AppendHex(Array<BYTE>& Data, const String& Hex);
	void AppendRaw(Array<BYTE>& Data, const void* Buffer, size_t Size);
    String I32ToHex(__int32 Value);

    const String B64Table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const String B64Table_UrlSecurity = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    const String B64Table_S7V1 = "Vg21WQ5KdRt0yNpcr9m4O3PoHaZvsLeCY8FjSwiTkUbuEBIJlAG7fqXM6xDnzh-;";
    const String B64Table_S7V2 = "NpcVg21KdRWQ5t0ysLer9mPoH4O3aZvEBIwxTJ6X8FjSkUbuiGCqMlfYA7Dnzh-;";
    const String MyB64Table = "4YIrsWXm3uPxUZR+QOveiNp/MkGf8S2LVK7nJ9C0o6B5tTahqbz1wjlydFDgEcAH";

    String Base64Encode(const Array<BYTE>& Data, const String& Table);
    Array<BYTE> Base64Decode(const String& B64, const String& Table);
}
#endif // !HELPER_HPP
