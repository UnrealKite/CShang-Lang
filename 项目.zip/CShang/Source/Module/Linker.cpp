﻿#include "Linker.hpp"
#include "Helper.hpp"
namespace CShang
{
	static size_t GetAlignFillSize(size_t DataSize, size_t AlignSize)
	{
		// 如果对齐粒度为 0，直接返回 0（避免除零错误）
		if (AlignSize == 0) { return 0; }
		// 计算需要填充的字节数
		size_t Remainder = DataSize % AlignSize;
		if (Remainder == 0) {
			return 0; // 如果已经对齐，不需要填充
		}
		else {
			return AlignSize - Remainder; // 否则，返回需要填充的字节数
		}
	}

	Linker_T::Linker_T()
	{
		m_OutputFullPath = "";

		ZeroMemory(&m_DOS_Header, sizeof(m_DOS_Header));
		m_DOS_Stub.clear();
		ZeroMemory(&m_DOS_Header, sizeof(m_DOS_Header));
		m_Sections.clear();


		SetSubSystem(IMAGE_SUBSYSTEM_WINDOWS_CUI);


		SetFileAlignment(0x200);     // 512
		SetMemoryAlignment(0x1000);  // 4096
		SetSectionAlignment(0x200);  // 512
		SetImageBase(0x400000);
	}

	Linker_T::~Linker_T()
	{
	}

	bool Linker_T::WriteToFile()
	{
		OutFile File;
		File.open(Utf8ToWide(m_OutputFullPath), std::ios::binary);
		File.write((const char*)m_Buffer.data(), m_Buffer.size());
		File.close();
		return true;
	}

	void Linker_T::AppendDOSHeader()
	{
		// MZ
		m_DOS_Header.e_magic = IMAGE_DOS_SIGNATURE;
		// 文件总大小 / 512的余数
		m_DOS_Header.e_cblp = 0;
		// 文件总大小 / 512的商
		m_DOS_Header.e_cp = 0;
		// 0不用管
		m_DOS_Header.e_crlc = 0;
		// 如果 e_cparhdr 的值是10，那么可选头的大小就是10乘以16字节，即160字节
		m_DOS_Header.e_cparhdr = 4;
		// PE文件在加载时所需的最小额外段数，现代PE文件通常设置为0
		m_DOS_Header.e_minalloc = 0;
		// PE文件在加载时所需的最大额外段数，现代PE文件通常设置为0xFFFF，表示无限制
		m_DOS_Header.e_maxalloc = 0xFFFF;
		// 在DOS程序的上下文中，堆栈段寄存器SS用于指向程序的堆栈区域，现代PE文件通常设置为0
		m_DOS_Header.e_ss = 0;
		// 字段的值通常是一个偏移量，表示程序堆栈顶部的初始位置，现代PE文件通常设置为0
		m_DOS_Header.e_sp = 0;
		// 这个值用于DOS环境下对程序文件进行简单的完整性校验
		m_DOS_Header.e_csum = 0;
		// DOS可执行文件的初始指令指针
		m_DOS_Header.e_ip = 0;
		// DOS可执行文件的初始cs寄存器值
		m_DOS_Header.e_cs = 0;
		// 文件中重定位表的文件地址
		m_DOS_Header.e_lfarlc = 0;
		// 覆盖号这个字段在DOS可执行文件中用于指示程序的覆盖部分
		m_DOS_Header.e_ovno = 0;
		// 每个元素的初始值通常被设置为0这些字段在DOS可执行文件中没有特定的用途，保留
		ZeroMemory(&m_DOS_Header.e_res, sizeof(m_DOS_Header.e_res));
		// OEM标识符这个字段用于标识创建可执行文件的原始设备制造商或编译器
		m_DOS_Header.e_oemid = 0;
		m_DOS_Header.e_oeminfo = 0;
		// 每个元素的初始值通常被设置为0这些字段在DOS可执行文件中没有特定的用途，保留
		ZeroMemory(&m_DOS_Header.e_res2, sizeof(m_DOS_Header.e_res2));
		// 指向PE头
		m_DOS_Header.e_lfanew = 128;

		AppendRaw(m_Buffer, &m_DOS_Header, sizeof(m_DOS_Header));
	}

	void Linker_T::AppendDOSStub()
	{
		m_DOS_Stub.clear();
		// 0E 1F BA 0E 00    mov dx,E       ; 将立即数0xE移动到dx寄存器
		// B4 09             mov ah,9       ; 将立即数0x9移动到ah寄存器
		// CD 21             int 21         ; 调用中断0x21，ah = 0x9表示输出字符串功能
		// B8 01 4C          mov ax,4C01    ; 将立即数0x4C01移动到AX寄存器
		// CD 21             int 21         ; 调用中断0x21，ah = 0x4C表示退出程序功能
		
		AppendHex(m_DOS_Stub, "0E 1F BA 0E 00 B4 09 CD 21 B8 01 4C CD 21");

		// ASCII: This program cannot be run in DOS mode.
		AppendHex(m_DOS_Stub, "54 68 69 73 20 70 72 6F 67 72 61 6D 20 63 61 6E 6E 6F 74 20 62 65 20 72 75 6E 20 69 6E 20 44 4F 53 20 6D 6F 64 65 2E");
		/*
		0D 0D 0A：
		这是两个回车符 (0D) 和一个换行符 (0A)。在 DOS 中，0D 0A 是标准的行结束序列（回车换行）。这里有两个回车，可能是为了在显示后多留一个空行。
		24：$ 字符。这是至关重要的，因为之前调用的 AH=09（打印字符串）功能要求字符串必须以 $ 符号作为结束符。
		*/
		AppendHex(m_DOS_Stub, "0D" "0D 0A" "24" "00 00 00 00 00 00 00");

		AppendBin(m_Buffer, m_DOS_Stub);
	}

	void Linker_T::AppendNTHeader()
	{
		// PE\0\0
		m_NT_Header.Signature = IMAGE_NT_SIGNATURE;
		// 目标CPU类型
		m_NT_Header.FileHeader.Machine = IMAGE_FILE_MACHINE_I386;
		// 节数量
		m_NT_Header.FileHeader.NumberOfSections = m_Sections.size();
		// 编译时间戳
		m_NT_Header.FileHeader.TimeDateStamp = 0;
		// 符号表指针
		m_NT_Header.FileHeader.PointerToSymbolTable = 0;
		// 符号表数量
		m_NT_Header.FileHeader.NumberOfSymbols = 0;
		// AI: 在32位 PE 文件中，IMAGE_OPTIONAL_HEADER 的大小通常是 224 字节（0xE0），而在64位 PE 文件中，大小通常是 240 字节（0xF0）
		m_NT_Header.FileHeader.SizeOfOptionalHeader = 224;
		// 无注释
		m_NT_Header.FileHeader.Characteristics = IMAGE_FILE_EXECUTABLE_IMAGE | IMAGE_FILE_LARGE_ADDRESS_AWARE | IMAGE_FILE_32BIT_MACHINE;

		// 对于 32 位 PE 文件，Magic 字段的值通常为 0x010B，而对于 64 位 PE32+ 文件，该值为 0x020B
		m_NT_Header.OptionalHeader.Magic = IMAGE_NT_OPTIONAL_HDR32_MAGIC;
		// 链接器的主版本号和次版本号
		m_NT_Header.OptionalHeader.MajorLinkerVersion = 0;
		m_NT_Header.OptionalHeader.MinorLinkerVersion = 0;
		// 代码段（.text 段）的大小，以字节为单位
		m_NT_Header.OptionalHeader.SizeOfCode = 0x200;
		// 初始化数据段（通常指的是 .data 段）的大小，以字节为单位
		m_NT_Header.OptionalHeader.SizeOfInitializedData = 0;
		// 未初始化数据段（通常指的是 .bss 段）的大小，以字节为单位
		m_NT_Header.OptionalHeader.SizeOfUninitializedData = 0;
		// ★程序入口点（相对位置）
		m_NT_Header.OptionalHeader.AddressOfEntryPoint;// = 0x1000;
		// 可执行文件中代码段（通常是 .text 段）的首选基地址
		m_NT_Header.OptionalHeader.BaseOfCode = 0;
		// 指定数据段（通常是 .data 段）在内存中的首选基地址
		m_NT_Header.OptionalHeader.BaseOfData = 0;
		// 加载到的虚拟位置
		m_NT_Header.OptionalHeader.ImageBase;
		// 各个节（section）在内存中的对齐大小
		m_NT_Header.OptionalHeader.SectionAlignment = m_MemoryAlignment;
		// PE 文件中各个节（section）在磁盘上的对齐大小
		m_NT_Header.OptionalHeader.FileAlignment = m_FileAlignment;

		// 所要求的最低操作系统版本的版本号
		m_NT_Header.OptionalHeader.MajorOperatingSystemVersion = 6;
		m_NT_Header.OptionalHeader.MinorOperatingSystemVersion = 0;
		// 镜像版本号
		m_NT_Header.OptionalHeader.MajorImageVersion = 1;
		m_NT_Header.OptionalHeader.MinorImageVersion = 1;
		// 所依赖的子系统的版本号
		m_NT_Header.OptionalHeader.MajorSubsystemVersion = 6;
		m_NT_Header.OptionalHeader.MinorSubsystemVersion = 0;
		// 并不是 PE 文件格式规范中必须使用的部分。
		m_NT_Header.OptionalHeader.Win32VersionValue = 0;
		/// 在内存中被加载时所占用的总大小，以字节为单位，这个大小包括了所有节（sections）在内存中的实际占用空间
		m_NT_Header.OptionalHeader.SizeOfImage = m_MemoryAlignment * 5;
		///  PE 文件头（包括 DOS 头、PE 头、节表等）的总大小，以字节为单位，这个大小包括了所有文件头信息，但不包括实际的节（sections）数据。
		m_NT_Header.OptionalHeader.SizeOfHeaders = 0x200/*m_FileAlignment * 24*/;
		// PE 文件的校验和
		m_NT_Header.OptionalHeader.CheckSum = 0;
		// 子系统
		m_NT_Header.OptionalHeader.Subsystem = m_SubSystem;
		// 位掩码，用于指定动态链接库（DLL）的特定属性和行为。这个字段仅在生成的文件是 DLL 时有意义，对于可执行文件（EXE）通常不设置或设置为 0。
		m_NT_Header.OptionalHeader.DllCharacteristics = 0;
		// 为程序栈预留的虚拟内存空间的大小。
		m_NT_Header.OptionalHeader.SizeOfStackReserve = 0x100000;
		// 指定程序启动时操作系统实际为程序栈分配的初始物理内存大小。
		m_NT_Header.OptionalHeader.SizeOfStackCommit = 4096;
		// 为程序堆预留的虚拟内存空间的大小。
		m_NT_Header.OptionalHeader.SizeOfHeapReserve = 0x100000;
		// 指定程序启动时操作系统实际为程序堆（heap）分配的初始物理内存大小。这个值定义了程序堆的初始提交大小，即操作系统在程序启动时实际分配给堆的物理内存数量。
		m_NT_Header.OptionalHeader.SizeOfHeapCommit = 4096;
		// 一个较少使用的字段，它为操作系统加载器提供了额外的控制信息。
		m_NT_Header.OptionalHeader.LoaderFlags = 0;

		// 指定数据目录（Data Directory）中条目的数量。数据目录是一个数组，包含了指向 PE 文件中关键数据结构的指针和大小信息。
		m_NT_Header.OptionalHeader.NumberOfRvaAndSizes = 16;
		// 导入表
		m_NT_Header.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress = 0x1000;
		m_NT_Header.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size = 512;

		AppendRaw(m_Buffer, &m_NT_Header, sizeof(m_NT_Header));
	}

	void Linker_T::AppendSectionTable()
	{
		Array<IMAGE_SECTION_HEADER> SectionHeaders;
		SectionHeaders.clear();

		for (size_t i = 0; i < m_Sections.size(); i++)
		{
			IMAGE_SECTION_HEADER SectionHeader;
			ZeroMemory(&SectionHeader, sizeof(SectionHeader));
			const size_t SectionSize = m_Sections[i]->Data.size();
			// 节名称
			memcpy(SectionHeader.Name, &m_Sections[i]->Name[0], sizeof(m_Sections[i]->Name));
			// 大小（无需对齐）
			SectionHeader.Misc.VirtualSize = m_Sections[i]->Data.size();
			// 加载到内存中的RVA
			if (i == 0) {
				SectionHeader.VirtualAddress = m_MemoryAlignment;
			}
			else {
				const size_t Cur = SectionHeaders[i - 1].VirtualAddress + SectionHeaders[i - 1].SizeOfRawData;
				SectionHeader.VirtualAddress = Cur + GetAlignFillSize(Cur, m_MemoryAlignment);
			}
			// 节在文件中的实际大小（需对齐）
			SectionHeader.SizeOfRawData = SectionSize + GetAlignFillSize(SectionSize, m_SectionAlignment);
			//SectionHeader.Misc.VirtualSize = SectionHeader.SizeOfRawData;
			// 节数据在文件的的RA
			SectionHeader.PointerToRawData = 0x200 + i * 0x200;
			// 重定位信息的文件偏移量。重定位信息通常用于在可执行文件被加载到内存时，修正代码或数据中的地址引用，以确保它们指向正确的内存位置。
			SectionHeader.PointerToRelocations = 0;
			// 行号信息的文件偏移量。行号信息通常用于调试目的，它将源代码中的行号与编译后的代码指令关联起来，使得调试器能够将执行到的指令与源代码中的特定行对应起来。（行号信息并不是必须的）
			SectionHeader.PointerToLinenumbers = 0;
			// 重定位项的数量
			SectionHeader.NumberOfRelocations = 0;
			// 行号信息的数量
			SectionHeader.NumberOfLinenumbers = 0;
			// 节的额外属性和行为的信息
			SectionHeader.Characteristics = m_Sections[i]->SectionAttrib;

			SectionHeaders.push_back(SectionHeader);
			AppendRaw(m_Buffer, &SectionHeader, sizeof(SectionHeader));
		}
		// 对齐
		const size_t AlignFill = GetAlignFillSize(m_Buffer.size(), m_FileAlignment);
		if (AlignFill != 0) {
			Array<BYTE> tmpVec;
			tmpVec.resize(AlignFill);
			ZeroMemory(&tmpVec[0], tmpVec.size());
			AppendBin(m_Buffer, tmpVec);
		}
	}

	void Linker_T::AppendSections()
	{
		for (size_t i = 0; i < m_Sections.size(); i++)
		{
			size_t DataSize = m_Sections[i]->Data.size();
			size_t FillSize = GetAlignFillSize(DataSize, m_SectionAlignment);

			AppendRaw(m_Buffer, m_Sections[i]->Data.data(), DataSize);
			Array<BYTE> Buffer;
			Buffer.resize(FillSize);
			ZeroMemory(&Buffer[0], Buffer.size());
			AppendRaw(m_Buffer, &Buffer[0], Buffer.size());
		}
	}

	void Linker_T::AppendFileAlignment()
	{
		// 对齐总文件
		const size_t NeedFill = GetAlignFillSize(m_Buffer.size(), m_FileAlignment);
		if (NeedFill > 0) {
			Array<BYTE> tmpVec;
			tmpVec.resize(NeedFill);
			ZeroMemory(&tmpVec[0], tmpVec.size());
			AppendRaw(m_Buffer, &tmpVec[0], tmpVec.size());
		}
	}

	void Linker_T::SetSubSystem(DWORD SubSystem)
	{
		m_SubSystem = SubSystem;
	}

	void Linker_T::SetImageBase(DWORD BaseAddr)
	{
		m_NT_Header.OptionalHeader.ImageBase = BaseAddr;
	}

	DWORD Linker_T::GetImageBase() const
	{
		return m_NT_Header.OptionalHeader.ImageBase;
	}

	void Linker_T::SetFileAlignment(size_t AlignSize)
	{
		m_FileAlignment = AlignSize;
	}

	void Linker_T::SetMemoryAlignment(size_t AlignSize)
	{
		m_MemoryAlignment = AlignSize;
	}

	void Linker_T::SetSectionAlignment(size_t AlignSize)
	{
		m_SectionAlignment = AlignSize;
	}

	void Linker_T::AddSection(const String& Name, DWORD Attrib, const Array<BYTE>& Data)
	{
		if (Name.size() > 8)
		{
			throw std::runtime_error(u8"AddSection error: big section name size.");
		}

		PE_Section_T* Section = new PE_Section_T;
		Section->SectionAttrib = Attrib;
		ZeroMemory(&Section->Name[0], sizeof(Section->Name));
		memcpy(&Section->Name[0], &Name[0], Name.size());
		Section->Data = Data;
		m_Sections.push_back(Section);
	}

	DWORD Linker_T::GetNextSectionRVA() const
	{
		DWORD RVA = m_MemoryAlignment;

		if (!m_Sections.empty()) {
			for (const auto& Section : m_Sections)
			{
				size_t Last = Section->Data.size();
				size_t LastAligned = Last + GetAlignFillSize(Last, m_MemoryAlignment);
				RVA += LastAligned;
			}
		}
		return RVA;
	}

	void Linker_T::SetEntryPoint(DWORD RVA)
	{
		m_NT_Header.OptionalHeader.AddressOfEntryPoint = RVA;
	}

	LONG_PTR Linker_T::AddRawData(const Array<BYTE>& Data)
	{
		return 0;
	}

	LONG_PTR Linker_T::AddImport(const String& LibName, const String& Symbol, ExtRelocationCallback_T Callback)
	{
		// 先查重
		size_t ID = 0;
		for (const auto& Func : m_ImportTable[LibName]) {
			if (Func->FuncName == Symbol) {
				return ID; // 已存在
			}
			++ID;
		}
		ImportFunc_T* ImportFunc = new ImportFunc_T;
		ImportFunc->FuncName = Symbol;
		ImportFunc->Callback = Callback;
		m_ImportTable[LibName].push_back(ImportFunc);
		return m_ImportTable.size() - 1;
	}

	LONG_PTR Linker_T::TryGetFunc(const String& Symbol)
	{
		for (const auto& Func : m_FunctionTable) {
			if (Func->Symbol == Symbol) {
				return Func->Offset; // 已存在
			}
		}
		return -1; // 不存在
	}

	DWORD Linker_T::AddFunction(const String& Symbol, const Array<BYTE>* pCode, RelocationCallback_T Callback)
	{
		// 先查重
		const DWORD ID = TryGetFunc(Symbol);
		if (ID != -1) { return ID; }

		FunctionRecord_T* FuncRec = new FunctionRecord_T;
		FuncRec->Symbol = Symbol;
		FuncRec->Code = pCode;
		FuncRec->Callback = Callback;
		size_t Size = m_CodeSection.size();
		FuncRec->Offset = Size;
		m_FunctionTable.push_back(FuncRec);
		AppendBin(m_CodeSection, *pCode);
		return Size;
	}
	
	LONG_PTR Linker_T::AddBinaryRes(const Array<BYTE>& RawData, RelocationCallback_T Callback)
	{
		// 先查重
		size_t ID = 0;
		for (const auto& Res : m_BinaryResources) {
			if (Res->RawData == RawData) {
				return ID; // 已存在
			}
			++ID;
		}
		BinaryResRecord_T* Rec = new BinaryResRecord_T;
		Rec->RawData = RawData;
		Rec->Callback = Callback;
		m_BinaryResources.push_back(Rec);
		return m_BinaryResources.size() - 1;
	}

	LONG_PTR Linker_T::AddFunctionAndDepend(const ObjFunction_T* Function)
	{
		// Map<模块名, Map<函数名, Array<需要修补的位置>>
		static Map<String, Map<String, Array<size_t>>> ExternalMap;
		const auto ExtCallback = [this](const String& LibName, const String& Symbol, DWORD RVA) {
			const auto& Module = ExternalMap[LibName];
			for (const auto& Func : Module) {
				if (Func.first == Symbol) {
					for (const auto& Offset : Func.second) {
						*(DWORD*)(m_CodeSection.data() + Offset - 1) = GetImageBase() + RVA;
					}
				}
			}
			};

		// Map<编号, Array<(所有依赖它的项)需要修补的位置>>
		static Map<DWORD, Array<size_t>> FunctionMap;
		const auto FuncCallback = [this](LONG_PTR ID, DWORD RVA) {
			const auto& Function = FunctionMap[ID];
			if (!Function.empty()) {
				for (const auto& Offset : Function) {
					*(DWORD*)(m_CodeSection.data() + Offset - 1) = RVA - Offset - 3;
				}
			}
			};

		// Map<编号, Array<(所有依赖它的项)需要修补的位置>>
		static Map<LONG_PTR, Array<size_t>> RawDataMap;
		const auto RDataCallback = [this](LONG_PTR ID, DWORD RVA) {
			const auto& RawData = RawDataMap[ID];
			if (!RawData.empty()) {
				for (const auto& Offset : RawData) {
					*(DWORD*)(m_CodeSection.data() + Offset - 1) = GetImageBase() + RVA;
				}
			}
			};

		// 为函数添加依赖
		const ObjFuncRelocates_T* Relocates = Function->GetRelocates();
		// 此函数在代码节中的偏移
		const DWORD Offset = AddFunction(Function->GetName(), &Function->GetCode(), FuncCallback);

		if (Relocates == nullptr) { return Offset; }

		// 外部
		for (const auto& External : Relocates->GetExternals()) {
			AddImport(External->LibName, External->Symbol, ExtCallback);
			ExternalMap[External->LibName][External->Symbol].push_back(Offset + External->Offset);
		}

		// 依赖函数
		for (auto& Function : Relocates->GetRealFuncs()) {
			// 先看看有没有需要的函数
			DWORD FuncOffset = TryGetFunc(Function->Symbol);
			if (FuncOffset != -1) {
				// 已存在，记录需要修补的位置
				FunctionMap[FuncOffset].push_back(Offset + Function->Offset);
			}
			else {
				// 不存在，先尝试从输入单元中查找
				const ObjFunction_T* Func = FindInputFunction(Function->Symbol);
				if (Func == nullptr) {
					return -1;
				}
				// 找到了，递归添加依赖	
				FuncOffset = AddFunctionAndDepend(Func);
				if (FuncOffset == -1) {
					return -1;
				}
				// 记录需要修补的位置
				FunctionMap[FuncOffset].push_back(Offset + Function->Offset);
			}
		}

		// 二进制资源
		for (auto& BinaryRes : Relocates->GetBinaryRes()) {
			const LONG_PTR ID = AddBinaryRes(BinaryRes->RawData, RDataCallback);
			RawDataMap[ID].push_back(Offset + BinaryRes->Offset);
		}

		
		return Offset;
	}

	const ObjFunction_T* Linker_T::FindInputFunction(const String& Symbol) const
	{
		for (const auto& Unit : m_InputUnits) {
			const ObjFunction_T* Func = dynamic_cast<const ObjFunction_T*>(Unit->FindSymbol(Symbol));
			if (Func != nullptr) {
				return Func;
			}
		}
		return nullptr;
	}

	void Linker_T::AddInputFile(const String& Path)
	{
		ObjectFile_T* ObjFile = new ObjectFile_T();
		if (!ObjFile->LoadFromFile(Path)) {
			m_ErrorMsg = u8"输入文件打开失败！";
			return;
		}
		m_InputUnits.push_back(ObjFile);
	}

	void Linker_T::SetOutputFile(const String& FullPath)
	{
		m_OutputFullPath = FullPath;
	}

	bool Linker_T::Build()
	{
		// 测试：
		//AddImport("草泥马", "ExitProcess");
		//AddImport("kernel32.dll", "LoadLibraryW");
		//AddImport("ucrtbase.DLL", "CxxThrowException");
		//AddImport("USER32.DLL", "MessageBoxA");
		//AddImport("USER32.DLL", "MessageBoxW");

		/*==================导入节处理==================*/

		// 导入节的二进制数据
		{
			// 为每个导入模块记录：
			struct FixItem
			{
				DWORD NameOffset = 0;
				DWORD FirstThunkOffset = 0;
				Array<ImportFunc_T*> FirstThunks;  // 该模块的函数表
				Map<String, DWORD> FunctionFixOffsets;  // 每个函数需要修补的位置
			};
			Map<String, FixItem*> NeedFixModules; // 需要修补的模块名、FirstThunks

			// 导入模块表
			for (const auto& Import : m_ImportTable) {
				IMAGE_IMPORT_DESCRIPTOR ImportDesc{};
				AppendRaw(m_ImportSection, (BYTE*)&ImportDesc, sizeof(ImportDesc));

				FixItem* Item = new FixItem;
				Item->NameOffset = m_ImportSection.size() - sizeof(ImportDesc);
				Item->FirstThunkOffset = m_ImportSection.size() - sizeof(ImportDesc) + offsetof(IMAGE_IMPORT_DESCRIPTOR, FirstThunk);
				Item->FirstThunks = Import.second;
				NeedFixModules[Import.first] = Item;
			}

			// 模块表结尾空项
			if (!m_ImportSection.empty()) {
				IMAGE_IMPORT_DESCRIPTOR ImportDesc{};
				AppendRaw(m_ImportSection, (BYTE*)&ImportDesc, sizeof(ImportDesc));
			}

			// 修补模块表名
			for (const auto& Item : NeedFixModules) {
				// 修补模块名RVA
				DWORD NameRVA = GetNextSectionRVA() + m_ImportSection.size();
				*(DWORD*)(m_ImportSection.data() + Item.second->NameOffset + offsetof(IMAGE_IMPORT_DESCRIPTOR, Name)) = NameRVA;

				// 写出模块名
				AppendRaw(m_ImportSection, Item.first.data(), Item.first.size() + 1);
			}

			// 为每个模块创建 FirstThunk 数组并记录修补位置
			size_t i = 0;
			for (const auto& Item : NeedFixModules) {
				// 记录当前函数表开始位置
				DWORD FirstThunkRVA = GetNextSectionRVA() + m_ImportSection.size();
				*(DWORD*)(m_ImportSection.data() + Item.second->FirstThunkOffset) = FirstThunkRVA;

				// 为每个函数创建 thunk 并记录需要修补的位置
				for (const auto& Thunk : Item.second->FirstThunks) {
					DWORD ThunkValue = 0; // 暂时填0，后面修补
					AppendRaw(m_ImportSection, (BYTE*)&ThunkValue, sizeof(ThunkValue));

					// 记录这个函数需要修补的位置（相对于 ImportSection 的偏移）
					DWORD RA = m_ImportSection.size() - sizeof(ThunkValue);
					Item.second->FunctionFixOffsets[Thunk->FuncName] = RA;
					// 如果有回调，调用回调并传入RVA
					if (Thunk->Callback != nullptr) {
						Thunk->Callback(Item.first, Thunk->FuncName, GetNextSectionRVA() + RA);
					}
					++i;
				}

				// 函数表结尾空项
				DWORD NullThunk = 0;
				AppendRaw(m_ImportSection, (BYTE*)&NullThunk, sizeof(NullThunk));
			}

			// 现在为每个模块的函数创建 IMAGE_IMPORT_BY_NAME 并修补 thunk
			for (const auto& Item : NeedFixModules) {
				for (const auto& Function : Item.second->FunctionFixOffsets) {
					// 计算当前函数名的 RVA
					DWORD ImportByNameRVA = GetNextSectionRVA() + m_ImportSection.size();

					// 修补对应的 thunk
					*(DWORD*)(m_ImportSection.data() + Function.second) = ImportByNameRVA;

					// 写入 IMAGE_IMPORT_BY_NAME
					IMAGE_IMPORT_BY_NAME ImportByName{};
					ImportByName.Hint = 0; // 可以设为0，链接器通常不关心hint
					AppendRaw(m_ImportSection, (BYTE*)&ImportByName.Hint, sizeof(ImportByName.Hint));

					// 写入函数名
					AppendRaw(m_ImportSection, Function.first.data(), Function.first.size() + 1);
					//AppendRaw(m_ImportSection, (BYTE*)"\0", 1); // 确保以null结尾
				}
			}

			// 清理内存
			for (auto& Item : NeedFixModules) {
				delete Item.second;
				Item.second = nullptr;
			}
			NeedFixModules.clear();
		}
		
		if (!m_ImportSection.empty()) {
			AddSection(".idata", IMAGE_SCN_CNT_INITIALIZED_DATA | IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_WRITE, m_ImportSection);
		}

		/*==================常量节处理==================*/

		// 二进制常量节的二进制数据
		{
			// 二进制资源表
			size_t i = 0;
			for (const auto& BinaryRes : m_BinaryResources) {
				// 记录当前二进制 RVA
				DWORD RVA = GetNextSectionRVA() + m_RawDataSection.size();

				// 记录二进制 RVA
				if (BinaryRes->Callback != nullptr) {
					BinaryRes->Callback(i, RVA);
				}

				// 写入二进制内容
				// 可选：UTF8到ANSI
				//BinaryRes->RawData = Utf8ToAnsi(BinaryRes->RawData);
				AppendRaw(m_RawDataSection, BinaryRes->RawData.data(), BinaryRes->RawData.size()/* + 1*/);
				++i;
			}
		}

		if (!m_RawDataSection.empty()) {
			AddSection(".rdata", IMAGE_SCN_CNT_INITIALIZED_DATA | IMAGE_SCN_MEM_READ, m_RawDataSection);
		}

		/*==================代码节处理==================*/

		// 每个单元的初始化代码
		Array<BYTE> InitCode;
		for (const auto& Unit : m_InputUnits) {
			AppendBin(InitCode, Unit->GetInitCode());
		}
		// RET
		InitCode.push_back(0xC3);

		// 函数表
		size_t i = 0;
		for (const auto& Function : m_FunctionTable) {
			DWORD FuncRVA = GetNextSectionRVA() + i;
			// 回调
			if (Function->Callback != nullptr) {
				Function->Callback(i, /*FuncRVA*/i);
			}

			// 写入代码内容
			//AppendRaw(m_CodeSection, Function->Code->data(), Function->Code->size());
			i += Function->Code->size();
		}

		SetEntryPoint(GetNextSectionRVA());
		// text
		InsertBin(m_CodeSection, InitCode);
		AddSection(".text", IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ, m_CodeSection);

		AppendDOSHeader();     // DOS头
		AppendDOSStub();       // DOS Stub
		AppendNTHeader();      // NT头
		AppendSectionTable();  // 节表
		AppendSections();      // 节数据
		AppendFileAlignment(); // 对齐

		WriteToFile();
		return true;
	}

	const String& Linker_T::GetErrorMsg() const
	{
		return m_ErrorMsg;
	}
}