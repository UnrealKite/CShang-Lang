﻿#ifndef AST_HPP
#define AST_HPP
#include "../Program/pch.hpp"
namespace CShang
{
	enum class ASTNodeType
	{
		Unknown,
		CodeBlock,
		Identifier,
		LiteralInteger,
		LiteralString,
		CallingStatement,
		BinaryExpression,
		StringConcat,
	};

	/*============ASTNode_T============*/
	class ASTNode_T
	{
	public:
		ASTNode_T() = default;
		virtual ~ASTNode_T() = default;

		// 节点类型
		ASTNodeType GetType() const;

		void SetTag(LONG_PTR Tag);
		LONG_PTR GetTag() const;

	protected:
		LONG_PTR m_Tag = 0;
		ASTNodeType m_Type = ASTNodeType::Unknown;
	};

	/*============CodeBlock_T============*/
	// 代码块
	class CodeBlock_T : public ASTNode_T
	{
	public:
		CodeBlock_T();
		~CodeBlock_T();

		class Space_T* Space = nullptr;

		bool Parsing_LastIsAtomic = 0;
		const class Token_T* Parsing_LastTk = nullptr;
		void AddTempNode(ASTNode_T* Node);
		ASTNode_T* GetTempBack() const;
		void PopTempBack();
		const Array<ASTNode_T*>& GetSubNodes() const;
		ASTNode_T* GetSubBack() const;
		void FormatTempNodes();

	private:
		Array<ASTNode_T*> m_SubNodes;
		Array<ASTNode_T*> m_TempNodes;
	};

	/*============Identifier_T============*/
	class Identifier_T : public ASTNode_T
	{
	public:
		Identifier_T();
		~Identifier_T() = default;

		void SetName(const String& Name);
		const String& GetName() const;

		String Name;

	private:
		
	};

	/*============LiteralInteger_T============*/
	// 整数
	class LiteralInteger_T : public ASTNode_T
	{
	public:
		LiteralInteger_T();
		~LiteralInteger_T() = default;
		void SetValue(int64_t Value);
		int64_t GetValue() const;
		uint64_t Value = 0;
		
	};

	/*============LiteralString_T============*/
	// 文本
	class LiteralString_T : public ASTNode_T
	{
	public:
		LiteralString_T();
		~LiteralString_T() = default;
		void SetValue(const String& Value);
		const String& GetValue() const;
		String Value;
	};

	/*============BinaryExpression_T============*/

	enum class BinOp_E
	{
		Unknown,
		// 四则
		Add, Sub, Mul, Div,
		// 位运算
		And, Or, Xor,
		// 赋值
		Assign,
		// 成员访问
		MAcc
	};

	// 二元表达式基类
	class BinaryExpression_T : public ASTNode_T
	{
	public:
		BinaryExpression_T();
		~BinaryExpression_T() = default;
		bool IsAtomicity = false;
		ASTNode_T* Left = nullptr;
		ASTNode_T* Right = nullptr;
		BinOp_E Operator = BinOp_E::Unknown;
	};

	// 四则运算
	class FourBinExpression_T : public BinaryExpression_T
	{
	public:
		FourBinExpression_T();
		~FourBinExpression_T() = default;
	};

	// 算数位运算
	class BitBinExpression_T : public BinaryExpression_T
	{
	public:
		BitBinExpression_T();
		~BitBinExpression_T() = default;
	};

	// 赋值语句
	class AssignStatement_T : public BinaryExpression_T
	{
	public:
		AssignStatement_T();
		~AssignStatement_T() = default;
	};

	// 成员访问
	class MemberAccess_T : public BinaryExpression_T
	{
	public:
		MemberAccess_T();
		~MemberAccess_T() = default;
	};

	/*============StringConcat_T============*/
	// 字符串拼接
	class StringConcat_T : public ASTNode_T
	{
	public:
		StringConcat_T();
		~StringConcat_T() = default;

		ASTNode_T* Left = nullptr;
		ASTNode_T* Right = nullptr;
	};

	/*============CallingStatement_T============*/
	// 调用语句
	class CallingStatement_T : public ASTNode_T
	{
	public:
		CallingStatement_T();
		~CallingStatement_T() = default;

		const ASTNode_T* Source = nullptr;

		void SetSource(const ASTNode_T* Node);
		const ASTNode_T* GetSource() const;

		void AddParam(const ASTNode_T* Node);
		const Array<const ASTNode_T*>& GetParams() const;

	private:
		
		Array<const ASTNode_T*> m_Params;
	};

	void PrintASTStructure(const ASTNode_T* Node, const std::string& prefix = "", bool isLast = true, bool isRoot = true);
}
#endif // !AST_HPP