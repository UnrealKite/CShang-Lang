﻿// 文件： Linker.hpp
// 说明： PE文件链接器
// 作者： 所有者

#ifndef LINKER_HPP	
#define LINKER_HPP
#include "../Program/pch.hpp"
#include "ObjectFile.hpp"

namespace CShang
{
	struct PE_Section_T
	{
		DWORD SectionAttrib = 0;
		BYTE Name[IMAGE_SIZEOF_SHORT_NAME] = {};
		Array<BYTE> Data = {};
	};

	using RelocationCallback_T = std::function<void(LONG_PTR ID, DWORD RVA)>;
	using ExtRelocationCallback_T = std::function<void(const String& LibName, const String& Symbol, DWORD RVA)>;

	class Linker_T
	{
	public:
		Linker_T();
		~Linker_T();
		bool WriteToFile();

		void AppendDOSHeader();
		void AppendDOSStub();
		void AppendNTHeader();
		void AppendSectionTable();
		void AppendSections();
		void AppendFileAlignment();

		// void SetOutputFileType();

		// IMAGE_SUBSYSTEM_UNKNOWN(0)                  : 未知子系统。
		// IMAGE_SUBSYSTEM_NATIVE(1)                   : 不需要子系统，通常用于驱动程序。
		// IMAGE_SUBSYSTEM_WINDOWS(GUI) (2)            : Windows 图形用户界面子系统。
		// IMAGE_SUBSYSTEM_WINDOWS_CUI(3)              : Windows 控制台用户界面子系统。
		// IMAGE_SUBSYSTEM_POSIX_CUI(7)                : POSIX 控制台用户界面子系统。
		// IMAGE_SUBSYSTEM_WINDOWS_CE(GUI) (9)         : Windows CE 图形用户界面子系统。
		// IMAGE_SUBSYSTEMEFI_APPLICATION(10)          : EFI 应用程序。
		// IMAGE_SUBSYSTEMEFI_BOOT_SERVICE_DRIVER(11)  : EFI 启动服务驱动程序。
		// IMAGE_SUBSYSTEMEFI_RUN_TIME_DRIVER(12)      : EFI 运行时驱动程序。
		// IMAGE_SUBSYSTEMEFI_ROM(13)                  : EFI 固件。
		// IMAGE_SUBSYSTEM_XBOX(14)                    : Xbox 子系统。
		void SetSubSystem(DWORD SubSystem);
		void SetImageBase(DWORD BaseAddr);
		DWORD GetImageBase() const;
		void SetFileAlignment(size_t AlignSize);
		void SetMemoryAlignment(size_t AlignSize);
		void SetSectionAlignment(size_t AlignSize);

		// IMAGE_SCN_CNT_CODE                : 节包含可执行代码。
		// IMAGE_SCN_CNT_INITIALIZED_DATA    : 节包含已初始化的数据。
		// IMAGE_SCN_CNT_UNINITIALIZED_DATA  : 节包含未初始化的数据。
		// IMAGE_SCN_MEM_EXECUTE             : 节可执行。
		// IMAGE_SCN_MEM_READ                : 节可读。
		// IMAGE_SCN_MEM_WRITE               : 节可写。
		// IMAGE_SCN_MEM_DISCARDABLE         : 节在加载后可以被丢弃。
		// IMAGE_SCN_MEM_SHARED              : 节在多个进程之间共享。
		void AddSection(const String& Name, DWORD Attrib, const Array<BYTE>& Data);
		DWORD GetNextSectionRVA() const;
		void SetEntryPoint(DWORD RVA);
		LONG_PTR AddRawData(const Array<BYTE>& Data);
		LONG_PTR AddImport(const String& LibName, const String& Symbol, ExtRelocationCallback_T Callback = nullptr);
		LONG_PTR TryGetFunc(const String& Symbol);
		DWORD AddFunction(const String& Symbol, const Array<BYTE>* pCode, RelocationCallback_T Callback = nullptr);
		LONG_PTR AddBinaryRes(const Array<BYTE>& RawData, RelocationCallback_T Callback = nullptr);

		LONG_PTR AddFunctionAndDepend(const ObjFunction_T* Function);
		const ObjFunction_T* FindInputFunction(const String& Symbol) const;
		void AddInputFile(const String& Path);
		void SetOutputFile(const String& FullPath);
		bool Build();

		const String& GetErrorMsg() const;

	private:
		String m_ErrorMsg;
		// 文件路径
		String m_OutputFullPath;

		// 输入列表 
		Array<ObjectFile_T*> m_InputUnits;

		// 资源（文本等）
		Map<DWORD, Array<BYTE>> m_RawResources;

		// 导入表
		struct ImportFunc_T
		{
			String FuncName;
			ExtRelocationCallback_T Callback = nullptr;
		};
		Map<String, Array<ImportFunc_T*>> m_ImportTable;

		// 函数表
		struct FunctionRecord_T
		{
			size_t Offset = 0;
			String Symbol;
			const Array<BYTE>* Code = nullptr; // 减少拷贝
			RelocationCallback_T Callback = nullptr;
		};
		Array<FunctionRecord_T*> m_FunctionTable;

		// 二进制资源
		struct BinaryResRecord_T
		{
			Array<BYTE> RawData;
			RelocationCallback_T Callback = nullptr;
		};
		Array<BinaryResRecord_T*> m_BinaryResources;

		// 相关节的二进制数据
		Array<BYTE> m_ImportSection;
		Array<BYTE> m_RawDataSection;
		Array<BYTE> m_CodeSection;

		// 输出缓冲区
		Array<BYTE> m_Buffer;

		IMAGE_DOS_HEADER m_DOS_Header;
		Array<BYTE> m_DOS_Stub;
		IMAGE_NT_HEADERS32 m_NT_Header;

		Array<PE_Section_T*> m_Sections;

		DWORD m_SubSystem;

		size_t m_FileAlignment;
		size_t m_MemoryAlignment;
		size_t m_SectionAlignment;
	};

	
}
#endif // !LINKER_HPP