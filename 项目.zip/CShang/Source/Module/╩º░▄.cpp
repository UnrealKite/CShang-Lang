/*
static BinaryExpression_T* GetRootStatement(BinaryExpression_T* Statement)
	{
		ASTNode_T* Temp = Statement->GetRight();
		if (Temp == nullptr) {
			return Statement;
		}
		const ASTNodeType TypeDesc = Temp->GetType();
		if (TypeDesc == ASTNodeType::BinaryExpression) {
			BinaryExpression_T* Statement = dynamic_cast<BinaryExpression_T*>(Temp);
			return GetRootStatement(Statement);
		}
		return Statement;
	}
void SyntaxParser_T::ParseCodeBlock(CodeBlock_T* Block, ASTNode_T* Cur)
	{
		const Token_T& Token = _NextToken();
		switch (Token.TypeDesc)
		{
		case TokenType::COM_Id: {
			Identifier_T* Identifier = new Identifier_T();
			Identifier->SetName(Token.Value);
			ASTNode_T* Node = Cur->GetTempNode();
			if (Node != nullptr) {
				Cur->AddSubNode(Node);
			}
			Cur->SetTempNode(Identifier);
			ParseCodeBlock(Block, Cur);
			break;
		}
		case TokenType::Assign: {
			AssignStatement_T* Statement = new AssignStatement_T();

			ASTNode_T* Node = Block->GetTempNode();
			if (Node == nullptr) {
				throw std::runtime_error(u8"����ֵ������Ϊ��");
			}
			Statement->SetTarget(Node);
			Block->AddSubNode(Statement);
			Block->SetTempNode(nullptr);
			//Block->SetTempNode(Statement);
			// Block->SetActiveNode();
			ParseCodeBlock(Block, Statement);
			break;
		}
		case TokenType::COM_Integer: {
			LiteralInteger_T* Literal = new LiteralInteger_T();
			Literal->SetValue(std::stoull(Token.Value));

			ASTNode_T* Temp = Cur->GetTempNode();
			if (Temp == nullptr) {
				Cur->SetTempNode(Literal);
			}
			else {
				const ASTNodeType TypeDesc = Temp->GetType();
				if (TypeDesc == ASTNodeType::BinaryExpression) {
					BinaryExpression_T* Statement = GetRootStatement(dynamic_cast<BinaryExpression_T*>(Temp));
					Statement->SetRight(Literal);
				}
			}
			ParseCodeBlock(Block, Cur);
			break;
		}
		case TokenType::Add:
		case TokenType::Sub:
		case TokenType::Mul:
		case TokenType::Div:
		{
			// ���������
			FourArithOp_E Op = FourArithOp_E::Unknown;
			switch (Token.TypeDesc)
			{
			case TokenType::Add: Op = FourArithOp_E::Add; break;
			case TokenType::Sub: Op = FourArithOp_E::Sub; break;
			case TokenType::Mul: Op = FourArithOp_E::Mul; break;
			case TokenType::Div: Op = FourArithOp_E::Div; break;
			}

			BinaryExpression_T* NewBinaryOp = new BinaryExpression_T();
			NewBinaryOp->SetOp(Op);
			ASTNode_T* Temp = Cur->GetTempNode();
			const ASTNodeType TypeDesc = Temp->GetType();

			if (TypeDesc == ASTNodeType::BinaryExpression) {
				BinaryExpression_T* Statement = dynamic_cast<BinaryExpression_T*>(Temp);
				const FourArithOp_E TempOp = Statement->GetOp();
				// ���ȼ�����
				if ((TempOp == FourArithOp_E::Add || TempOp == FourArithOp_E::Sub)
					&& (Op == FourArithOp_E::Mul || Op == FourArithOp_E::Div))
				{
					ASTNode_T* Right = Statement->GetRight();
					NewBinaryOp->SetLeft(Right);
					Statement->SetRight(NewBinaryOp);
				}
				else {
					NewBinaryOp->SetLeft(Statement);
					Cur->SetTempNode(NewBinaryOp);
				}
			}
			else {
				NewBinaryOp->SetLeft(Temp);
				Cur->SetTempNode(NewBinaryOp);
			}

			ParseCodeBlock(Block, Cur);
			break;
		}
		case TokenType::RB: {
			ASTNode_T* Temp = Cur->GetTempNode();
			if (Temp != nullptr) {
				auto& SubNodes = Block->GetSubNodes();
				ASTNode_T* node = (ASTNode_T*)SubNodes.back();
				auto* temp = node->GetTempNode();
				if (temp != nullptr) {
					if (node->GetType() == ASTNodeType::AssignStatement) {
						AssignStatement_T* Statement = dynamic_cast<AssignStatement_T*>(node);
						Statement->SetValue(Statement->GetTempNode());
						Statement->SetTempNode(nullptr);
					}
				}
			}
			break;
		}
		}
	}

*/








/*
ASTNode_T* _LastNode = nullptr;
				BinaryExpression_T* LastBinaryNode = nullptr;

				Array<ASTNode_T*> NeedRemoveNodes;
				// �ȴ������г˳���
				for (auto& Node : Nodes) {
					const ASTNodeType TypeDesc = Node->GetType();
					if (TypeDesc == ASTNodeType::BinaryExpression) {
						LastBinaryNode = dynamic_cast<BinaryExpression_T*>(Node);
					}
					else {
						if (LastBinaryNode != nullptr) {
							const FourArithOp_E Op = LastBinaryNode->GetOp();
							if (Op == FourArithOp_E::Mul || Op == FourArithOp_E::Div) {
								LastBinaryNode->SetLeft(_LastNode);
								LastBinaryNode->SetRight(Node);
								NeedRemoveNodes.push_back(_LastNode);
								NeedRemoveNodes.push_back(Node);
							}
						}
						_LastNode = Node;
					}
				}

				Nodes.erase(
					std::remove_if(Nodes.begin(), Nodes.end(),
						[&NeedRemoveNodes](ASTNode_T* node) {
							return std::find(NeedRemoveNodes.begin(), NeedRemoveNodes.end(), node) != NeedRemoveNodes.end();
						}),
					Nodes.end()
				);

				for (const auto& node : Nodes) {
					PrintASTStructure(node);
					printf("%s\n", "----------");
				}


				_LastNode = nullptr;
				LastBinaryNode = nullptr;
				NeedRemoveNodes.clear();

				ASTNode_T* Record = nullptr;
				BinaryExpression_T* Last = nullptr;

				for (size_t i = 0; i < Nodes.size(); i++) {
					const auto& Node = Nodes[i];
					if (i % 2 == 0) {  // ���������
						Record = Node;
						continue;      // ��������ѭ����ʣ�ಿ��
					}
					const ASTNodeType TypeDesc = Node->GetType();
					if (TypeDesc == ASTNodeType::BinaryExpression) {
						BinaryExpression_T* Statement = dynamic_cast<BinaryExpression_T*>(Node);
						if (Statement->GetOp() != FourArithOp_E::Mul && Statement->GetOp() != FourArithOp_E::Div)
						{
							printf("!!!warning!!!\n");
						}
						Statement->SetLeft(Record);
						Last = Statement;
					}
				}

				Last->SetRight(Record);

*/




























/*
if (Node == nullptr) { return; }

		if (LastNode == nullptr) {
			LastNode = Node;
		}

		const Token_T& Token = _NextToken();
		switch (Token.TypeDesc)
		{
		case TokenType::COM_Id: {
			Identifier_T* Identifier = new Identifier_T();
			Identifier->SetName(Token.Value);
			ASTNode_T* Last = LastNode->GetBack();
			if ((Last == nullptr) || (Last != nullptr && Last->GetType() == ASTNodeType::BinaryExpression)) {
				LastNode->PushTempNode(Identifier);
				ParseASTNodes(Node, LastNode);
			}
			else {
				ConvertToFormalNode(Node, LastNode);
				Node->PushTempNode(Identifier);
				ParseASTNodes(Node, Node);
			}
			break;
		}
		case TokenType::Assign: {
			AssignStatement_T* Statement = new AssignStatement_T();
			Statement->SetTarget(LastNode->GetBackAndPop());
			Node->PushTempNode(Statement);
			ParseASTNodes(Node, Statement);
			break;
		}
		case TokenType::COM_Integer: {
			LiteralInteger_T* Int = new LiteralInteger_T();
			Int->SetValue((int64_t)std::stoull(Token.Value));
			//if (LastNode->GetType() == ASTNodeType::AssignStatement true)
			ASTNode_T* Last = LastNode->GetBack();
			if ((Last == nullptr) || (Last != nullptr && Last->GetType() == ASTNodeType::BinaryExpression)) {
				LastNode->PushTempNode(Int);
				ParseASTNodes(Node, LastNode);
			}
			else {
				ConvertToFormalNode(Node, LastNode);
				Node->PushTempNode(Int);
				ParseASTNodes(Node, Node);
			}
			break;
		}
		case TokenType::Add: case TokenType::Sub:
		case TokenType::Mul: case TokenType::Div:
		{
			// ���������
			FourArithOp_E Op = FourArithOp_E::Unknown;
			switch (Token.TypeDesc)
			{
			case TokenType::Add: Op = FourArithOp_E::Add; break;
			case TokenType::Sub: Op = FourArithOp_E::Sub; break;
			case TokenType::Mul: Op = FourArithOp_E::Mul; break;
			case TokenType::Div: Op = FourArithOp_E::Div; break;
			}

			BinaryExpression_T* Statement = new BinaryExpression_T();
			Statement->SetOp(Op);
			LastNode->PushTempNode(Statement);

			ParseASTNodes(Node, LastNode);
			break;
		}
		case TokenType::RB: {
			ConvertToFormalNode(Node, LastNode);
			return;
			break;
		}
		case TokenType::LP: {
			CallingStatement_T* Statement = new CallingStatement_T();
			Statement->SetSource(LastNode->GetBackAndPop());
			LastNode->PushTempNode(Statement);
			ParseASTNodes(Node, LastNode);
			break;
		}
		case TokenType::RP: {
			ASTNode_T* Back = LastNode->GetBack();
			ASTNodeType TypeDesc = Back->GetType();
			if (TypeDesc == ASTNodeType::CallingStatement) {
				CallingStatement_T* Statement = dynamic_cast<CallingStatement_T*>(Back);
				Node->AddSubNode(Statement);
				Node->PopBack();
			}
			ParseASTNodes(Node, LastNode);
			break;
		}
		}

*/



/*static void ConvertToFormalNode(ASTNode_T* Node, ASTNode_T* LastNode)
	{
		const ASTNodeType TypeDesc = LastNode->GetType();
		if (TypeDesc == ASTNodeType::AssignStatement) {
			AssignStatement_T* Statement = dynamic_cast<AssignStatement_T*>(LastNode);
			Array<ASTNode_T*> Nodes = Statement->GetTempNodes();
			if (Nodes.size() == 1) {
				Statement->SetValue(Nodes.back());
			}
			else {
				ASTNode_T* Record = nullptr;
				BinaryExpression_T* Last = nullptr;

				for (size_t i = 0; i < Nodes.size(); i++) {
					const auto& Node = Nodes[i];
					const ASTNodeType TypeDesc = Node->GetType();
					if (TypeDesc == ASTNodeType::BinaryExpression) {
						BinaryExpression_T* Statement = dynamic_cast<BinaryExpression_T*>(Node);
						Statement->SetLeft(Record);
						Last = Statement;
					}
					else {
						Record = Node;
					}
				}
				Last->SetRight(Record);
				Statement->SetValue(Last);
			}
			Node->AddSubNode(LastNode);
			if (Node->GetBack() == LastNode) {
				Node->PopBack();
			}
		}
	}*/