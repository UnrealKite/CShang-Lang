﻿#ifndef TOKEN_HPP
#define TOKEN_HPP
#include "../Program/pch.hpp"
namespace CShang
{
	enum class TokenType
	{
		Void,     // 保留

		// 可多态
		Empty,    // 空格，换行符，制表符
		Integer,   // 0 .. 9
		Word,     // A .. Z  &  a .. z  &  [中文]

		// 不可多态
		// : ; . ,
		Colon, Semicolon, Dot, Comma,
		// ' " `
		SingleQuote, DoubleQuote, BackQuote,
		
		// (   )   [   ]   {   }   <    >
		LP, RP, LA, RA, LB, RB, LTD, RTD,
		// =
		Assign,
		// =>
		ResultType,
		// ..
		StrConcat,
		// ..=
		StrConcatA,
		
		// + - * /
		Add, Sub, Mul, Div,
		// & # ~ ~#
		BitAnd, BitOr, BitNot, BitXor,

		// == >= <=
		Cmp, CHigh, CLow,

		// 组合
		COM_SComment, // 单行注释
		COM_MComment, // 多行注释
        COM_Ident,       // 标识符
        //Integer,
        COM_Float,
		COM_String,
    };

    struct Token_T
    {
		TokenType Type = TokenType::Void;
		String Value;
		Position_T Position;
	};

	extern std::map<TokenType, String> TokenName;
	bool IsKeyworld(const String& StrId);
	bool IsBinOpToken(TokenType Type);
	uint32_t GetTokenColor(const Token_T& Token);
}
#endif // !TOKEN_HPP
