﻿#include "Token.hpp"
namespace CShang
{
	std::map<TokenType, String> TokenName
	{
		{ TokenType::Void, u8"保留" },
		//================================//
		{ TokenType::Empty,  u8"空" },
		{ TokenType::Integer, u8"整数" },
		{ TokenType::Word,   u8"字" },
		//================================//
		{ TokenType::Colon,     u8"冒号" },
		{ TokenType::Dot,       u8"点" },
		{ TokenType::Comma,     u8"逗号" },
		{ TokenType::Semicolon, u8"分号" },
		//================================//
		{ TokenType::SingleQuote, u8"单引号" },
		{ TokenType::DoubleQuote, u8"双引号" },
		{ TokenType::BackQuote,   u8"反引号" },
		//================================//
		{ TokenType::LP,  u8"左括号" },
		{ TokenType::RP,  u8"右括号" },
		{ TokenType::LA,  u8"左方括号" },
		{ TokenType::RA,  u8"右方括号" },
		{ TokenType::LB,  u8"左花括号" },
		{ TokenType::RB,  u8"右花括号" },
		{ TokenType::LTD, u8"左尖括号" },
		{ TokenType::RTD, u8"右尖括号" },
		//================================//
		{ TokenType::Assign, u8"赋值号" },
		//================================//
		{ TokenType::ResultType, u8"返回值类型标记" },
		//================================//
		{ TokenType::StrConcat, u8"字符串拼接" },
		//================================//
		{ TokenType::StrConcatA, u8"字符串自拼接赋值" },
		//================================//
		{ TokenType::Add, u8"加号" },
		{ TokenType::Sub, u8"减号" },
		{ TokenType::Mul, u8"乘号" },
		{ TokenType::Div, u8"除号" },
		//================================//
		{ TokenType::BitAnd, u8"位与" },
		{ TokenType::BitOr,  u8"位或" },
		{ TokenType::BitNot, u8"位非" },
		{ TokenType::BitXor, u8"位异或" },
		//================================//
		{ TokenType::Cmp,   u8"等于" },
		{ TokenType::CHigh, u8"大于" },
		{ TokenType::CLow,  u8"小于" },
		//================================//
		{ TokenType::COM_SComment, u8"单行注释" },
		{ TokenType::COM_MComment, u8"多行注释" },
		{ TokenType::COM_Ident,       u8"标识符" },
		{ TokenType::Integer,  u8"整数" },
		{ TokenType::COM_Float,    u8"小数" },
		{ TokenType::COM_String,   u8"字符串" },
	};

	bool IsKeyworld(const String& StrId)
	{
		if (StrId == u8"函数") { return true; }
		if (StrId == u8"变量") { return true; }
		if (StrId == u8"导入") { return true; }
		if (StrId == u8"整数型") { return true; }
		if (StrId == u8"字符串") { return true; }
	}

	bool IsBinOpToken(TokenType Type)
	{
		std::set<TokenType> BinOperators
		{
			TokenType::Assign,
			TokenType::Add,
			TokenType::Sub,
			TokenType::Mul,
			TokenType::Div,
			TokenType::BitAnd,
			TokenType::BitOr,
			TokenType::BitXor
		};
		return BinOperators.find(Type) != BinOperators.end();
	}

	uint32_t GetTokenColor(const Token_T& Token)
	{
		if (Token.Type == TokenType::COM_Ident) {
			if (IsKeyworld(Token.Value)) {
				// 关键字
				return RGB(0x56, 0x9C, 0xD6);
			}
			else {
				// 标识符
				return RGB(0x4E, 0xC9, 0xB0);
			}
		}
		else if (Token.Type == TokenType::Integer || Token.Type == TokenType::COM_Float) {
			// 数字
			return RGB(0xB5, 0xC1, 0xA8);
		}
		else if (Token.Type == TokenType::COM_String) {
			// 字符串
			return RGB(0xD6, 0x9D, 0x85);
		}
		else if (Token.Type == TokenType::COM_SComment) {
			// 单行注释
			return RGB(0x57, 0xA6, 0x4A);
		}
		else if (Token.Type == TokenType::COM_MComment) {
			// 多行注释
			return RGB(0x57, 0xA6, 0x4A);
		}
		else {
			// 其他：默认
			return RGB(0xB4, 0xB4, 0xB4);
		}
	}
}