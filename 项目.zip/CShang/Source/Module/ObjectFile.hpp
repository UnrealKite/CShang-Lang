﻿#ifndef OBJECT_FILE_HPP
#define OBJECT_FILE_HPP
#include "../Program/pch.hpp"
namespace CShang
{
	// 为了方便调试，暂时使用json存储，后续优化为更小更高效的二进制文件

	// 尽量多用指针，减少拷贝
	// 先明确需求再写，不要拿着键盘就开始瞎写

	struct BinaryRes_T
	{
		LONG_PTR Tag = 0; // 保留
		int Offset; // 代码中需要重定位的位置
		Array<BYTE> RawData; // 字符串内容
	};

	struct External_T
	{
		LONG_PTR Tag = 0; // 保留
		int Offset; // 代码中需要重定位的位置
		String LibName; // 库名
		String Symbol;  // 符号名
	};

	struct RealFunc_T
	{
		LONG_PTR Tag = 0; // 保留
		int Offset; // 代码中需要重定位的位置
		String Symbol;
	};

	class ObjFuncRelocates_T
	{
	public:
		void SetBaseOffset(int Offset);
		// 记录字符串资源
		void AddBinaryRes(int Offset, const Array<BYTE>& StrRes);
		// 记录外部函数
		void AddExternal(int Offset, const String& LibName, const String& Symbol);
		// 记录依赖的函数
		void AddRealFunc(int Offset, const String& Symbol);
		const Array<BinaryRes_T*>& GetBinaryRes() const { return m_BinaryRes; }
		const Array<External_T*>& GetExternals() const { return m_Externals; }
		const Array<RealFunc_T*>& GetRealFuncs() const { return m_RealFuncs; }
	private:
		Array<BinaryRes_T*> m_BinaryRes;
		Array<External_T*> m_Externals;
		Array<RealFunc_T*> m_RealFuncs;
	};

	enum class ObjSymbolType_E
	{
		Unknown,
		Function,
		Variable
	};

	class ObjSymbol_T
	{
	public:
		ObjSymbol_T();
		virtual ~ObjSymbol_T() = default;
		// 符号名
		void SetName(const String& Name) { m_Name = Name; }
		const String& GetName() const { return m_Name; }

		ObjSymbolType_E GetType() const { return m_Type; }
	protected:
		String m_Name; // 符号名
		ObjSymbolType_E m_Type = ObjSymbolType_E::Unknown; // 符号类型
	};

	class ObjFunction_T : public ObjSymbol_T
	{
	public:
		ObjFunction_T();
		~ObjFunction_T() = default;
		// 代码
		void SetCode(const Array<BYTE>& Code) { m_Code = Code; }
		const Array<BYTE>& GetCode() const { return m_Code; }

		void SetRelocates(ObjFuncRelocates_T* Relocates) { m_Relocates = Relocates; }
		const ObjFuncRelocates_T* GetRelocates() const { return m_Relocates; }
	public:
		ObjFuncRelocates_T* m_Relocates = nullptr; // 重定位信息
	private:
		Array<BYTE> m_Code; // 机器码
	};

	// 需求：有一个类能操作.o文件
	// 编译每个单元后生成对应的.o文件，存储了这个单元所有的函数和变量的符号
	// 链接器分析函数依赖关系（其它单元函数、外部库函数，文本变量等）
	// 若需使用某个函数，除了要合并该函数的代码，还要合并该函数所依赖的所有符号并重定位
	class ObjectFile_T
	{
	public:
		bool LoadFromFile(const String& Path);
		bool SaveToFile(const String& Path);
		void SetInitCode(const Array<BYTE>& Code);
		const Array<BYTE>& GetInitCode();
		void AddFunction(const String& Name, const Array<BYTE>& Code, ObjFuncRelocates_T* Relocates);
		const ObjSymbol_T* FindSymbol(const String& Name) const;
		//void AddFunction(const ObjFunction_T* ObjFunc);

	private:
		//Array<ObjFunction_T*> Functions;
		Array<BYTE> m_InitCode;
		Array<ObjSymbol_T*> m_Symbols;
	};
}
#endif // !OBJECT_FILE_HPP