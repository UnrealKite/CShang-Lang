#ifndef STACK_RES_ALLOCATOR_HPP
#define STACK_RES_ALLOCATOR_HPP
#include "../Program/pch.hpp"
#include "ClassDefine.hpp"
#include "Assembler.hpp"
namespace CShang
{
	class StackResAllocator_T
	{
	public:
		StackResAllocator_T();
		~StackResAllocator_T();

		x86::Register GetAvtiveR() const;
		void PushR(x86::Register R);
		void PopR(x86::Register R);

		void SetLocalVariables(const Array<Pair<String, Variable_T*>>& Variables);
		size_t GetNeedSize() const;
		Pair<Variable_T*, size_t> GetObjAndOffset(const String& Name) const;
		size_t GetOffset(const String& Name) const;

		void ResetRegisterAllocator();
		x86::Register AllocateRegister();
		Array<x86::Register> GetUsedRegisters();

	private:

		size_t m_NeedSize = 0;
		Array<Pair<String, Pair<size_t, Variable_T*>>> m_Variables;
		Stack<x86::Register> m_RStack;

		bool Eax = false; bool Ebx = false;
		bool Ecx = false; bool Edx = false;
		bool Edi = false; bool Esi = false;

		bool Used_Eax = false; bool Used_Ebx = false;
		bool Used_Ecx = false; bool Used_Edx = false;
		bool Used_Edi = false; bool Used_Esi = false;
	};
}
#endif // !STACK_RES_ALLOCATOR_HPP