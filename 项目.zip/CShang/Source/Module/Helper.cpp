﻿#include "Helper.hpp"
namespace CShang
{
    String Utf8ToAnsi(const String& utf8)
    {
        // 计算所需的缓冲区大小
        const int WCStringLength = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, NULL, 0);
        // 转换失败
        if (WCStringLength == 0) { return ""; }

        // 创建宽字符数组
        wchar_t* WCString = new wchar_t[WCStringLength];
        MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, WCString, WCStringLength);

        // 计算 ANSI 字符串的缓冲区大小
        const int ANSILength = WideCharToMultiByte(CP_ACP, 0, WCString, -1, NULL, 0, NULL, NULL);
        if (ANSILength == 0) {
            delete[] WCString;
            return ""; // 转换失败
        }

        // 创建 ANSI 字符串并进行转换
        std::string ANSIString(ANSILength, '\0');
        WideCharToMultiByte(CP_ACP, 0, WCString, -1, &ANSIString[0], ANSILength, NULL, NULL);

        delete[] WCString; // 释放内存
        return ANSIString;
    }

    WString Utf8ToUtf16(const String& UTF8)
    {
        if (UTF8.empty()) { return L""; }

        // 获取所需缓冲区大小
        const int SizeNeeded = MultiByteToWideChar(CP_UTF8, 0, UTF8.c_str(), (int)UTF8.size(), nullptr, 0);
        if (SizeNeeded == 0) { return L""; }

        // 分配足够大的缓冲区
        WString UTF16(SizeNeeded, 0);

        // 实际执行转换
        const int converted = MultiByteToWideChar(CP_UTF8, 0, UTF8.c_str(), (int)UTF8.size(), &UTF16[0], SizeNeeded);
        if (converted == 0) { return L""; }

        return UTF16;
    }

	WString Utf8ToWide(const String& UTF8)
	{
		if (UTF8.empty()) { return L""; }

		int WideLength = MultiByteToWideChar(CP_UTF8, 0, UTF8.c_str(), -1, nullptr, 0);
		if (WideLength == 0) { return L""; }

		std::wstring wideStr(WideLength - 1, 0);
		MultiByteToWideChar(CP_UTF8, 0, UTF8.c_str(), -1, &wideStr[0], WideLength);

		return wideStr;
	}

    Array<String> SplitUTF8(const String& UTF8)
    {
        Array<String> Result;
        for (size_t i = 0; i < UTF8.size(); )
        {
            // 获取当前字节（转换为无符号以便位操作）
            const BYTE Char = (BYTE)UTF8[i];

            // 字符长度
            size_t CharLength = 1;
            if ((Char & 0xE0) == 0xC0) {
                CharLength = 2; // 2字节字符
            }
            else if ((Char & 0xF0) == 0xE0) {
                CharLength = 3; // 3字节字符
            }
            else if ((Char & 0xF8) == 0xF0) {
                CharLength = 4; // 4字节字符
            }

            // 检查是否有足够的字节
            if (i + CharLength > UTF8.size()) {
                // 无效的UTF-8序列，按单字节处理
                CharLength = 1;
            }

            // 提取字符并添加到结果中
            Result.push_back(UTF8.substr(i, CharLength));
            i += CharLength;
        }
        return Result;
    }

    Array<BYTE> HexToBin(const std::string& Hex)
    {
        Array<BYTE> result;
        std::string hexStr = Hex;

        // 移除所有空格
        hexStr.erase(std::remove(hexStr.begin(), hexStr.end(), ' '), hexStr.end());

        // 检查字符串长度是否为偶数
        if (hexStr.length() % 2 != 0) {
            return result; // 返回空向量
        }

        for (size_t i = 0; i < hexStr.length(); i += 2) {
            std::string BYTEStr = hexStr.substr(i, 2);

            // 转换为大写以便处理
            for (char& c : BYTEStr) {
                c = std::toupper(c);
            }

            // 验证字符是否为有效的十六进制字符
            bool valid = true;
            for (char c : BYTEStr) {
                if (!std::isxdigit(c)) {
                    valid = false;
                    break;
                }
            }

            if (!valid) {
                result.clear();
                return result; // 返回空向量
            }

            // 将两个十六进制字符转换为一个字节
            BYTE byte = static_cast<BYTE>(std::stoul(BYTEStr, nullptr, 16));
            result.push_back(byte);
        }

        return result;
    }

    String BinToHex(const Array<BYTE>& Data)
    {
        std::ostringstream oss;
        for (BYTE BYTE : Data) {
            oss << std::hex << std::uppercase << std::setw(2) << std::setfill('0') << static_cast<int>(BYTE) << " ";
        }
		String HexStr = oss.str();
        if (!HexStr.empty() && HexStr.back() == ' ') {
            HexStr.pop_back(); // 移除最后一个空格
		}
        return HexStr;
    }

    void InsertBin(Array<BYTE>& Data, const Array<BYTE>& Bin)
    {
        Data.insert(Data.begin(), Bin.begin(), Bin.end());
    }

    void AppendBin(Array<BYTE>& Data, const Array<BYTE>& Bin)
    {
        Data.insert(Data.end(), Bin.begin(), Bin.end());
    }

    void InsertHex(Array<BYTE>& Data, const String& Hex)
    {
        Array<BYTE> NewData = HexToBin(Hex);
        Data.insert(Data.begin(), NewData.begin(), NewData.end());
    }

    void AppendHex(Array<BYTE>& Data, const String& Hex)
    {
        Array<BYTE> NewData = HexToBin(Hex);
        Data.insert(Data.end(), NewData.begin(), NewData.end());
    }

    void AppendRaw(Array<BYTE>& Data, const void* Buffer, size_t Size)
    {
        const BYTE* byteBuffer = static_cast<const BYTE*>(Buffer);
		Data.insert(Data.end(), byteBuffer, byteBuffer + Size);
    }

    String I32ToHex(__int32 Value) {
        // 使用小端序：低地址存储低位字节
        unsigned char* bytes = reinterpret_cast<unsigned char*>(&Value);
        std::stringstream ss;
        ss << std::hex << std::setfill('0');

        // 逐个字节处理（小端序：从第一个字节到最后一个字节）
        for (int i = 0; i < 4; ++i) {
            ss << std::setw(2) << static_cast<unsigned int>(bytes[i]);
            if (i < 3) {
                ss << " ";
            }
        }

        return ss.str();
    }

    String Base64Encode(const Array<BYTE>& Data, const String& Table)
    {
        if (Table.size() != 64) { return ""; }

        String Encoded;
        int i = 0;
        int j = 0;
        uint8_t CharArray3[3]{};
        uint8_t CharArray4[4]{};
        size_t in_len = Data.size();
        const uint8_t* bytes_to_encode = Data.data();

        while (in_len--)
        {
            CharArray3[i++] = *(bytes_to_encode++);
            if (i == 3)
            {
                CharArray4[0] = (CharArray3[0] & 0xfc) >> 2;
                CharArray4[1] = ((CharArray3[0] & 0x03) << 4) + ((CharArray3[1] & 0xf0) >> 4);
                CharArray4[2] = ((CharArray3[1] & 0x0f) << 2) + ((CharArray3[2] & 0xc0) >> 6);
                CharArray4[3] = CharArray3[2] & 0x3f;

                for (i = 0; i < 4; i++)
                {
                    Encoded += Table[CharArray4[i]];
                }
                i = 0;
            }
        }

        if (i)
        {
            for (j = i; j < 3; j++)
            {
                CharArray3[j] = '\0';
            }

            CharArray4[0] = (CharArray3[0] & 0xfc) >> 2;
            CharArray4[1] = ((CharArray3[0] & 0x03) << 4) + ((CharArray3[1] & 0xf0) >> 4);
            CharArray4[2] = ((CharArray3[1] & 0x0f) << 2) + ((CharArray3[2] & 0xc0) >> 6);
            CharArray4[3] = CharArray3[2] & 0x3f;

            for (j = 0; j < i + 1; j++)
            {
                Encoded += Table[CharArray4[j]];
            }

            while (i++ < 3)
            {
                Encoded += '=';
            }
        }

        return Encoded;
    }

    Array<BYTE> Base64Decode(const String& B64, const String& Table)
    {
        // 检查Base64表是否有效
        if (Table.size() != 64) { return {}; }

        Array<BYTE> Result;
        int val = 0;
        int valb = -8;

        // 创建反向查找表以提高性能
        uint8_t ReverseTable[256]{};
        for (int i = 0; i < 256; ++i) {
            ReverseTable[i] = 0xFF; // 初始化为无效值
        }
        for (size_t i = 0; i < Table.size(); ++i) {
            ReverseTable[static_cast<uint8_t>(Table[i])] = static_cast<uint8_t>(i);
        }

        for (const BYTE c : B64)
        {
            if (c == '=')
            {
                break; // 遇到填充字符，结束处理
            }

            uint8_t index = ReverseTable[c];
            // 跳过不在Base64表中的字符（如换行符等）
            if (index == 0xFF) { continue; }

            val = (val << 6) + index;
            valb += 6;

            if (valb >= 0)
            {
                Result.push_back(static_cast<BYTE>((val >> valb) & 0xFF));
                valb -= 8;
            }
        }
        return Result;
    }
}