#ifndef ASSEMBLER_HPP
#define ASSEMBLER_HPP
#include "../Program/pch.hpp"
namespace CShang
{
	namespace x86
	{
		enum class Register
		{
			Unk,
			Eax, Ebx, Ecx, Edx,
			Edi, Esi, Esp, Ebp
		};

		class Assembler_T
		{
		public:
			Assembler_T();
			~Assembler_T();

			void ResetPointer();
			void SetPointer(size_t Pos);
			size_t GetPointer() const;

			void DB(BYTE Byte);
			void DW(WORD Word);
			void DD(DWORD DWord);

			size_t GetSize() const;
			const Array<BYTE>& _GetBytes() const;
			// nop
			void Nop();

			// retn
			void Retn();
			// ret
			void Ret_Imm16(uint16_t Value);
			// push���
			
			void Push(Register R, int Offset);
			void Push_Imm8(uint8_t Value);
			void Push_Imm32(uint32_t Value);
			void Push(int32_t Value);
			void Push_U(uint32_t Value);
			void Push(Register R);
			void Pop(Register R);
			
			// mov Eax, 123
			void Mov(Register R, uint32_t Value);
			// mov Eax, Eax
			void Mov(Register A, Register B);
			// mov Eax, [Eax+xxx]
			void Mov(Register A, Register B, int Offset);

			// mov [xxx], Eax
			void Mov(void* Addr, Register V);
			// mov [Eax+xxx], Eax
			void Mov(Register A, int Offset, Register B);
			// mov [Eax+xxx], 123
			void Mov(Register R, int Offset, uint32_t Value);
			
			// void Sub(Register A, uint32_t Value);
			// lea Eax, [Eax+xxx]
			void Lea(Register A, Register B, int Offset);

			// add Eax, 123
			void Add(Register R, int32_t Value);
			// sub Eax, 123
			void Sub(Register R, int32_t Value);

			// Add Eax,Ebx
			void Add(Register A, Register B);
			// Sub Eax,Ebx
			void Sub(Register A, Register B);

			// add Eax, [Eax+xxx]
			void Add(Register A, Register B, int Offset);
			// sub Eax, [Eax+xxx]
			void Sub(Register A, Register B, int Offset);

			// Imul Eax, Eax
			void Imul2(Register A, Register B);
			// Imul Eax, [Ebp-xxx]
			void Imul2(Register A, Register B, int Offset);

			// Imul Eax, Eax, 12345
			void Imul3(Register A, Register B, int32_t Value);
			

			void Call(void* Addr);
			void Call_Dword_Ptr(void* Addr);

		private:
			size_t m_Position = SIZE_MAX;
			Array<BYTE> m_Code;
		};
	}
}
#endif // !ASSEMBLER_HPP