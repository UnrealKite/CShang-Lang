﻿#include "SyntaxPaser.hpp"
namespace CShang
{
	static Token_T InvalidToken = { TokenType::Void, "", { 0, 0 } };

	void SyntaxParser_T::SetTokens(const Array<Token_T>& Tokens)
	{
		m_Tokens = Tokens;
	}

	Space_T* SyntaxParser_T::GetSpace()
	{
		return &m_Space;
	}

	const Space_T* SyntaxParser_T::GetSpace() const
	{
		return &m_Space;
	}

	CodeBlock_T* SyntaxParser_T::GetUnitInitCode()
	{
		return &m_UnitInitCode;
	}

	const CodeBlock_T* SyntaxParser_T::GetUnitInitCode() const
	{
		return &m_UnitInitCode;
	}

	const Array<String>& SyntaxParser_T::GetNeededUnits() const
	{
		return m_NeededUnits;
	}

	bool SyntaxParser_T::Parse()
	{
		try {

			m_CurTokenIndex = SIZE_MAX;
			m_ParsingError.clear();

			Function_T MainFunc(&m_Space);
			ParseCode(&m_Space, &MainFunc.Body, true);

			PrintASTStructure(&MainFunc.Body);
			return true;
		}
		catch (const std::exception& e)
		{
			m_ParsingError = e.what();
			return false;
		}
	}

	const Position_T& SyntaxParser_T::GetErrorPos() const
	{
		if (m_CurTokenIndex < m_Tokens.size()) {
			return m_Tokens[m_CurTokenIndex].Position;
		}
		else {
			static const Position_T InvalidPosition{ 0, 0 };
			return InvalidPosition;
		}
	}

	const String& SyntaxParser_T::GetErrorMsg() const
	{
		return m_ParsingError;
	}

	const Token_T& SyntaxParser_T::_PeekToken(intptr_t Pos) const
	{
		// 计算绝对索引位置
		size_t CurIndex = ((m_CurTokenIndex == SIZE_MAX && !m_Tokens.empty()) ? -1 : m_CurTokenIndex);

		// 处理负的 Pos 值（向后查找）
		intptr_t TargetIndex;
		if (Pos >= 0) {
			TargetIndex = static_cast<intptr_t>(CurIndex) + Pos;
		}
		else {
			// Pos 为负，表示从当前位置向前回溯
			TargetIndex = static_cast<intptr_t>(CurIndex) + Pos;
		}

		// 检查索引是否有效
		if (TargetIndex >= 0 && TargetIndex < static_cast<intptr_t>(m_Tokens.size())) {
			return m_Tokens[static_cast<size_t>(TargetIndex)];
		}
		else {
			return InvalidToken;
		}
	}
	
	const Token_T& SyntaxParser_T::_CurToken() const
	{
		if (m_CurTokenIndex < m_Tokens.size()) {
			return m_Tokens[m_CurTokenIndex];
		}
		else {
			return InvalidToken;
		}
	}

	const Token_T& SyntaxParser_T::_NextToken()
	{
		if ((m_CurTokenIndex == SIZE_MAX && !m_Tokens.empty()) || m_CurTokenIndex + 1 < m_Tokens.size()) {
			++m_CurTokenIndex;
			return m_Tokens[m_CurTokenIndex];
		}
		else {
			return InvalidToken;
		}
	}

	const Token_T& SyntaxParser_T::_LastToken()
	{
		if (m_CurTokenIndex > 0 && m_CurTokenIndex <= m_Tokens.size()) {
			--m_CurTokenIndex;
			return m_Tokens[m_CurTokenIndex];
		}
		else if (m_CurTokenIndex == 0) {
			m_CurTokenIndex = SIZE_MAX;
		}
		return InvalidToken;
	}

	// 后续可能会改...
	Array<const Token_T*> SyntaxParser_T::ParseBracketKeys()
	{
		const Token_T& Begin = _CurToken();
		if (Begin.Type != TokenType::LP) {
			throw Exception(u8"预期\"(\"\"，" + ERROR_MSG_BUTGOT(Begin));
		}
		Array<const Token_T*> Result;
		while (true)
		{
			const Token_T& NextToken = _NextToken();

			if (NextToken.Type != TokenType::COM_String) {
				throw Exception(u8"括号内的键必须是字符串，" + ERROR_MSG_BUTGOT(NextToken));
			}
			Result.push_back(&NextToken);
			const Token_T& Delimiter = _NextToken();
			if (Delimiter.Type == TokenType::Comma) {
				continue;
			}
			else if (Delimiter.Type == TokenType::RP) {
				break;
			}
		}
		return Result;
	}

	// 已弃用
	bool SyntaxParser_T::ParseSpaceMember(Space_T* Space)
	{
		const Token_T& FirstToken = _NextToken();
		const Token_T& LastToken = _NextToken();

		_LastToken();

		if (LastToken.Type == TokenType::Colon) {
			_LastToken();
			//_ParseVariable(Space);
			return true;
		}

		if (FirstToken.Type == TokenType::Void) {
			return false;
		}

		if (FirstToken.Value == u8"函数") {
			_ParseFunction(Space);
		}
		else if (FirstToken.Value == u8"结构") {
			_ParseStructure(Space);
		}
		else if (FirstToken.Value == u8"类") {
			_ParseClass(Space);
		}
		else if (FirstToken.Value == u8"构造") {
			const SpaceMemberType T =
				Space->Parent == nullptr
				? SpaceMemberType::MainSpace
				: Space->Parent->GetMemberType();

			if (T != SpaceMemberType::Class) {
				throw Exception(u8"\"构造\"只能在类中使用。");
			}
			// 和函数类似，先按函数解析
			_ParseFunction(Space, TAG_FUNCTION_CONSTRUCTOR);
		}
		else if (FirstToken.Value == u8"析构") {
			const SpaceMemberType T =
				Space->Parent == nullptr
				? SpaceMemberType::MainSpace
				: Space->Parent->GetMemberType();

			if (T != SpaceMemberType::Class) {
				throw Exception(u8"\"析构\"只能在类中使用。");
			}
			// 和函数类似，先按函数解析
			_ParseFunction(Space, TAG_FUNCTION_DESTRUCTOR);
		}
		else {
			throw Exception(u8"预期关键字，" + ERROR_MSG_BUTGOT(FirstToken));
		}
		return true;
	}

	// 后续可能会改...
	PTypeDesc SyntaxParser_T::_ParseType()
	{
		const Token_T& TypeToken = _NextToken();
		if (TypeToken.Type == TokenType::COM_Ident) {
			return TypeDesc_T::Create(TypeToken.Value);
		}
		throw Exception(u8"类型必须是标识符，" + ERROR_MSG_BUTGOT(TypeToken));
	}

	String SyntaxParser_T::_ParseNameAndOptions(SpaceMember_T* Member)
	{
		const Token_T& Name = _NextToken();
		if (Name.Type != TokenType::COM_Ident) {
			throw Exception(u8"应输入标识符，" + ERROR_MSG_BUTGOT(Name));
		}
		// 可选：选项
		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type == TokenType::LA) {
			while (true) {
				const Token_T& NextToken = _NextToken();
				if (NextToken.Type == TokenType::RA) {
					break;
				}
				else if (NextToken.Type == TokenType::COM_Ident) {
					Array<String> Params;
					// 处理属性参数
					const Token_T& AfterAttr = _NextToken();
					if (AfterAttr.Type == TokenType::LP) {
						const auto& _Params = ParseBracketKeys();
						for (const auto& Param : _Params) {
							Params.push_back(Param->Value);
						}
					}
					else if (AfterAttr.Type == TokenType::RA) {
						break;
					}
					Member->AddOption(NextToken.Value, Params);

					const Token_T& Delimiter = _NextToken();
					if (Delimiter.Type == TokenType::Comma) {
						continue;
					}
					else if (Delimiter.Type == TokenType::RA) {
						break;
					}
					else {
						throw Exception(u8"函数属性之间必须用逗号分隔，" + ERROR_MSG_BUTGOT(Delimiter));
					}
				}
				else {
					throw Exception(u8"函数属性必须是标识符，" + ERROR_MSG_BUTGOT(NextToken));
				}
			}
		}
		else {
			_LastToken();
		}

		return Name.Value;
	}

	String SyntaxParser_T::_ParseVariable(Space_T* Space, CodeBlock_T* Block, LONG_PTR Tag)
	{
		Variable_T* NewVar = new Variable_T();
		// 变量名
		const String Name = _ParseNameAndOptions(NewVar);

		// :
		const Token_T& Delimiter = _NextToken();
		if (Delimiter.Type != TokenType::Colon) {
			throw Exception(u8"变量声明后必须是冒号，" + ERROR_MSG_BUTGOT(Delimiter));
		}

		// 类型
		NewVar->TypeDesc = _ParseType();
		
		// 废弃：
		//// 可选：变量初始值
		//const Token_T& Begin = _NextToken();
		//if (Begin.Type == TokenType::Assign) {
		//	const Token_T& Value = _NextToken();
		//}
		//else {
		//	_LastToken();
		//}
		
		// 可选：变量初始值
		if (_PeekToken().Type == TokenType::Assign) {
			//_NextToken();
			Identifier_T* Ident = new Identifier_T();
			Ident->Name = Name;
			Block->AddTempNode(Ident);
			Block->Parsing_LastIsAtomic = true;
			ParseExpression(Space, Block);
		}

		Space->AddVariable(Name, NewVar);
		return Name;
	}

	void SyntaxParser_T::_ParseFunction(Space_T* Space, LONG_PTR Tag)
	{
		const Token_T& First = _NextToken();
		if (First.Value != u8"函数") {
			throw Exception(u8"预期“函数”，" + ERROR_MSG_BUTGOT(First));
		}

		Function_T* NewFunc = new Function_T(Space);
		NewFunc->Tag = Tag;

		// 函数名
		const String Name = _ParseNameAndOptions(NewFunc);

		// 解析参数列表
		const Token_T& LeftBracket1 = _NextToken();
		if (LeftBracket1.Type != TokenType::LP) {
			throw Exception(u8"函数名后必须是左括号，" + ERROR_MSG_BUTGOT(LeftBracket1));
		}
		
		auto Parameters = _ParseParametersOrResults();
		for (const auto& Param : Parameters) {
			NewFunc->AddParam(Param.second, Param.first);
		}
		
		const Token_T& LeftBracket2 = _NextToken();
		if (LeftBracket2.Type != TokenType::RP) {
			throw Exception(u8"预期右括号，" + ERROR_MSG_BUTGOT(LeftBracket2));
		}

		// 调试打印参数
#ifdef TEST_DEBUGPRINT
		printf(u8"参数列表：\n");
		for (const auto& Param : NewFunction->GetParams())
		{
			if (Param.second.empty()) {
				const TypeDescType TypeDesc = Param.first->GetType();
				switch (TypeDesc)
				{
				case TypeDescType::Named: {
					const TypeDescNamed_T* NamedType = dynamic_cast<const TypeDescNamed_T*>(Param.first);
					printf("Param: TypeDesc: %s, Name: <anonymous>\n", NamedType->GetTypeName().c_str());
					break;
				}
				default:
					printf("Param: TypeDesc: UnknownType, Name: <anonymous>\n");
					break;
				}
			}
			else {
				const TypeDescType TypeDesc = Param.first->GetType();
				switch (TypeDesc)
				{
				case TypeDescType::Named: {
					const TypeDescNamed_T* NamedType = dynamic_cast<const TypeDescNamed_T*>(Param.first);
					printf("Param: TypeDesc: %s, Name: %s\n", NamedType->GetTypeName().c_str(), Param.second.c_str());
					break;
				}
				default:
					printf("Param: TypeDesc: UnknownType, Name: %s\n", Param.second.c_str());
					break;
				}
			}
		}
#endif

		// 结果类型
		if (_PeekToken().Type == TokenType::ResultType) {
			_NextToken();
			auto Results = _ParseParametersOrResults();
			for (const auto& Result : Results) {
				NewFunc->AddResult(Result.second, Result.first);
			}
		}

		// 是否有代码实现
		if (_PeekToken().Type == TokenType::LB) {
			CodeBlock_T* Block = &NewFunc->Body;
			ParseCode(&m_Space, Block);
			PrintASTStructure(Block);
		}

		// const String Symbol = Space->GetAccessName() +  + "@" +
		Space->Functions[Name].push_back(NewFunc);
	}

	SyntaxParser_T::ParameterList SyntaxParser_T::_ParseParametersOrResults()
	{
		ParameterList Result;
		while (true) {
			const Token_T& Tk = _NextToken();
			if (Tk.Type != TokenType::COM_Ident) {
				_LastToken();
				break;
			}
			
			Parameter Param;

			// 是否为占位元素（占位元素无名）
			const Token_T& Next = _NextToken();
			if (Next.Type != TokenType::Colon) {
				Param.second = TypeDesc_T::Create(Tk.Value);
				_LastToken();
			}
			else {
				Param.first = Tk.Value;
				Param.second = _ParseType();
			}

			Result.push_back(Param);

			const Token_T& Tk2 = _NextToken();
			if (Tk2.Type != TokenType::Comma) {
				_LastToken();
				break;
			}
		}
		return Result;
	}

	void SyntaxParser_T::_ParseFunctionParam(Function_T* Function)
	{
		const Token_T& Begin = _NextToken();
		const Token_T& Next = _NextToken();
		// 正常的参数
		if (Next.Type == TokenType::Colon)
		{
			if (Begin.Type != TokenType::COM_Ident) {
				throw Exception(u8"函数参数名必须是标识符，" + ERROR_MSG_BUTGOT(Begin));
			}
			Function->AddParam(_ParseType(), Begin.Value);
		}
		// 占位的未命名参数
		else {
			_LastToken();
			_LastToken();
			Function->AddParam(_ParseType());
		}
	}

	void SyntaxParser_T::_ParseStructure(Space_T* Space)
	{
		const Token_T& First = _NextToken();
		if (First.Value != u8"结构") {
			throw Exception(u8"预期“结构”，" + ERROR_MSG_BUTGOT(First));
		}
		Structure_T* NewStructure = new Structure_T(Space);
		// 结构名
		const String Name = _ParseNameAndOptions(NewStructure);
		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type != TokenType::LB) {
			throw Exception(u8"预期“{”，" + ERROR_MSG_BUTGOT(LeftBracket));
		}
		while (true) {
			CodeBlock_T Block;
			_ParseVariable(&NewStructure->Space, &Block);
			const Token_T& NextToken = _NextToken();
			if (NextToken.Type == TokenType::RB) {
				break;
			}
			else if (NextToken.Type != TokenType::Comma) {
				throw Exception(u8"预期“,”，" + ERROR_MSG_BUTGOT(LeftBracket));
			}
		}
		Space->Structures[Name] = NewStructure;
	}

	void SyntaxParser_T::_ParseClass(Space_T* Space)
	{
		Class_T* NewClass = new Class_T(Space);
		// 类名
		const String Name = _ParseNameAndOptions(NewClass);

		const Token_T& LeftBracket = _NextToken();
		if (LeftBracket.Type != TokenType::LB) {
			throw Exception(u8"预期“{”，" + ERROR_MSG_BUTGOT(LeftBracket));
		}
		while (true) {
			const Token_T& NextToken = _NextToken();
			if (NextToken.Type == TokenType::RB) {
				break;
			}
			else {
				_LastToken();
			}
			if (!ParseSpaceMember(&NewClass->Space)) {
				throw Exception(u8"意外结尾。");
			}
		}
		Space->Classes[Name] = NewClass;
	}

	static bool IsAtomicToken(const Token_T& Tk)
	{
		static Set<TokenType> Atomics
		{
			TokenType::COM_Ident,
			TokenType::Integer,
			TokenType::COM_String,
			//TokenType::LP,
			TokenType::RB
		};
		return Atomics.find(Tk.Type) != Atomics.end();
	}

	static void RecursiveBinaryRootRightAndSet(BinaryExpression_T* Binary, ASTNode_T* Node)
	{
		if (Binary->Right) {
			if (Binary->Right->GetType() == ASTNodeType::BinaryExpression) {
				RecursiveBinaryRootRightAndSet((BinaryExpression_T*)Binary->Right, Node);
			}
			else {
				throw Exception(u8"暂未支持");
			}
		}
		else {
			Binary->Right = Node;
		}
	}

	static bool IsPriorityHigh(BinOp_E A, BinOp_E B)
	{
		static Map<BinOp_E, int> Prioritys
		{
			{ BinOp_E::MAcc, 10 }, // 成员访问

			{ BinOp_E::Mul, 20 }, // *
			{ BinOp_E::Div, 20 }, // /

			{ BinOp_E::Add, 30 }, // +
			{ BinOp_E::Sub, 30 }, // -

			{ BinOp_E::And, 40 }, // &
			{ BinOp_E::Or, 40 },  // #
			{ BinOp_E::Xor, 40 }, // ~#

			{ BinOp_E::Assign, 4 } // =
		};
		return Prioritys[A] < Prioritys[B];
	}

	static BinaryExpression_T* FindLastPriorityLowRootBinary(BinaryExpression_T* Binary, BinOp_E Op)
	{
		if (!IsPriorityHigh(Op, Binary->Operator)) {
			return nullptr;
		}
		if (Binary->Right && Binary->Right->GetType() == ASTNodeType::BinaryExpression && !((BinaryExpression_T*)Binary->Right)->IsAtomicity) {
			BinaryExpression_T* Right = (BinaryExpression_T*)Binary->Right;
			BinaryExpression_T* Result = FindLastPriorityLowRootBinary(Right, Op);
			if (Result) {
				return Result;
			}
			if (IsPriorityHigh(Op, Right->Operator)) {
				return nullptr;
			}
		}
		return Binary;
	}

	// 找到上一个优先级低于xxx的临时根token（用于括号处理）
	static BinaryExpression_T* FindLastPriorityLowRootToken(CodeBlock_T* Block, int Priority)
	{
		//暂未实现
	}

	static BinOp_E TokenTypeToBinOp(TokenType Type)
	{
		switch (Type) {
		case TokenType::Add: return BinOp_E::Add;
		case TokenType::Sub: return BinOp_E::Sub;
		case TokenType::Mul: return BinOp_E::Mul;
		case TokenType::Div: return BinOp_E::Div;

		case TokenType::BitAnd: return BinOp_E::And;
		case TokenType::BitOr:  return BinOp_E::Or;
		case TokenType::BitXor: return BinOp_E::Xor;

		case TokenType::Assign:
			return BinOp_E::Assign; break;
		case TokenType::Dot:
			return BinOp_E::MAcc; break;
		}
		return BinOp_E::Unknown;
	}

	void SyntaxParser_T::ParseCode(Space_T* Space, CodeBlock_T* Block, bool IsTopSpace)
	{
		if (!IsTopSpace && _NextToken().Type != TokenType::LB) {
			throw Exception(u8"代码块必须以“{”开头。");
		}

		while (true)
		{
			const Token_T& Tk = _PeekToken();
			// 右代码块
			if (Tk.Type == TokenType::COM_Ident) {
				// 因为关键字暂时是当作标识符处理
				if (Tk.Value == u8"函数") {
					_ParseFunction(Space);
					continue;
				}
				else if (Tk.Value == u8"结构") {
					_ParseStructure(Space);
					continue;
				}
				// 变量定义
				else {
					const Token_T& Tk = _PeekToken(2);
					if (Tk.Type == TokenType::Colon) {
						_ParseVariable(Space, Block);
						continue;
					}
				}
			}
			else if (Tk.Type == TokenType::RB) {
				if (IsTopSpace) {
					throw Exception(u8"此处不因出现“}”");
				}
				_NextToken(); // 吞掉“}”
				break;
			}
			else if (Tk.Type == TokenType::Void) {
				if (!IsTopSpace) {
					throw Exception(u8"意外结尾。");
				}
				break;
			}

			ParseExpression(Space, Block);
		}
	}

	ASTNode_T* SyntaxParser_T::ParseExpression(Space_T* Space, CodeBlock_T* Block, bool IsAtomicity)
	{
		while (true)
		{
			const Token_T& Tk = _PeekToken();
			bool CurIsAtomic = IsAtomicToken(Tk);
			bool IsCompleted = CurIsAtomic && Block->Parsing_LastIsAtomic;
			// 如果 连续2个token 或 结尾了 则 表示表达式已结束
			if (IsCompleted || Tk.Type == TokenType::Void) {
				break;
			}
			Block->Parsing_LastIsAtomic = CurIsAtomic;
			_NextToken();
			// 处理括号
			if (Tk.Type == TokenType::LP) {
				if (!Block->Parsing_LastTk) {
					throw Exception(u8"此处不应出现“(”");
				}
				// 函数调用
				if (Block->Parsing_LastTk->Type == TokenType::COM_Ident)
				{
					auto* Calling = new CallingStatement_T();
					ASTNode_T* Back = Block->GetSubBack();
					if (!Back) {
						throw Exception(u8"内部错误");
					}
					if (Back->GetType() == ASTNodeType::Identifier) {
						Calling->Source = Back;
					}
					//FindLastPriorityLowRootToken(Block, 25);
				}
				// 原子表达式
				else if (IsBinOpToken(Block->Parsing_LastTk->Type))
				{
					CodeBlock_T TempBlock;
					ASTNode_T* Node = ParseExpression(Space, &TempBlock, true);
					if (_NextToken().Type != TokenType::RP) {
						throw Exception(u8"括号内只能有一条语句。");
					}
					Block->AddTempNode(Node);
				}
				else {
					throw Exception(u8"此处不应出现“(”");
				}
			}

			// 反括号
			else if (Tk.Type == TokenType::RP) {
				if (!IsAtomicity) {
					throw Exception(u8"非法Token“)”。");
				}
				_LastToken();
				return Block->GetTempBack();
			}
			else {
				HandleToken(Block, Tk, IsAtomicity);
			}
			Block->Parsing_LastTk = &Tk;
		}
		// 转正所有临时节点
		Block->FormatTempNodes();
		// 重置状态
		Block->Parsing_LastIsAtomic = false;
		return Block->GetSubBack();
	}

	void SyntaxParser_T::HandleBrackets()
	{
	}

	void SyntaxParser_T::HandleToken(CodeBlock_T* Block, const Token_T& Tk, bool IsAtomicity)
	{
		switch (Tk.Type)
		{
		case TokenType::COM_Ident: {
			auto* Ident = new Identifier_T();
			Ident->Name = Tk.Value;
			HandleAtomicToken(Block, Ident);
			break;
		}

		case TokenType::Integer: {
			auto* Int = new LiteralInteger_T();
			Int->Value = std::stoull(Tk.Value);
			HandleAtomicToken(Block, Int);
			break;
		}

		case TokenType::COM_String: {
			auto* Str = new LiteralString_T();
			Str->Value = Tk.Value;
			HandleAtomicToken(Block, Str);
			break;
		}

		case TokenType::Add: case TokenType::Sub:
		case TokenType::Mul: case TokenType::Div:
		case TokenType::BitAnd:
		case TokenType::BitOr:
		case TokenType::BitXor:
		case TokenType::Assign:
		case TokenType::Dot:
		{
			BinOp_E Op = TokenTypeToBinOp(Tk.Type);
			BinaryExpression_T* Bin = nullptr;
			switch (Op) {
				// 四则运算
			case BinOp_E::Add: case BinOp_E::Sub:
			case BinOp_E::Mul: case BinOp_E::Div:
				Bin = new FourBinExpression_T();
				break;
				// 位运算
			case BinOp_E::And: case BinOp_E::Or:
			case BinOp_E::Xor:
				Bin = new BitBinExpression_T();
				break;
				// 赋值
			case BinOp_E::Assign:
				Bin = new AssignStatement_T();
				break;
			case BinOp_E::MAcc:
				Bin = new MemberAccess_T();
				break;
			default:
				throw Exception(u8"内部错误");
			}
			Bin->Operator = Op;
			Bin->IsAtomicity = IsAtomicity;
			HandleBinaryOperator(Block, Bin);
			break;
		}
		default:
			throw Exception(u8"表达式中的意外token：“" + Tk.Value + u8"”");
		}
	}

	void SyntaxParser_T::HandleAtomicToken(CodeBlock_T* Block, ASTNode_T* Node)
	{
		ASTNode_T* Back = Block->GetTempBack();
		if (Back) {
			// 如果尾部有节点，而且是二元表达式，则递归这个表达式，在空闲的右根节点插入原子
			if (auto* Back1 = dynamic_cast<BinaryExpression_T*>(Back)) {
				RecursiveBinaryRootRightAndSet((BinaryExpression_T*)Back1, Node);
			}
			else {
				throw Exception(u8"暂未支持");
			}
			return;
		}
		else if (Node->GetType() != ASTNodeType::Identifier) {
			throw Exception(u8"非法表达式");
		}

		Block->AddTempNode(Node);
	}

	void SyntaxParser_T::HandleBinaryOperator(CodeBlock_T* Block, BinaryExpression_T* Binary)
	{
		ASTNode_T* Back = Block->GetTempBack();
		if (Back == nullptr) {
			throw Exception(u8"左边不能为空。");
		}
		// 最后一个临时节点是二元表达式
		if (Back->GetType() == ASTNodeType::BinaryExpression) {
			auto Root = FindLastPriorityLowRootBinary((BinaryExpression_T*)Back, Binary->Operator);
			if (Root) {
				Binary->Left = Root->Right;
				Root->Right = Binary;
				return;
			}
		}
		Binary->Left = Back;
		Block->PopTempBack();
		Block->AddTempNode(Binary);
	}
}