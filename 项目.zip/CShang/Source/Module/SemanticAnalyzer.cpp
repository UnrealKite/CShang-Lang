﻿#include "SemanticAnalyzer.hpp"
#include "ObjectFile.hpp"
namespace CShang
{
	void SemanticAnalyzer_T::SetSpace(Space_T* Space)
	{
		m_Space = Space;
	}

	bool SemanticAnalyzer_T::Analyzer()
	{
		// ExceptionTest();
		AnalyzerSpace(m_Space);
		return m_Errors.empty();
	}

	const Array<SAException_T>& SemanticAnalyzer_T::GetErrors() const
	{
		return m_Errors;
	}

	const Array<SAException_T>& SemanticAnalyzer_T::GetWarnings() const
	{
		return m_Warnings;
	}

	const Array<SAException_T>& SemanticAnalyzer_T::GetInfos() const
	{
		return m_Infos;
	}

	void SemanticAnalyzer_T::PushException(const String& Message, SAException_T::EType Type)
	{
		SAException_T Exception;
		Exception.Type = Type;
		Exception.Message = Message;
		Exception.Position = {};

		switch (Type)
		{
		case SAException_T::EType::Error:
			m_Errors.push_back(Exception);
			break;
		case SAException_T::EType::Warning:
			m_Warnings.push_back(Exception);
			break;
		case SAException_T::EType::Info:
			m_Infos.push_back(Exception);
			break;
		}
	}

	void SemanticAnalyzer_T::ExceptionTest()
	{
		PushException(u8"这是一个错误！", SAException_T::EType::Error);
		PushException(u8"这是一个警告！", SAException_T::EType::Warning);
		PushException(u8"这是一个提示！", SAException_T::EType::Info);
	}

	void SemanticAnalyzer_T::AnalyzerSpace(Space_T* Space)
	{
		auto& Variables = Space->GetVariables();
		auto& Functions = Space->Functions;
		auto& Classes = Space->Classes;

		// 处理所有变量
		for (auto& Variable : Variables) {
			const String& Name = Variable.first;
			Variable_T* Var = Variable.second;
			AnalyzerTypeDesc(&Var->TypeDesc, Space);
		}

		// 处理所有函数
		for (const auto& ReloadFuncs : Functions) {
			const String& Name = ReloadFuncs.first; // 函数名
			// 重载的函数实例
			for (const auto& Func : ReloadFuncs.second) {
				// 处理结果类型
				//AnalyzerTypeDesc(&Func->ResultType, Space);
				// 不是导入函数
				if (Func->GetOption(u8"导入") == nullptr) {
					AnalyzerSpace(&Func->Space);
					// 处理所有语句
					const CodeBlock_T* Body = &Func->Body;
					for (const auto& Node : Body->GetSubNodes()) {
						// 只用管调用、赋值语句
						const ASTNodeType Type = Node->GetType();
						if (Type == ASTNodeType::CallingStatement) {
							const CallingStatement_T* Calling = dynamic_cast<const CallingStatement_T*>(Node);
							AnalyzeStatement_Calling(Func, Calling);
						}
						else if (Type == ASTNodeType::BinaryExpression) {
							AssignStatement_T* Assign = dynamic_cast<AssignStatement_T*>(Node);
							AnalyzeStatement_Assign(Func, Assign);
						}
					}
					
				}
			}
		}
	}

	const Variable_T* SemanticAnalyzer_T::FindVariable(const Function_T* Func, const String& Name)
	{
		// 从函数局部变量中查找
		const Variable_T* Variable = Func->Space.FindVariable(Name);
		if (Variable != nullptr) {
			// ...
			return Variable;
		}
		// 从函数参数中查找
		Variable = Func->FindParam(Name);
		if (Variable != nullptr) {
			// ...
			return Variable;
		}
		// 从全局变量中查找
		return FindVariableFromParent(Func->Parent, Name);
	}

	const Variable_T* SemanticAnalyzer_T::FindVariableFromParent(const Space_T* Space, const String& Name)
	{
		if (Space == nullptr) { return nullptr; }
		const Variable_T* VarObj = Space->FindVariable(Name);
		if (VarObj != nullptr) { return VarObj; }
		//FindVariableFromParent(Space->Parent, Name);
		return nullptr;
	}

	SpaceMember_T* SemanticAnalyzer_T::FindTypeFromSpace(const Space_T* Space, const String& Name)
	{
		// 先从当前空间查找：
		// 结构体？
		for (const auto& Class : Space->Classes) {
			if (Class.first == Name) {
				return Class.second;
			}
		}
		// 类？
		for (const auto& Structure : Space->Structures) {
			if (Structure.first == Name) {
				return Structure.second;
			}
		}
		if (Space->Parent == nullptr) { return nullptr; }
		// 当前空间未找到，看看当前空间所属的父对象是什么
		const SpaceMemberType T = Space->Parent->GetMemberType();
		if (T == SpaceMemberType::Function) {
			return FindTypeFromSpace(Space->Parent->Parent, Name);
		}
		return nullptr;
	}

	void SemanticAnalyzer_T::AnalyzerTypeDesc(PTypeDesc* pResult, const Space_T* Space)
	{
		PTypeDesc TD = pResult ? *pResult : nullptr;
		if (!TD) {
			PushException("[" __FUNCTION__ u8"]内部函数参数错误。");
			return;
		}
		
		const String& Name = TD->Name;
		if (Name == u8"整数型" || Name == u8"字符串") {
			TD->Type = TypeDescType::Base;
			return;
		}

		// 如果不是基础类型，就尝试从定义中查找
		SpaceMember_T* Definition = FindTypeFromSpace(Space, Name);
		if (Definition == nullptr) {
			PushException(u8"类型“" + Name + u8"”的定义未找到。");
		}

		TD->DefinitionPtr = Definition;
	}

	void SemanticAnalyzer_T::AnalyzeStatement_Calling(Function_T* Func, const CallingStatement_T* Calling)
	{
		
	}
	
	void SemanticAnalyzer_T::AnalyzeStatement_Assign(Function_T* Func, AssignStatement_T* Assign)
	{
		ASTNode_T* Target = Assign->Left;
		ASTNode_T* Value = Assign->Right;
		if (Target == nullptr) {
			PushException(u8"赋值目标不能为空。", SAException_T::EType::Error);
			return;
		}
		if (Value == nullptr) {
			PushException(u8"值节点不能为空。", SAException_T::EType::Error);
			return;
		}

		const ASTNodeType TargetType = Target->GetType();

		if (TargetType == ASTNodeType::LiteralInteger || TargetType == ASTNodeType::LiteralString) {
			PushException(u8"不能对常量进行赋值。", SAException_T::EType::Error);
			return;
		}

		if (TargetType != ASTNodeType::Identifier) {
			/*if (TargetType == ASTNodeType::MemberAccess) {
				const MemberAccess_T* MemberAcc = (const MemberAccess_T*)Target;
				AnalyzeExpression_MemberAccess(Func, MemberAcc);
			}
			else {
				PushException(u8"不受支持的赋值目标。", SAException_T::EType::Error);
			}
			return;*/
		}

		// 查找变量

		Identifier_T* Identifier = (Identifier_T*)Target;
		const String& Name = Identifier->GetName();
		if (Name == u8"结果") {
			// ...
			return;
		}
		const Variable_T* Variable = FindVariable(Func, Name);
		if (Variable == nullptr) {
			PushException(u8"未定义标识符“" + Name + u8"”", SAException_T::EType::Error);
		}

		// 右值节点
		AnalyzerNode_Right(&Assign->Right, Value);
	}

	void SemanticAnalyzer_T::AnalyzeExpression_MemberAccess(const Function_T* Func, const MemberAccess_T* MemberAcc)
	{
		const ASTNode_T* Source = MemberAcc->Left;
		const ASTNodeType Type = Source->GetType();
		/*if (Type == ASTNodeType::MemberAccess) {
			const MemberAccess_T* MemberAcc_Source = (const MemberAccess_T*)Source;
			AnalyzeExpression_MemberAccess(Func, MemberAcc_Source);
		}*/
		const Identifier_T* Member = dynamic_cast<Identifier_T*>(MemberAcc->Right);
		const String& MemberName = Member->GetName();
		// 这是访问源头，先查找此变量
		if (Type == ASTNodeType::Identifier) {
			const Identifier_T* Identifier = (const Identifier_T*)Source;
			const String& Name = Identifier->GetName();
			const Variable_T* VarObj = FindVariable(Func, Name);
			// 检查是否有成员
			const SpaceMember_T* Definition = VarObj->TypeDesc->DefinitionPtr;
			SpaceMemberType DefType = Definition->GetMemberType();
			// 结构体
			if (DefType == SpaceMemberType::Structure) {
				const Structure_T* Structure = (const Structure_T*)Definition;
				Variable_T* VarObj = Structure->Space.FindVariable(MemberName);
				if (VarObj == nullptr) {
					PushException(u8"类“" + Name + u8"”没有成员“" + MemberName + u8"”。", SAException_T::EType::Error);
				}
			}
		}
		else {
			PushException(u8"不受支持的成员访问源。", SAException_T::EType::Error);
		}
	}

	void SemanticAnalyzer_T::AnalyzerNode_Right(ASTNode_T** Parent, ASTNode_T* Value)
	{
		ASTNodeType Type = Value->GetType();
		/*if (Type == ASTNodeType::ForBinExpression) {
			BinaryExpression_T* Binary = (BinaryExpression_T*)(Value);
			AnalyzeExpression_Binary(Parent, Binary);
		}*/
	}

	void SemanticAnalyzer_T::AnalyzeExpression_Binary(ASTNode_T** Parent, BinaryExpression_T* Binary)
	{
		ASTNode_T* Left = Binary->Left;
		ASTNode_T* Right = Binary->Right;
		if (Left == nullptr) {
			PushException(u8"左操作数不能为空。", SAException_T::EType::Error);
			return;
		}
		if (Right == nullptr) {
			PushException(u8"右操作数不能为空。", SAException_T::EType::Error);
			return;
		}
		const ASTNodeType LeftType = Left->GetType();
		const ASTNodeType RightType = Right->GetType();

		if (LeftType == ASTNodeType::LiteralInteger) {
			if (RightType == ASTNodeType::LiteralInteger) {
				__int64 LeftValue = ((LiteralInteger_T*)Left)->GetValue();
				__int64 RightValue = ((LiteralInteger_T*)Right)->GetValue();
				__int64 Result = 0;
				switch (Binary->Operator)
				{
				case BinOp_E::Add:
					Result = LeftValue + RightValue; break;
				case BinOp_E::Sub:
					Result = LeftValue - RightValue; break;
				case BinOp_E::Mul:
					Result = LeftValue * RightValue; break;
				case BinOp_E::Div:
					Result = LeftValue / RightValue; break;
				}
				delete Binary;
				Binary = nullptr;
				LiteralInteger_T* NewValue = new LiteralInteger_T();
				NewValue->SetValue(Result);
				*Parent = NewValue;
			}
			else {
				std::swap(Binary->Left, Binary->Right);
			}
		}
		if (LeftType == ASTNodeType::BinaryExpression) {
			BinaryExpression_T* LeftBinary = (BinaryExpression_T*)Left;
			AnalyzeExpression_Binary(&Binary->Left, LeftBinary);
		}
	}
}