﻿#include "CodeGenerator.hpp"
#include "ObjectFile.hpp"
#include "Helper.hpp"
namespace CShang
{
	/*
	* @brief: 设置输入的空间
	*/
	void CodeGenerator_T::SetSpace(const Space_T* Space)
	{
		m_Space = Space;
	}
	
	/*
	* @brief: 设置单元初始化代码
	*/
	void CodeGenerator_T::SetUnitInitCode(const CodeBlock_T* Block)
	{
		m_UnitInitCode = Block;
	}

	/*
	* @brief: 设置输出的文件
	*/
	void CodeGenerator_T::SetOutputFile(const String& Path)
	{
		m_OutputFile = Path;
	}

	/*
	* @brief: 生成
	* @return: 生成是否成功
	*/
	bool CodeGenerator_T::Generate()
	{
		try {
			ObjectFile_T ObjFile;
			GenerateUnit(&ObjFile, m_Space);
			if (!ObjFile.SaveToFile(m_OutputFile)) {
				throw Exception(u8"文件保存失败！");
			}
			return true;
		}
		catch (const std::exception& e) {
			m_ErrorMsg = e.what();
			return false;
		}
	}

	/*
	* @brief: 取失败消息
	* @return: 失败消息
	*/
	const String& CodeGenerator_T::GetErrorMsg() const
	{
		return m_ErrorMsg;
	}

	/*
	* @brief: 生成单元的.obj文件
	* @param: .obj文件对象
	* @param: 该单元的空间
	*/
	void CodeGenerator_T::GenerateUnit(ObjectFile_T* ObjFile, const Space_T* Space)
	{
		String AccSymbol = Space->GetAccessName();
		if (!AccSymbol.empty()) {
			AccSymbol += ".";
		}
		// 所有函数
		for (const auto& ReloadFunc : Space->Functions) {
			const String& Name = ReloadFunc.first;
			for (const auto& Func : ReloadFunc.second) {
				// 不是导入函数
				if (Func->GetOption(u8"导入") == nullptr) {
					ObjFuncRelocates_T* Relocates = new ObjFuncRelocates_T;
					x86::Assembler_T Assembler;
					GeneratorParam_T Param;
					Param.Assembler = &Assembler;
					Param.Function = Func;
					Param.Relocates = Relocates;
					GenerateRealFuncBody(&Param);
					// 添加函数到ObjFile
					const String Symbol = AccSymbol + Name + "@" + Func->GetFeatureDesc();
					ObjFile->AddFunction(Symbol, Assembler._GetBytes(), Relocates);
					printf("%s\n", BinToHex(Assembler._GetBytes()).c_str());
				}
			}
		}
		// 所有类
		for (const auto& Class : Space->Classes) {
			const String& Name = Class.first;
			const Class_T* ClassObj = Class.second;
			GenerateUnit(ObjFile, &ClassObj->Space);
		}
	}

	Tuple<Variable_T*, int, int> CodeGenerator_T::FindVariable(GeneratorParam_T* Param, const String& VarName)
	{
		// 从局部变量表中找到变量
		auto OffsetAndObj = Param->Allocator->GetObjAndOffset(VarName);
		if (OffsetAndObj.second != SIZE_MAX) {
			return std::make_tuple(OffsetAndObj.first, 1, OffsetAndObj.second);
		}

		// 从参数中查找
		OffsetAndObj = Param->Function->GetParamObjAndOffset(VarName);
		if (OffsetAndObj.second != SIZE_MAX) {
			return std::make_tuple(OffsetAndObj.first, 2, OffsetAndObj.second);
		}

		return std::make_tuple(nullptr, 0, 0);
	}

	void CodeGenerator_T::GenerateRealFuncBody(GeneratorParam_T* Param)
	{
		const CodeBlock_T* Block = &Param->Function->Body;
		const auto& Nodes = Block->GetSubNodes();


		StackResAllocator_T Allocator;
		const auto& Variables = Param->Function->Space.GetVariables();
		Allocator.SetLocalVariables(Variables);
		Param->Allocator = &Allocator;

		auto& Assembler = Param->Assembler;

		const size_t NeedSize = Allocator.GetNeedSize();
		
		

		// push Ebp
		// mov Ebp, Esp
		// lea Esp, [Esp-xxx]
		Assembler->Push(x86::Register::Ebp);
		Assembler->Mov(x86::Register::Ebp, x86::Register::Esp);
		Assembler->Lea(x86::Register::Esp, x86::Register::Esp, -(static_cast<int>(NeedSize) + 4));
		
		const size_t FramePos = Assembler->GetSize();

		// 检索所有类的成员函数,如果有构造函数，则调用
		for (const auto& VarObj : Variables) {
			const SpaceMember_T* Definition = VarObj.second->TypeDesc->DefinitionPtr;
			const SpaceMemberType T = Definition == nullptr ? SpaceMemberType::Unknown : Definition->GetMemberType();
			if (T == SpaceMemberType::Class) {
				const Class_T* ClassObj = (Class_T*)Definition;
				const auto Constructors = ClassObj->GetConstructors();
			}
		}

		for (const auto& Node : Nodes) {
			switch (Node->GetType()) {
				// 调用语句
			case ASTNodeType::CallingStatement: {
				const CallingStatement_T* Calling = dynamic_cast<const CallingStatement_T*>(Node);
				GenerateStatement_Calling(Param, Calling);
				// 调试：每条语句结束后加一个nop
				Param->Assembler->Nop();
				Allocator.ResetRegisterAllocator();
				break;
			}
				// 赋值语句
			case ASTNodeType::BinaryExpression: {
				if (((BinaryExpression_T*)Node)->Operator != BinOp_E::Assign) {
					throw Exception(u8"目前仅支持赋值语句的二元表达式。");
				}
				AssignStatement_T* Statement = dynamic_cast<AssignStatement_T*>(Node);
				GenerateStatement_Assign(Param, Statement);
				// 调试：每条语句结束后加一个nop
				Param->Assembler->Nop();
				Allocator.ResetRegisterAllocator();
				break;
			}

			}
		}

		const auto& UsedResisters = Allocator.GetUsedRegisters();

		// 保存寄存器
		if (!UsedResisters.empty()) {
			Param->Assembler->SetPointer(FramePos);
			for (const auto& Register : UsedResisters) {
				if (Register == x86::Register::Eax || Register == x86::Register::Ecx || Register == x86::Register::Edx) {
					continue;
				}
				Param->Assembler->Push(Register);
			}
			

			// 因为在开头插入了堆栈框架，所以需要将所有的重定位项后移
			Param->Relocates->SetBaseOffset(Param->Assembler->GetPointer());

			// 还原寄存器
			Param->Assembler->ResetPointer();
			for (auto pRegister = UsedResisters.rbegin(); pRegister != UsedResisters.rend(); ++pRegister) {
				const x86::Register Register = *pRegister;
				if (Register == x86::Register::Eax || Register == x86::Register::Ecx || Register == x86::Register::Edx) {
					continue;
				}
				Param->Assembler->Pop(Register);
			}
		}

		// mov Esp, Ebp
		// pop Ebp
		Assembler->Mov(x86::Register::Esp, x86::Register::Ebp);
		Assembler->Pop(x86::Register::Ebp);

		const auto& Params = Param->Function->GetParams();
		size_t Size = 0;
		if (!Params.empty()) {
			for (auto it = Params.rbegin(); it != Params.rend(); ++it) {
				Size += 4;
			}
		}
		if (Size == 0) {
			Param->Assembler->Retn();
		}
		else {
			Param->Assembler->Ret_Imm16(Size);
		}
	}

	void CodeGenerator_T::GenerateRealFuncParam(GeneratorParam_T* Param, const ASTNode_T* AParam)
	{
		const ASTNodeType Type = AParam->GetType();
		if (Type == ASTNodeType::LiteralInteger) {
			__int64 Value = ((LiteralInteger_T*)AParam)->GetValue();
			// 先判断是否为64位整数
			if (Value == (__int64)((int32_t)Value)) {
				Param->Assembler->Push(Value);
			}
			else {
				// 否则，先push低32位
				Param->Assembler->Push((int32_t)Value);
				// 再push高32位
				Param->Assembler->Push((int32_t)(Value >> 32));
			}
		}
		else if (Type == ASTNodeType::LiteralString) {
			const String& LS = ((LiteralString_T*)AParam)->GetValue();
			const auto RawData = Array<BYTE>(LS.begin(), LS.end());
			Param->Relocates->AddBinaryRes(Param->Assembler->GetSize() + 2, RawData);
			Param->Assembler->Push_Imm32(0);
		}
		else if (Type == ASTNodeType::Identifier) {
			const Identifier_T* Identifier = dynamic_cast<const Identifier_T*>(AParam);
			const String Name = Identifier->GetName();
			// 先push低32位
			const size_t Offset = Param->Allocator->GetOffset(Name);
			Param->Assembler->Push(x86::Register::Ebp, -(int32_t)(Offset));
		}
	}

	void CodeGenerator_T::GenerateStatement_Calling(GeneratorParam_T* Param, const CallingStatement_T* Calling)
	{
		const ASTNode_T* Source = Calling->GetSource();
		const ASTNodeType SourceType = Source->GetType();
		if (SourceType == ASTNodeType::Identifier) {
			const String& Name = ((Identifier_T*)Source)->GetName();
			const Function_T* FuncSource = nullptr;
			if (FindFunction(&FuncSource, Name)) {
				const auto& Params = Calling->GetParams();
				if (!Params.empty()) {
					for (auto it = Params.rbegin(); it != Params.rend(); ++it) {
						const auto& AParam = *it;
						GenerateRealFuncParam(Param, AParam);
					}
				}
				const Array<String>* OptParams = FuncSource->GetOption(u8"导入");
				if (OptParams != nullptr) {
					const size_t Size = OptParams->size();
					if (Size != 1 && Size != 2) {
						throw Exception(u8"函数“导入”选项参数过多或过少。");
					}
					const String& LibName = (*OptParams)[0];
					const String& SymbolName = Size == 1 ? Name : (*OptParams)[1];
					Param->Relocates->AddExternal(Param->Assembler->GetSize() + 3, LibName, SymbolName);
					Param->Assembler->Call_Dword_Ptr(nullptr);
				}
				else {
					String Symbol;
					if (Param->Function->Parent != nullptr) {
						Symbol = Param->Function->Parent->GetAccessName();
					}
					if (!Symbol.empty()) {
						Symbol += ".";
					}
					Symbol += Name;
					Symbol += "@" + FuncSource->GetFeatureDesc();
					Param->Relocates->AddRealFunc(Param->Assembler->GetSize() + 2, Symbol);
					Param->Assembler->Call(nullptr);
				}
			}
			else {
				throw Exception(u8"未找到函数：" + ((Identifier_T*)Source)->GetName());
			}
		}
		//if (SourceType == ASTNodeType::MemberAccess) {
		//	const MemberAccess_T* MemberAccess = dynamic_cast<const MemberAccess_T*>(Source);

		//	const ASTNode_T* Source = MemberAccess->Left;
		//	const Identifier_T* Member = dynamic_cast<Identifier_T*>(MemberAccess->Right);

		//	if (Source->GetType() == ASTNodeType::Identifier) {
		//		const String& Name = ((Identifier_T*)Source)->GetName();
		//		// 先从局部变量表中找到变量
		//		const Variable_T* Variable = Param->Function->Space.FindVariable(Name);
		//		if (Variable != nullptr) {
		//			String s = ((Class_T*)Variable->TypeDesc->DefinitionPtr)->Space.GetAccessName();
		//			if (!s.empty()) {
		//				s += ".";
		//			}
		//			s += Member->GetName() + "@" + ((Class_T*)Variable->TypeDesc->DefinitionPtr)->Space.Functions[Member->GetName()][0]->GetFeatureDesc();
		//			Param->Assembler->Lea(x86::Register::Ecx, x86::Register::Ebp, 114514);
		//			Param->Relocates->AddRealFunc(Param->Assembler->GetSize() + 2, s);
		//			Param->Assembler->Call(nullptr);
		//		}

		//	}
		//}
	}
	
	void CodeGenerator_T::GenerateStatement_Assign(GeneratorParam_T* Param, const AssignStatement_T* Assign)
	{
		const ASTNode_T* Target = Assign->Left;
		const ASTNode_T* Value = Assign->Right;
		if (!Target || !Value) { return; }
		// 根据被赋值对象来
		const ASTNodeType TargetType = Target->GetType();
		if (TargetType == ASTNodeType::Identifier) {
			const Identifier_T* Identifier = dynamic_cast<const Identifier_T*>(Target);
			const String VarName = Identifier->GetName();
			if (VarName == u8"结果") {
				// mov [Ebp-4], exx
				const x86::Register R = GenerateValueExpression(Param, Value);
				Param->Assembler->Mov(x86::Register::Ebp, -4, R);
				return;
			}

			size_t i = 0;
			const auto [VarObj, DefSpace, Offset] = FindVariable(Param, VarName);

			// 变量未找到
			if (VarObj == nullptr) {
				throw Exception(u8"未找到变量：" + VarName);
			}

			// 局部变量
			if (DefSpace == 1) {
				if (Value->GetType() == ASTNodeType::LiteralInteger) {
					// mov [Ebp-xxx], 123
					__int64 LI = ((LiteralInteger_T*)Value)->GetValue();
					Param->Assembler->Mov(x86::Register::Ebp, -Offset, LI);
				}
				else if (Value->GetType() == ASTNodeType::LiteralString)
				{
					String S = ((LiteralString_T*)Value)->GetValue();
					Array<BYTE> Binary;
					Binary.resize(8);
					*(uint32_t*)(Binary.data()) = static_cast<uint32_t>(0xffffffff);
					*((uint32_t*)(Binary.data()) + 1) = static_cast<uint32_t>(S.size());
					AppendRaw(Binary, S.data(), S.size());
					Param->Relocates->AddBinaryRes(Param->Assembler->GetSize() + 2, Binary);
					Param->Assembler->Push_Imm32(0);
				}
				else {
					// mov [Ebp-xxx], exx
					const x86::Register R = GenerateValueExpression(Param, Value);
					Param->Assembler->Mov(x86::Register::Ebp, -Offset, R);
				}
				return;
			}
		}
		//else if (TargetType == ASTNodeType::MemberAccess) {
		//	const MemberAccess_T* MemberAccess = (const MemberAccess_T*)Target;
		//	const auto Pos = GenerateNode_MemberAccPtr(Param, MemberAccess);
		//	if (Value->GetType() == ASTNodeType::LiteralInteger) {
		//		// mov [Eax], 123
		//		__int64 LI = ((LiteralInteger_T*)Value)->GetValue();
		//		Param->Assembler->Mov(Pos.first, Pos.second, LI);
		//	}
		//	else {
		//		// mov [Eax], Eax
		//		const x86::Register R2 = GenerateValueExpression(Param, Value);
		//		Param->Assembler->Mov(Pos.first, Pos.second, R2);
		//	}
		//}
		else {
			throw Exception(u8"暂不支持。");
		}
	}

	Pair<x86::Register, int> CodeGenerator_T::GenerateNode_MemberAccPtr(GeneratorParam_T* Param, const MemberAccess_T* MemberAcc)
	{
		auto& Assembler = Param->Assembler;

		const ASTNode_T* Source = MemberAcc->Left;
		if (Source->GetType() != ASTNodeType::Identifier) {
			throw Exception(u8"暂不支持。");
		}
		const String& Name = ((Identifier_T*)Source)->GetName();
		
		const auto [VarObj, DefSpace, Offset] = FindVariable(Param, Name);
		if (DefSpace != 1) {
			throw Exception(u8"暂不支持。");
		}

		const Identifier_T* Member = dynamic_cast<Identifier_T*>(MemberAcc->Right);
		const String MemberName = Member->GetName();

		Assembler->Lea(x86::Register::Eax, x86::Register::Ebp, -Offset);
		const size_t MemberOffset = dynamic_cast<Structure_T*>(VarObj->TypeDesc->DefinitionPtr)->GetMemberVarOffset(MemberName);
		return std::make_pair(x86::Register::Eax, MemberOffset);
	}

	x86::Register CodeGenerator_T::GenerateExpression_Binary(GeneratorParam_T* Param, const BinaryExpression_T* Binary)
	{
		auto& Assembler = Param->Assembler;
		auto& Allocator = Param->Allocator;

		x86::Register R = x86::Register::Unk;
		const ASTNode_T* Left = Binary->Left;

		if (Left->GetType() == ASTNodeType::Identifier) {
			R = GenerateValueExpression(Param, Left);
		}
		/*else if (Left->GetType() == ASTNodeType::ForBinExpression) {
			BinaryExpression_T* LeftBinary = (BinaryExpression_T*)Left;
			R = GenerateExpression_Binary(Param, LeftBinary);
		}*/
		else {
			throw Exception(u8"暂不支持。");
		}
		Allocator->PushR(R);
		
		const BinOp_E Op = Binary->Operator;
		const ASTNode_T* Right = Binary->Right;
		GenerateBinaryRight(Param, Op, Right);

		return R;
	}

	x86::Register CodeGenerator_T::GenerateBinaryRight(GeneratorParam_T* Param, const BinOp_E Op, const ASTNode_T* Right)
	{
		auto& Assembler = Param->Assembler;
		auto& Allocator = Param->Allocator;
		const x86::Register ActiveR = Allocator->GetAvtiveR();
		const ASTNodeType Type = Right->GetType();
		if (Type == ASTNodeType::LiteralInteger) {
			__int64 Value = ((LiteralInteger_T*)Right)->GetValue();
			if (Op == BinOp_E::Add) {
				Assembler->Add(ActiveR, Value);
			}
			else if (Op == BinOp_E::Sub) {
				Assembler->Sub(ActiveR, Value);
			}
			else if (Op == BinOp_E::Mul) {
				Assembler->Imul3(ActiveR, ActiveR, Value);
			}
		}
		else if (Type == ASTNodeType::Identifier) {
			const String& Name = ((Identifier_T*)Right)->GetName();
			const auto [VarObj, DefSpace, Offset] = FindVariable(Param, Name);
			if (VarObj == nullptr) {
				throw Exception(u8"内部错误");
			}
			// 局部变量
			if (DefSpace == 1) {
				
				if (Op == BinOp_E::Add) {
					// add Eax, [Ebp-xxx]
					Assembler->Add(ActiveR, x86::Register::Ebp, -Offset);
				}
				else if (Op == BinOp_E::Sub) {
					// Sub Eax, [Ebp-xxx]
					Assembler->Sub(ActiveR, x86::Register::Ebp, -Offset);
				}
				else if (Op == BinOp_E::Mul) {
					// Imul Eax, [Ebp-xxx]
					Assembler->Imul2(ActiveR, x86::Register::Ebp, -Offset);
				}
			}
			// 参数
			if (DefSpace == 2) {
				if (Op == BinOp_E::Add) {
					// Add Eax, [Ebp+xxx]
					Assembler->Add(ActiveR, x86::Register::Ebp, Offset + 4);
				}
				else if (Op == BinOp_E::Sub) {
					// Sub Eax, [Ebp+xxx]
					Assembler->Sub(ActiveR, x86::Register::Ebp, Offset + 4);
				}
				else if (Op == BinOp_E::Mul) {
					// Imul Eax, [Ebp+xxx]
					Assembler->Imul2(ActiveR, x86::Register::Ebp, Offset + 4);
				}
				
			}
		}
		/*else if (Type == ASTNodeType::ForBinExpression) {
			const BinaryExpression_T* Binary = (const BinaryExpression_T*)Right;
			const x86::Register R = GenerateExpression_Binary(Param, Binary);
			if (Op == BinOp_E::Add) {
				Assembler->Add(ActiveR, R);
			}
			else if (Op == BinOp_E::Sub) {
				Assembler->Sub(ActiveR, R);
			}
			else if (Op == BinOp_E::Mul) {
				Assembler->Imul2(ActiveR, R);
			}
		}*/
		else {
			throw Exception(u8"暂不支持。");
		}
		return x86::Register();
	}

	x86::Register CodeGenerator_T::GenerateValueExpression(GeneratorParam_T* Param, const ASTNode_T* Node)
	{
		auto& Assembler = Param->Assembler;
		auto& Allocator = Param->Allocator;

		const ASTNodeType Type = Node->GetType();
		if (Type == ASTNodeType::CallingStatement) {
			const CallingStatement_T* Calling = dynamic_cast<const CallingStatement_T*>(Node);
			GenerateStatement_Calling(Param, Calling);
			const x86::Register R = Allocator->AllocateRegister();
			if (R != x86::Register::Eax) {
				Assembler->Mov(R, x86::Register::Eax);
			}
			return R;
		}

		else if (Type == ASTNodeType::BinaryExpression) {
			const BinaryExpression_T* Binary = dynamic_cast<const BinaryExpression_T*>(Node);
			return GenerateExpression_Binary(Param, Binary);
		}

		else if (Type == ASTNodeType::Identifier)
		{
			const x86::Register R = Allocator->AllocateRegister();

			const Identifier_T* Identifier = dynamic_cast<const Identifier_T*>(Node);
			const String VarName = Identifier->GetName();
			// 找到变量
			const auto [VarObj, DefSpace, Offset] = FindVariable(Param, VarName);
			if (VarObj == nullptr) {
				throw Exception(u8"内部错误");
			}
			// 局部变量
			if (DefSpace == 1) {
				// mov Eax, [Ebp-xxx]
				Param->Assembler->Mov(R, x86::Register::Ebp, -Offset);
				return R;
			}
			// 参数
			if (DefSpace == 2) {
				// mov Eax, [Ebp+xxx]
				Param->Assembler->Mov(R, x86::Register::Ebp, Offset + 4);
				return R;
			}
		}
		return x86::Register::Unk;
	}

	thread_local String CodeGenerator_T::m_ErrorMsg;

	bool CodeGenerator_T::FindFunction(const Function_T** Result, const String& Name)
	{
		// 暂时先返回第一个重造函数
		auto it = m_Space->Functions.find(Name);
		if (it == m_Space->Functions.end()) {
			*Result = nullptr;
			return false;
		}
		if (it->second.empty()) {
			*Result = nullptr;
			return false;
		}
		*Result = it->second[0];
		return true;
	}
}