﻿#include "ObjectFile.hpp"
#include "Helper.hpp"
namespace CShang
{
	//ObjFuncRelocate_T::ObjFuncRelocate_T()
	//{
	//}

	//ObjFuncRelocate_T::~ObjFuncRelocate_T()
	//{
	//	if (TypeDesc == Type_E::StringRes) {
	//		StringRes.Content.~basic_string();
	//	}
	//	else if (TypeDesc == Type_E::Function) {

	//	}
	//	else if (TypeDesc == Type_E::External) {
	//		External.LibName.~basic_string();
	//		External.Symbol.~basic_string();
	//	}
	//}

	//ObjFunction_T::~ObjFunction_T()
	//{
	//	for (auto& Relocate : m_Relocates) {
	//		delete Relocate;
	//		Relocate = nullptr;
	//	}
	//}

	//void ObjFunction_T::AddBinaryRes(int Offset, const LiteralString& BinRes)
	//{
	//	ObjFuncRelocate_T* Relocate = new ObjFuncRelocate_T;
	//	Relocate->TypeDesc = ObjFuncRelocate_T::Type_E::StringRes;
	//	Relocate->StringRes.Content = BinRes;
	//	m_Relocates.push_back(Relocate);
	//}

	//void ObjFunction_T::AddExternal(int Offset, const LiteralString& LibName, const LiteralString& Symbol)
	//{
	//	ObjFuncRelocate_T* Relocate = new ObjFuncRelocate_T;
	//	Relocate->TypeDesc = ObjFuncRelocate_T::Type_E::Function;
	//	//Relocate->External.LibName = LibName;
	//	//Relocate->External.Symbol = Symbol;
	//	m_Relocates.push_back(Relocate);
	//}

	void ObjFuncRelocates_T::SetBaseOffset(int Offset)
	{
		for (const auto& Binary : m_BinaryRes) {
			Binary->Offset += Offset;
		}
		for (const auto& External : m_Externals) {
			External->Offset += Offset;
		}
		for (const auto& Func : m_RealFuncs) {
			Func->Offset += Offset;
		}
	}

	void ObjFuncRelocates_T::AddBinaryRes(int Offset, const Array<BYTE>& BinRes)
	{
		BinaryRes_T* Res = new BinaryRes_T;
		Res->Offset = Offset;
		Res->RawData = BinRes;
		m_BinaryRes.push_back(Res);
	}

	void ObjFuncRelocates_T::AddExternal(int Offset, const String& LibName, const String& Symbol)
	{
		External_T* Ext = new External_T;
		Ext->Offset = Offset;
		Ext->LibName = LibName;
		Ext->Symbol = Symbol;
		m_Externals.push_back(Ext);
	}

	void ObjFuncRelocates_T::AddRealFunc(int Offset, const String& Symbol)
	{
		RealFunc_T* RelF = new RealFunc_T;
		RelF->Offset = Offset;
		RelF->Symbol = Symbol;
		m_RealFuncs.push_back(RelF);
	}

	ObjSymbol_T::ObjSymbol_T()
	{
		m_Type = ObjSymbolType_E::Variable;
	}

	ObjFunction_T::ObjFunction_T()
	{
		m_Type = ObjSymbolType_E::Function;
	}

	bool ObjectFile_T::LoadFromFile(const String& Path)
	{
		try {
			InFile File;
			File.open(Path);
			if (!File.is_open()) {
				throw std::runtime_error("Failed to open the file!");
			}

			Json::Value Root;
			File >> Root;


			const Json::Value& SymbolTable = Root[u8"符号表"];
			Json::Value::Members keys = SymbolTable.getMemberNames();
			for (const auto& key : keys) {
				ObjFunction_T* ObjFunc = new ObjFunction_T;
				ObjFunc->SetName(key);

				ObjFunc->SetCode(HexToBin(SymbolTable[key][u8"代码"].asString()));

				if (SymbolTable[key].isMember(u8"依赖表")) {
					ObjFuncRelocates_T* Relocates = new ObjFuncRelocates_T;
					ObjFunc->SetRelocates(Relocates);

					const Json::Value& RelocateTable = SymbolTable[key][u8"依赖表"];
					for (const auto& Relocate : RelocateTable) {
						if (Relocate[u8"类型"] == u8"外部函数") {
							const int Offset = Relocate[u8"偏移"].asInt();
							const String LibName = Relocate[u8"库名"].asString();
							const String Symbol = Relocate[u8"符号"].asString();
							Relocates->AddExternal(Offset, LibName, Symbol);

						}
						if (Relocate[u8"类型"] == u8"依赖函数") {
							const int Offset = Relocate[u8"偏移"].asInt();
							const String Symbol = Relocate[u8"符号"].asString();
							Relocates->AddRealFunc(Offset, Symbol);

						}
						else if (Relocate[u8"类型"] == u8"二进制") {
							const int Offset = Relocate[u8"偏移"].asInt();
							const Array<BYTE> RawData = Base64Decode(Relocate[u8"数据"].asString(), B64Table);
							Relocates->AddBinaryRes(Offset, RawData);
						}
					}
					
				}
				m_Symbols.push_back(ObjFunc);
			}

			return true;
		}
		catch (...) {
			return false;
		}
	}

	bool ObjectFile_T::SaveToFile(const String& Path)
	{
		try {
			OutFile File;
			File.open(Utf8ToWide(Path));
			if (!File.is_open()) {
				throw std::runtime_error("Failed to open the file!");
			}

			Json::Value SymbolTable;
			for (const auto& Symbol : m_Symbols) {
				ObjSymbolType_E Type = Symbol->GetType();
				if (Type == ObjSymbolType_E::Function) {
					Json::Value SymbolEntry;
					const String& Name = Symbol->GetName();

					ObjFunction_T* Func = (ObjFunction_T*)Symbol;
	
					for (const auto& Relocate : Func->m_Relocates->GetExternals()) {
						Json::Value RelocateEntry;
						RelocateEntry[u8"类型"] = u8"外部函数";
						RelocateEntry[u8"偏移"] = Relocate->Offset;
						RelocateEntry[u8"库名"] = Relocate->LibName;
						RelocateEntry[u8"符号"] = Relocate->Symbol;
						SymbolEntry[u8"依赖表"].append(RelocateEntry);
					}

					for (const auto& Relocate : Func->m_Relocates->GetBinaryRes()) {
						Json::Value RelocateEntry;
						RelocateEntry[u8"类型"] = u8"二进制";
						RelocateEntry[u8"偏移"] = Relocate->Offset;
						RelocateEntry[u8"数据"] = Base64Encode(Relocate->RawData, B64Table);
						SymbolEntry[u8"依赖表"].append(RelocateEntry);
					}

					for (const auto& Relocate : Func->m_Relocates->GetRealFuncs()) {
						Json::Value RelocateEntry;
						RelocateEntry[u8"类型"] = u8"依赖函数";
						RelocateEntry[u8"偏移"] = Relocate->Offset;
						RelocateEntry[u8"符号"] = Relocate->Symbol;
						SymbolEntry[u8"依赖表"].append(RelocateEntry);
					}

					SymbolEntry[u8"代码"] = BinToHex(Func->GetCode());
					SymbolTable[Name] = SymbolEntry;
				}
			}

			Json::Value Root;
			// Root[u8"单元"] = m_OutputFile;
			Root[u8"版本"] = "1.0";
			Root[u8"符号表"] = SymbolTable;
			Root[u8"代码"] = BinToHex(m_InitCode);

			Json::StreamWriterBuilder builder;
			builder.settings_["emitUTF8"] = true;
			std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());
			writer->write(Root, &File);

			return true;
		}
		catch (...) {
			return false;
		}
	}

	void ObjectFile_T::SetInitCode(const Array<BYTE>& Code)
	{
		m_InitCode = Code;
	}

	const Array<BYTE>& ObjectFile_T::GetInitCode()
	{
		return m_InitCode;
	}

	void ObjectFile_T::AddFunction(const String& Name, const Array<BYTE>& Code, ObjFuncRelocates_T* Relocates)
	{
		ObjFunction_T* ObjFunc = new ObjFunction_T;
		ObjFunc->SetName(Name);
		ObjFunc->SetCode(Code);
		ObjFunc->SetRelocates(Relocates);
		m_Symbols.push_back(ObjFunc);
	}

	const ObjSymbol_T* ObjectFile_T::FindSymbol(const String& Name) const
	{
		for (const auto& Symbol : m_Symbols) {
			if (Symbol->GetName() == Name) {
				return Symbol;
			}
		}
		return nullptr;
	}


	/*void ObjectFile_T::AddFunction(const ObjFunction_T* ObjFunc)
	{
	}*/
}