#include "StackResAllocator.hpp"
namespace CShang
{
	StackResAllocator_T::StackResAllocator_T()
	{
	}

	StackResAllocator_T::~StackResAllocator_T()
	{
	}

	x86::Register StackResAllocator_T::GetAvtiveR() const
	{
		return m_RStack.top();
	}

	void StackResAllocator_T::PushR(x86::Register R)
	{
		m_RStack.push(R);
	}

	void StackResAllocator_T::PopR(x86::Register R)
	{
		m_RStack.pop();
	}

	void StackResAllocator_T::SetLocalVariables(const Array<Pair<String, Variable_T*>>& Variables)
	{
		size_t Offset = 0x4;
		for (const auto& Variable : Variables) {
			m_Variables.push_back(
				std::make_pair(Variable.first, std::make_pair(Offset, Variable.second))
			);
			size_t Size = Variable.second->TypeDesc->GetSize();
			m_NeedSize += Size;
			Offset += Size;
		}
	}

	size_t StackResAllocator_T::GetNeedSize() const
	{
		return m_NeedSize;
	}

	Pair<Variable_T*, size_t> StackResAllocator_T::GetObjAndOffset(const String& Name) const
	{
		for (const auto& Variable : m_Variables) {
			if (Variable.first == Name) {
				return std::make_pair(
					Variable.second.second,
					Variable.second.first
				);
			}
		}
		return std::make_pair(nullptr, SIZE_MAX);
	}

	size_t StackResAllocator_T::GetOffset(const String& Name) const
	{
		for (const auto& Variable : m_Variables) {
			if (Variable.first == Name) {
				return Variable.second.first;
			}
		}
		return SIZE_MAX;
	}

	void StackResAllocator_T::ResetRegisterAllocator()
	{
		Eax = false; Ebx = false;
		Ecx = false; Edx = false;
		Edi = false; Esi = false;
	}

	x86::Register StackResAllocator_T::AllocateRegister()
	{
		if (!Eax) {
			Eax = true; Used_Eax = true;
			return x86::Register::Eax;
		}
		if (!Ebx) {
			Ebx = true; Used_Ebx = true;
			return x86::Register::Ebx;
		}
		if (!Ecx) {
			Ecx = true; Used_Ecx = true;
			return x86::Register::Ecx;
		}
		if (!Edx) {
			Edx = true; Used_Edx = true;
			return x86::Register::Edx;
		}
		if (!Edi) {
			Edi = true; Used_Edi = true;
			return x86::Register::Edi;
		}
		if (!Esi) {
			Esi = true; Used_Esi = true;
			return x86::Register::Esi;
		}
	}

	Array<x86::Register> StackResAllocator_T::GetUsedRegisters()
	{
		Array<x86::Register> Result;
		if (Used_Eax) {
			Result.push_back(x86::Register::Eax);
		}
		if (Used_Ebx) {
			Result.push_back(x86::Register::Ebx);
		}
		if (Used_Ecx) {
			Result.push_back(x86::Register::Ecx);
		}
		if (Used_Edx) {
			Result.push_back(x86::Register::Edx);
		}
		if (Used_Edi) {
			Result.push_back(x86::Register::Edi);
		}
		if (Used_Esi) {
			Result.push_back(x86::Register::Esi);
		}
		return Result;
	}
}